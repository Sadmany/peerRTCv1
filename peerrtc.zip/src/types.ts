export type ConnectionStatus = 
  | 'waiting' 
  | 'connecting' 
  | 'connected' 
  | 'reconnecting' 
  | 'disconnected' 
  | 'failed';

export interface UserIdentity {
  username: string;
  peerAddress: string;
  createdAt: number;
}

export interface AppSettings {
  autoReconnect: boolean;
  stripMetadataOnTransfer: boolean;
  iceServers: string[];
}

export interface KnownPeer {
  peerAddress: string;
  username: string;
  lastSeen: number;
  notes?: string;
  isFavorite?: boolean;
}

// Internal CBOR-serialized WebRTC packet
export interface TransmissionPacket<T = any> {
  type: 'text' | 'file_chunk' | 'file_header' | 'file_ack' | 'mail' | 'mail_ack' | 'ping' | 'pong';
  payload?: any;
  metadata?: {
    id?: string;
    senderAddress?: string;
    senderUsername?: string;
    recipientAddress?: string;
    timestamp?: number;
    chunkIndex?: number;
    totalChunks?: number;
    filename?: string;
    fileSize?: number;
    mimeType?: string;
    [key: string]: any;
  };
}

export interface ChatMessage {
  id: string;
  conversationId: string; // peerAddress
  peerAddress?: string;
  sender: 'me' | string; // 'me' or peerAddress
  senderUsername: string;
  timestamp: number;
  type: 'text' | 'file' | 'system';
  text?: string;
  fileInfo?: {
    transferId: string;
    filename: string;
    size: number;
    mimeType: string;
    blobUrl?: string;
    downloadReady?: boolean;
  };
  deliveryStatus: 'sending' | 'sent' | 'delivered' | 'failed';
}

export type MailDeliveryStatus = 'sending' | 'sent' | 'delivered' | 'failed' | 'recipient unavailable';

export interface MailAttachment {
  name: string;
  filename?: string;
  size: number;
  type?: string;
  mimeType?: string;
  blobUrl?: string;
  dataUrl?: string;
}

export interface MailItem {
  id: string;
  direction: 'inbox' | 'sent';
  from: string; // peerAddress
  fromUsername: string;
  to: string[]; // usernames or addresses
  subject: string;
  message: string;
  body?: string;
  attachments?: MailAttachment[];
  timestamp: number;
  status: MailDeliveryStatus;
  deliveryStatus?: MailDeliveryStatus;
  read?: boolean;
}

export interface FileTransferItem {
  id: string;
  filename: string;
  fileSize: number;
  size?: number;
  fileType: string;
  peerAddress: string;
  peerUsername: string;
  direction: 'upload' | 'download';
  status: 'transferring' | 'completed' | 'interrupted' | 'failed' | 'cancelled';
  progress: number; // 0 - 100
  speed: number | string; // bytes/sec or formatted string like "1.4 MB/s"
  bytesTransferred: number;
  totalChunks: number;
  chunksCompleted: number;
  timestamp: number;
  blob?: Blob;
  blobUrl?: string;
}

export interface ActiveSession {
  sessionId: string;
  isHost: boolean;
  peerAddress?: string;
  peerUsername?: string;
  status: ConnectionStatus;
  startedAt: number;
  reconnectAttempts: number;
}
