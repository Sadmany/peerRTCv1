import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Terminal, 
  Network, 
  MessageSquare, 
  Mail, 
  ArrowLeftRight, 
  Wrench, 
  Settings, 
  BookOpen, 
  LogOut, 
  PlusCircle, 
  Link 
} from 'lucide-react';
import { NavigationSection } from './Sidebar';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (section: NavigationSection) => void;
  onOpenNotes: () => void;
  onOpenSettings: () => void;
  onCreateConnection: () => void;
  onJoinConnection: () => void;
  onComposeMail: () => void;
  onRequestCloseSession: () => void;
  isSessionActive: boolean;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenNotes,
  onOpenSettings,
  onCreateConnection,
  onJoinConnection,
  onComposeMail,
  onRequestCloseSession,
  isSessionActive
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (isOpen) {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const commands = [
    {
      id: 'nav-home',
      title: 'Go to Home / Activity Overview',
      category: 'Navigation',
      icon: Terminal,
      action: () => onNavigate('home')
    },
    {
      id: 'nav-connections',
      title: 'Go to Connection Hub',
      category: 'Navigation',
      icon: Network,
      action: () => onNavigate('connections')
    },
    {
      id: 'nav-messages',
      title: 'Go to Live 1-to-1 Chat',
      category: 'Navigation',
      icon: MessageSquare,
      action: () => onNavigate('messages')
    },
    {
      id: 'nav-mail',
      title: 'Go to PeerRTC Mail',
      category: 'Navigation',
      icon: Mail,
      action: () => onNavigate('mail')
    },
    {
      id: 'nav-transfers',
      title: 'Go to P2P File Transfers',
      category: 'Navigation',
      icon: ArrowLeftRight,
      action: () => onNavigate('transfers')
    },
    {
      id: 'nav-tools',
      title: 'Open Cyber Tools (Base64, Hex, Hash, JWT, Metadata, UUID, Timestamp, JSON)',
      category: 'Tools',
      icon: Wrench,
      action: () => onNavigate('tools')
    },
    {
      id: 'action-create',
      title: 'Create P2P Connection (New Session Code)',
      category: 'P2P Session',
      icon: PlusCircle,
      action: onCreateConnection
    },
    {
      id: 'action-join',
      title: 'Join P2P Connection (Enter Code)',
      category: 'P2P Session',
      icon: Link,
      action: onJoinConnection
    },
    {
      id: 'action-compose',
      title: 'Compose PeerRTC Mail',
      category: 'Mail',
      icon: Mail,
      action: onComposeMail
    },
    {
      id: 'action-notes',
      title: 'Open Technical Architecture Notes (Ctrl+/)',
      category: 'Help',
      icon: BookOpen,
      action: onOpenNotes
    },
    {
      id: 'action-settings',
      title: 'Open Settings & Storage Management',
      category: 'Settings',
      icon: Settings,
      action: onOpenSettings
    }
  ];

  if (isSessionActive) {
    commands.unshift({
      id: 'action-close-session',
      title: 'Disconnect Active P2P Session',
      category: 'P2P Session',
      icon: LogOut,
      action: onRequestCloseSession
    });
  }

  const filtered = commands.filter((c) =>
    c.title.toLowerCase().includes(query.toLowerCase()) ||
    c.category.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 p-4 z-50 animate-in fade-in duration-100">
      <div 
        className="w-full max-w-xl bg-[#1e1e1e] border border-[#2e2e2e] shadow-2xl rounded-sm overflow-hidden flex flex-col font-sans"
        role="dialog"
        aria-modal="true"
      >
        {/* Search Input */}
        <div className="flex items-center gap-2.5 px-3 py-2.5 bg-[#181818] border-b border-[#2a2a2a]">
          <Search className="w-4 h-4 text-gray-400" />
          <input
            autoFocus
            type="text"
            placeholder="Type a command or view name (Ctrl+K)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-xs font-mono text-white placeholder-gray-500 focus:outline-hidden"
          />
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-[#252525] border border-[#383838] rounded text-gray-400">
            ESC
          </kbd>
        </div>

        {/* Command list */}
        <div className="max-h-80 overflow-y-auto p-1.5 space-y-0.5 font-mono text-xs">
          {filtered.length === 0 ? (
            <div className="p-4 text-center text-gray-500">No matching commands</div>
          ) : (
            filtered.map((cmd) => {
              const Icon = cmd.icon;
              return (
                <button
                  key={cmd.id}
                  onClick={() => {
                    cmd.action();
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xs hover:bg-[#282828] text-left text-gray-300 hover:text-white transition-colors group"
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-3.5 h-3.5 text-sky-400 group-hover:text-sky-300" />
                    <span>{cmd.title}</span>
                  </div>
                  <span className="text-[10px] text-gray-500 group-hover:text-gray-300">
                    {cmd.category}
                  </span>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
