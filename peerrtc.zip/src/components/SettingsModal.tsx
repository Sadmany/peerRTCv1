import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  X, 
  User, 
  Network, 
  Shield, 
  Database, 
  Copy, 
  Check, 
  RefreshCw, 
  AlertTriangle,
  HardDrive
} from 'lucide-react';
import { UserIdentity, AppSettings } from '../types';
import { getStorageStats } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  identity: UserIdentity | null;
  settings: AppSettings;
  onUpdateUsername: (username: string) => Promise<void>;
  onUpdateSettings: (newSettings: AppSettings) => Promise<void>;
  onClearHistory: () => Promise<void>;
  onClearAllData: () => Promise<void>;
  onResetIdentity: () => Promise<void>;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  identity,
  settings,
  onUpdateUsername,
  onUpdateSettings,
  onClearHistory,
  onClearAllData,
  onResetIdentity
}) => {
  const [activeTab, setActiveTab] = useState<'identity' | 'network' | 'privacy' | 'storage'>('identity');
  const [usernameInput, setUsernameInput] = useState<string>(identity?.username || '');
  const [usernameSaved, setUsernameSaved] = useState<boolean>(false);
  const [copiedAddress, setCopiedAddress] = useState<boolean>(false);

  // Storage usage stats
  const [storageStats, setStorageStats] = useState<{
    messagesCount: number;
    mailCount: number;
    transfersCount: number;
    peersCount: number;
    approximateSizeBytes: number;
  } | null>(null);

  // Confirmation states
  const [confirmClearHistory, setConfirmClearHistory] = useState<boolean>(false);
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);
  const [confirmResetIdentity, setConfirmResetIdentity] = useState<boolean>(false);

  useEffect(() => {
    if (identity?.username) {
      setUsernameInput(identity.username);
    }
  }, [identity?.username]);

  useEffect(() => {
    if (isOpen) {
      getStorageStats().then(setStorageStats);
    }
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSaveUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameInput.trim()) return;
    const clean = usernameInput.trim().substring(0, 15);
    await onUpdateUsername(clean);
    setUsernameSaved(true);
    setTimeout(() => setUsernameSaved(false), 2000);
  };

  const handleCopyAddress = () => {
    if (!identity?.peerAddress) return;
    navigator.clipboard.writeText(identity.peerAddress);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleToggleAutoReconnect = async () => {
    await onUpdateSettings({
      ...settings,
      autoReconnect: !settings.autoReconnect
    });
  };

  const handleToggleStripMetadata = async () => {
    await onUpdateSettings({
      ...settings,
      stripMetadataOnTransfer: !settings.stripMetadataOnTransfer
    });
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 KB';
    return (bytes / 1024).toFixed(1) + ' KB';
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-2xl bg-[#181818] border border-[#2e2e2e] shadow-2xl rounded-sm flex flex-col overflow-hidden font-sans text-gray-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-title"
      >
        {/* Header */}
        <div className="h-11 px-4 bg-[#1f1f1f] border-b border-[#2b2b2b] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 font-mono text-xs font-semibold text-gray-200">
            <Settings className="w-4 h-4 text-sky-400" />
            <span id="settings-title">PeerRTC Preferences</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white rounded hover:bg-[#2b2b2b] transition-colors"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#2b2b2b] bg-[#1a1a1a] px-3 font-mono text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('identity')}
            className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors shrink-0 ${
              activeTab === 'identity'
                ? 'border-sky-400 text-sky-400 font-medium'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Identity</span>
          </button>

          <button
            onClick={() => setActiveTab('network')}
            className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors shrink-0 ${
              activeTab === 'network'
                ? 'border-sky-400 text-sky-400 font-medium'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>Network & WebRTC</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors shrink-0 ${
              activeTab === 'privacy'
                ? 'border-sky-400 text-sky-400 font-medium'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Privacy</span>
          </button>

          <button
            onClick={() => setActiveTab('storage')}
            className={`flex items-center gap-1.5 px-3 py-2.5 border-b-2 transition-colors shrink-0 ${
              activeTab === 'storage'
                ? 'border-sky-400 text-sky-400 font-medium'
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Local Storage</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 max-h-[65vh] overflow-y-auto space-y-6 text-sm">
          
          {/* TAB: IDENTITY */}
          {activeTab === 'identity' && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-mono font-medium text-gray-300 mb-1.5">
                  Peer Handle / Username
                </label>
                <form onSubmit={handleSaveUsername} className="flex gap-2">
                  <input
                    type="text"
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    maxLength={15}
                    placeholder="Enter username"
                    className="flex-1 bg-[#1f1f1f] border border-[#333333] focus:border-sky-400 px-3 py-1.5 rounded text-xs font-mono text-gray-200 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    className={`px-3 py-1.5 rounded text-xs font-mono font-medium transition-colors flex items-center gap-1.5 ${
                      usernameSaved
                        ? 'bg-emerald-600 text-white'
                        : 'bg-sky-600 hover:bg-sky-500 text-white'
                    }`}
                  >
                    {usernameSaved ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Saved</span>
                      </>
                    ) : (
                      <span>Save</span>
                    )}
                  </button>
                </form>
                <p className="text-[11px] text-gray-400 mt-1">
                  Visible to connected peers in 1-to-1 chats, mail headers, and transfer logs.
                </p>
              </div>

              <div className="pt-3 border-t border-[#262626]">
                <label className="block text-xs font-mono font-medium text-gray-300 mb-1.5">
                  Local Peer Address (PRTC)
                </label>
                <div className="flex items-center justify-between p-2.5 bg-[#1f1f1f] border border-[#2e2e2e] rounded text-xs font-mono">
                  <span className="text-sky-300">{identity?.peerAddress || 'Generating...'}</span>
                  <button
                    onClick={handleCopyAddress}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors text-xs ${
                      copiedAddress
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/40'
                        : 'bg-[#282828] hover:bg-[#333333] text-gray-300 border border-[#3d3d3d]'
                    }`}
                    title="Copy Address"
                  >
                    {copiedAddress ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-gray-400 mt-1">
                  Generated in your browser upon initial launch and stored locally in IndexedDB.
                </p>
              </div>

              <div className="pt-3 border-t border-[#262626]">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-mono font-medium text-gray-200">Reset Local Identity</h4>
                    <p className="text-[11px] text-gray-400">
                      Generate a fresh PRTC peer address and random username.
                    </p>
                  </div>
                  {confirmResetIdentity ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={async () => {
                          await onResetIdentity();
                          setConfirmResetIdentity(false);
                        }}
                        className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-mono"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => setConfirmResetIdentity(false)}
                        className="px-2 py-1 bg-[#282828] hover:bg-[#333333] text-gray-300 rounded text-xs font-mono"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setConfirmResetIdentity(true)}
                      className="flex items-center gap-1 px-2.5 py-1 bg-[#222222] hover:bg-[#2b2b2b] border border-[#333333] text-gray-300 rounded text-xs font-mono"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Reset Identity</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB: NETWORK & WEBRTC */}
          {activeTab === 'network' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-[#1f1f1f] border border-[#2a2a2a] rounded">
                <div>
                  <h4 className="text-xs font-mono font-medium text-gray-200">Auto-Reconnect on ICE Interruption</h4>
                  <p className="text-[11px] text-gray-400">
                    Automatically re-negotiate connection state if the WebRTC DataChannel temporarily drops.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoReconnect}
                  onChange={handleToggleAutoReconnect}
                  className="w-4 h-4 rounded bg-[#282828] border-gray-600 text-sky-500 focus:ring-sky-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-mono font-medium text-gray-300 mb-1">
                  Configured STUN / ICE Servers
                </label>
                <div className="p-2.5 bg-[#1f1f1f] border border-[#2a2a2a] rounded space-y-1 text-xs font-mono text-gray-300">
                  {settings.iceServers.map((server, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="text-gray-500">•</span>
                      <span>{server}</span>
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-gray-400 mt-1">
                  Public STUN servers are used solely to discover your external reflexive IP address and NAT type during session setup.
                </p>
              </div>

              <div className="p-3 bg-[#1a2332]/50 border border-sky-900/40 rounded text-xs space-y-1">
                <span className="font-mono font-medium text-sky-400">WebRTC DataChannel Protocol</span>
                <p className="text-gray-300 text-[11px]">
                  Structured messages use binary CBOR (Concise Binary Object Representation) serialization, delivering high transport efficiency, lower packet overhead, and zero text-encoding latency.
                </p>
              </div>
            </div>
          )}

          {/* TAB: PRIVACY */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-[#1f1f1f] border border-[#2a2a2a] rounded">
                <div>
                  <h4 className="text-xs font-mono font-medium text-gray-200">Strip Image Metadata (EXIF) on Transfer</h4>
                  <p className="text-[11px] text-gray-400">
                    Removes camera model, GPS coordinates, and timestamp metadata from uploaded images before chunk transmission.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.stripMetadataOnTransfer}
                  onChange={handleToggleStripMetadata}
                  className="w-4 h-4 rounded bg-[#282828] border-gray-600 text-sky-500 focus:ring-sky-500 cursor-pointer"
                />
              </div>

              <div className="p-3 bg-[#1f1f1f] border border-[#2a2a2a] rounded space-y-2">
                <h4 className="text-xs font-mono font-medium text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Privacy Notice & Technical Reality</span>
                </h4>
                <p className="text-[11px] text-gray-300 leading-relaxed">
                  PeerRTC does not store messages or files on central servers. Once a connection is established, communication travels directly over peer-to-peer WebRTC DataChannels.
                </p>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Direct P2P connections require each peer to see the other&apos;s IP address. If concealing your IP address from your peer is necessary, use a VPN or Tor.
                </p>
              </div>
            </div>
          )}

          {/* TAB: STORAGE */}
          {activeTab === 'storage' && (
            <div className="space-y-4">
              {/* Storage Overview */}
              <div className="p-3 bg-[#1f1f1f] border border-[#2a2a2a] rounded space-y-2">
                <div className="flex items-center justify-between font-mono text-xs">
                  <div className="flex items-center gap-2 text-gray-300">
                    <HardDrive className="w-4 h-4 text-sky-400" />
                    <span>IndexedDB Local Storage</span>
                  </div>
                  <span className="text-sky-300 font-semibold">
                    {storageStats ? formatSize(storageStats.approximateSizeBytes) : 'Calculating...'}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-xs font-mono">
                  <div className="p-2 bg-[#181818] rounded border border-[#262626]">
                    <span className="text-gray-400 text-[10px]">Chat Messages</span>
                    <p className="text-gray-200 font-bold">{storageStats?.messagesCount ?? 0}</p>
                  </div>
                  <div className="p-2 bg-[#181818] rounded border border-[#262626]">
                    <span className="text-gray-400 text-[10px]">Mail Dispatches</span>
                    <p className="text-gray-200 font-bold">{storageStats?.mailCount ?? 0}</p>
                  </div>
                  <div className="p-2 bg-[#181818] rounded border border-[#262626]">
                    <span className="text-gray-400 text-[10px]">Transfers</span>
                    <p className="text-gray-200 font-bold">{storageStats?.transfersCount ?? 0}</p>
                  </div>
                  <div className="p-2 bg-[#181818] rounded border border-[#262626]">
                    <span className="text-gray-400 text-[10px]">Known Peers</span>
                    <p className="text-gray-200 font-bold">{storageStats?.peersCount ?? 0}</p>
                  </div>
                </div>
              </div>

              {/* Clear History */}
              <div className="flex items-center justify-between p-3 bg-[#1f1f1f] border border-[#2a2a2a] rounded">
                <div>
                  <h4 className="text-xs font-mono font-medium text-gray-200">Clear Message & Transfer History</h4>
                  <p className="text-[11px] text-gray-400">
                    Deletes all stored chat transcripts, mail messages, and transfer logs. Preserves identity.
                  </p>
                </div>
                {confirmClearHistory ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={async () => {
                        await onClearHistory();
                        setConfirmClearHistory(false);
                        getStorageStats().then(setStorageStats);
                      }}
                      className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs font-mono"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setConfirmClearHistory(false)}
                      className="px-2 py-1 bg-[#282828] hover:bg-[#333333] text-gray-300 rounded text-xs font-mono"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmClearHistory(true)}
                    className="px-2.5 py-1 bg-[#282828] hover:bg-[#333333] text-gray-300 border border-[#3d3d3d] rounded text-xs font-mono"
                  >
                    Clear History
                  </button>
                )}
              </div>

              {/* Clear All Data */}
              <div className="flex items-center justify-between p-3 bg-[#241515] border border-rose-900/40 rounded">
                <div>
                  <h4 className="text-xs font-mono font-medium text-rose-300">Wipe All Local Storage</h4>
                  <p className="text-[11px] text-gray-400">
                    Irreversibly clears identity, address book, chats, mail, and settings from browser.
                  </p>
                </div>
                {confirmClearAll ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={async () => {
                        await onClearAllData();
                        setConfirmClearAll(false);
                        window.location.reload();
                      }}
                      className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-mono"
                    >
                      Confirm Wipe
                    </button>
                    <button
                      onClick={() => setConfirmClearAll(false)}
                      className="px-2 py-1 bg-[#282828] hover:bg-[#333333] text-gray-300 rounded text-xs font-mono"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmClearAll(true)}
                    className="px-2.5 py-1 bg-rose-950 hover:bg-rose-900 border border-rose-700/50 text-rose-300 rounded text-xs font-mono"
                  >
                    Wipe Everything
                  </button>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="h-10 px-4 bg-[#1f1f1f] border-t border-[#2b2b2b] flex items-center justify-between shrink-0 font-mono text-xs text-gray-400">
          <span>PeerRTC Local DB v1.0</span>
          <button
            onClick={onClose}
            className="px-3 py-1 bg-[#282828] hover:bg-[#333333] text-gray-200 border border-[#3d3d3d] rounded text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
