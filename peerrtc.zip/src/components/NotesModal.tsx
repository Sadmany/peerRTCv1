import React, { useState } from 'react';
import { BookOpen, X, ShieldAlert, Cpu, Terminal, FileCode, CheckCircle, Info, Lock } from 'lucide-react';

interface NotesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotesModal: React.FC<NotesModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<string>('architecture');

  if (!isOpen) return null;

  const topics = [
    { id: 'architecture', title: 'What is PeerRTC?' },
    { id: 'p2p_webrtc', title: 'WebRTC & P2P DataChannels' },
    { id: 'signaling_turn', title: 'Signaling & TURN Relays' },
    { id: 'encoding_vs_crypto', title: 'Encoding vs Encryption' },
    { id: 'base44_spec', title: 'Base44 Specification' },
    { id: 'mail_transfers', title: 'PeerRTC Mail & Chunked Transfers' },
    { id: 'storage_persistence', title: 'IndexedDB & Local State' },
    { id: 'connection_states', title: 'Connection States' },
    { id: 'privacy_limits', title: 'Privacy Limitations' },
  ];

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-4xl h-[85vh] max-h-[780px] bg-[#1e1e1e] border border-[#3e3e42] shadow-2xl rounded-sm flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="notes-panel-title"
      >
        {/* Header */}
        <div className="px-4 py-2.5 bg-[#252526] border-b border-[#333333] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-white font-mono text-xs font-semibold">
            <BookOpen className="w-4 h-4 text-[#007acc]" />
            <span id="notes-panel-title">PeerRTC Technical Documentation & Notes</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#333333] text-[#858585]">ESC to close</span>
          </div>
          <button
            onClick={onClose}
            className="text-[#858585] hover:text-white transition-colors p-1"
            title="Close (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content split */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Topic list */}
          <div className="w-full md:w-60 bg-[#252526] border-b md:border-b-0 md:border-r border-[#333333] p-2 shrink-0 overflow-y-auto">
            <div className="text-[11px] font-mono text-[#858585] px-2 py-1 uppercase tracking-wider">
              Sections
            </div>
            <div className="space-y-0.5">
              {topics.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-xs text-xs font-mono transition-colors ${
                    activeTab === t.id
                      ? 'bg-[#37373d] text-white font-medium border-l-2 border-[#007acc]'
                      : 'text-[#cccccc] hover:bg-[#2a2d2e] hover:text-white'
                  }`}
                >
                  {t.title}
                </button>
              ))}
            </div>
          </div>

          {/* Documentation body */}
          <div className="flex-1 p-5 overflow-y-auto font-mono text-xs leading-relaxed space-y-4 text-[#cccccc]">
            {activeTab === 'architecture' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-[#007acc]" />
                  What is PeerRTC?
                </h3>
                <p>
                  PeerRTC is a browser-native, privacy-oriented peer-to-peer cyber communication platform. It delivers 1-to-1 live messaging, a multi-recipient Mail system, and chunked file transfers without intermediate server message persistence.
                </p>
                <div className="p-3 bg-[#252526] border border-[#333333] rounded-xs space-y-2">
                  <div className="text-white font-semibold">Core Tenets:</div>
                  <ul className="list-disc pl-4 space-y-1 text-[#858585]">
                    <li><strong className="text-gray-200">No Account Infrastructure:</strong> No passwords, usernames or email logins stored on servers. Identities are generated directly in browser client storage.</li>
                    <li><strong className="text-gray-200">Local-First Storage:</strong> Conversations, transfer histories, and addresses reside exclusively in your browser's IndexedDB.</li>
                    <li><strong className="text-gray-200">Direct Transport:</strong> Communication travels peer-to-peer over encrypted WebRTC DataChannels whenever direct network routes exist.</li>
                  </ul>
                </div>
              </div>
            )}

            {activeTab === 'p2p_webrtc' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  WebRTC & P2P DataChannels
                </h3>
                <p>
                  WebRTC (Web Real-Time Communication) provides browsers with the ability to establish direct bidirectional binary and text pipelines called <code>RTCDataChannel</code>.
                </p>
                <div className="p-3 bg-[#181818] border border-[#333333] rounded-xs font-mono text-[11px] text-[#9cdcfe]">
                  [User A (Browser)] &lt;=== SCTP / DTLS / UDP ===&gt; [User B (Browser)]
                </div>
                <p>
                  Because the SCTP connection is layered over DTLS (Datagram Transport Layer Security), all traffic between peers is authenticated and encrypted in transit at the cryptographic transport layer.
                </p>
              </div>
            )}

            {activeTab === 'signaling_turn' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Info className="w-4 h-4 text-sky-400" />
                  Signaling & TURN Relays
                </h3>
                <p>
                  WebRTC cannot establish direct peer-to-peer routes without first knowing each peer's network parameters (IP candidates and codecs).
                </p>
                <ul className="list-disc pl-4 space-y-1.5 text-[#858585]">
                  <li><strong className="text-gray-200">Temporary Signaling:</strong> The PeerRTC server acts solely as a transient mailbox for SDP Offers, Answers, and ICE Candidates. Once connected, signaling is no longer used for chat.</li>
                  <li><strong className="text-gray-200">STUN (Session Traversal Utilities for NAT):</strong> Discovers your public IP address through NAT gateways.</li>
                  <li><strong className="text-gray-200">TURN (Traversal Using Relays around NAT):</strong> When peers are behind symmetric NATs or corporate firewalls that forbid direct peer-to-peer packets, a TURN server relays the encrypted packets.</li>
                </ul>
              </div>
            )}

            {activeTab === 'encoding_vs_crypto' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-rose-400 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-rose-400" />
                  Encoding vs Encryption (Crucial Distinction)
                </h3>
                <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-xs text-rose-200 text-xs">
                  <strong>Important Security Notice:</strong> Encoding (Base44, Base64, Hex, URL) transforms data into alternate representation formats. <em>It does NOT provide cryptographic confidentiality against anyone who obtains the raw payload.</em>
                </div>
                <p>
                  In PeerRTC, confidentiality is provided by WebRTC's underlying <strong>DTLS-SRTP</strong> session keys. Payload encoding is a cyber communication feature that allows transmission over binary-sensitive protocols, payload inspection, and explicit format structuring.
                </p>
              </div>
            )}

            {activeTab === 'base44_spec' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-[#007acc]" />
                  Base44 Encoding Specification
                </h3>
                <p>
                  Base44 is PeerRTC's default payload representation. It employs a deterministic radix-44 positional alphabet designed for safe ASCII transmission without URL-unsafe escapes.
                </p>
                <div className="p-2.5 bg-[#181818] border border-[#333333] rounded-xs font-mono text-[11px] text-amber-300 break-all">
                  Alphabet (44 chars): 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_.-~!*+=
                </div>
                <p>
                  Every transmitted packet carries mandatory metadata declaring its encoding:
                </p>
                <pre className="p-2.5 bg-[#181818] border border-[#333333] rounded-xs text-[#ce9178] text-[11px]">
{`{
  "type": "text",
  "encoding": "base44",
  "payload": "1L84Q..."
}`}
                </pre>
                <p className="text-[#858585]">
                  The receiver inspects the <code>encoding</code> field explicitly and never guesses from the payload content.
                </p>
              </div>
            )}

            {activeTab === 'mail_transfers' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  PeerRTC Mail & Chunked File Transfers
                </h3>
                <p>
                  <strong>PeerRTC Mail:</strong> Unlike SMTP/IMAP servers that store emails centrally, PeerRTC Mail transfers messages directly to target peers. Delivery confirmations (<em>Delivered</em>) are only reported after the recipient's DataChannel acknowledges packet receipt.
                </p>
                <p>
                  <strong>Chunked File Transfer:</strong> Files are sliced into 32KB sequential chunks with backpressure throttling on <code>RTCDataChannel.bufferedAmount</code>.
                </p>
                <div className="p-3 bg-[#252526] border border-[#333333] rounded-xs space-y-1 text-[#858585]">
                  <div className="text-emerald-400 font-semibold">Safety Guarantee:</div>
                  <p>
                    Received files, scripts, or executables are NEVER automatically opened or run. All downloads require explicit user action.
                  </p>
                </div>
              </div>
            )}

            {activeTab === 'storage_persistence' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white">IndexedDB Local Storage</h3>
                <p>
                  All conversation history, mail messages, transfer records, known peer addresses, and user preferences are persisted in your browser's local IndexedDB.
                </p>
                <p className="text-[#858585]">
                  When you close your tab, WebRTC sockets close naturally. When you return, PeerRTC restores your identity and records from IndexedDB and allows one-click reconnection.
                </p>
              </div>
            )}

            {activeTab === 'connection_states' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white">Connection States</h3>
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 text-[10px]">Waiting</span>
                    <span className="text-[#858585]">Session created; awaiting guest peer connection.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-sky-950 text-sky-400 text-[10px]">Connecting...</span>
                    <span className="text-[#858585]">Exchanging SDP Offers/Answers and ICE candidates.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px]">Connected</span>
                    <span className="text-[#858585]">DataChannel is active; live peer communication enabled.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 text-[10px]">Trying to reconnect...</span>
                    <span className="text-[#858585]">Temporary network glitch; ICE restart in progress.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-[#333333] text-[#cccccc] text-[10px]">Disconnected</span>
                    <span className="text-[#858585]">Peer closed session or network terminated.</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-400 text-[10px]">Connection failed.</span>
                    <span className="text-[#858585]">NAT traversal or session code handshake failed.</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'privacy_limits' && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  Accurate Privacy Language & Limitations
                </h3>
                <div className="p-3 bg-[#252526] border border-[#333333] rounded-xs space-y-2">
                  <div className="text-white font-semibold">Honest Technical Guarantees:</div>
                  <p className="text-[#858585]">
                    PeerRTC does NOT claim to be "100% anonymous", "untraceable", or "zero server traffic".
                  </p>
                  <ul className="list-disc pl-4 space-y-1 text-[#858585]">
                    <li>Initial signaling requires temporary IP communication with the signaling server.</li>
                    <li>Direct P2P connections reveal your public IP address to your connected peer (inherent to WebRTC).</li>
                    <li>If a TURN relay is required, encrypted packets pass through the TURN relay host.</li>
                    <li>If browser storage is cleared, stored keys and identities are removed permanently.</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-[#252526] border-t border-[#333333] flex items-center justify-between text-xs font-mono text-[#858585] shrink-0">
          <span>PeerRTC Technical Reference</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#37373d] hover:bg-[#45454c] text-white transition-colors"
          >
            Close Notes
          </button>
        </div>
      </div>
    </div>
  );
};
