import React from 'react';
import { LogOut, X, AlertTriangle } from 'lucide-react';

interface CloseSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmClose: () => void;
}

export const CloseSessionModal: React.FC<CloseSessionModalProps> = ({
  isOpen,
  onClose,
  onConfirmClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div 
        className="w-full max-w-md bg-[#252526] border border-[#3e3e42] shadow-2xl rounded-sm overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="close-session-title"
      >
        {/* Header */}
        <div className="px-4 py-3 bg-[#1e1e1e] border-b border-[#333333] flex items-center justify-between">
          <div className="flex items-center gap-2 text-rose-400 font-mono text-xs font-semibold uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" />
            <span id="close-session-title">Close Session Confirmation</span>
          </div>
          <button
            onClick={onClose}
            className="text-[#858585] hover:text-white transition-colors p-1"
            title="Cancel (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-3">
          <h3 className="text-base font-medium text-white">
            Close Session?
          </h3>
          <p className="text-sm text-[#cccccc] leading-relaxed">
            This will disconnect the current peer and close this session.
          </p>
          <div className="p-3 bg-[#1e1e1e] border border-[#333333] rounded-sm text-xs font-mono text-[#858585]">
            <span className="text-emerald-400 font-medium">✓ Safe:</span> Your local conversation history will remain saved.
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#1e1e1e] border-t border-[#333333] flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-sm bg-[#2d2d2d] hover:bg-[#383838] border border-[#3e3e42] text-xs font-mono text-[#cccccc] transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirmClose();
              onClose();
            }}
            className="px-3.5 py-1.5 rounded-sm bg-rose-700 hover:bg-rose-600 text-white text-xs font-mono font-medium flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Close Session</span>
          </button>
        </div>
      </div>
    </div>
  );
};
