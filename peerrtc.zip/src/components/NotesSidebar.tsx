import React, { useEffect } from 'react';
import { BookOpen, X, ShieldAlert, Cpu, Terminal, CheckCircle2, Lock, ArrowRight, Keyboard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NotesSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotesSidebar: React.FC<NotesSidebarProps> = ({ isOpen, onClose }) => {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 cursor-pointer"
            aria-hidden="true"
          />

          {/* Right Sliding Sidebar */}
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="fixed top-0 right-0 bottom-0 w-full sm:w-[540px] md:w-[600px] bg-[#181818] border-l border-[#2e2e2e] shadow-2xl z-50 flex flex-col font-sans text-gray-200"
            role="dialog"
            aria-modal="true"
            aria-labelledby="notes-sidebar-title"
          >
            {/* Header */}
            <div className="h-12 px-5 bg-[#1f1f1f] border-b border-[#2e2e2e] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 font-mono text-xs font-semibold text-gray-100">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <span id="notes-sidebar-title">PeerRTC Technical Reference & Architecture</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="hidden sm:inline-block text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#2a2a2a] text-gray-400 border border-[#383838]">
                  Esc to close
                </span>
                <button
                  onClick={onClose}
                  className="p-1.5 text-gray-400 hover:text-white rounded hover:bg-[#2a2a2a] transition-colors"
                  aria-label="Close notes"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Continuous Scrollable Document Body */}
            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-8 text-sm leading-relaxed text-gray-300">
              
              {/* Keyboard Shortcuts Section */}
              <section className="space-y-3 pb-6 border-b border-[#2e2e2e]">
                <div className="flex items-center gap-2 text-xs font-mono font-semibold uppercase tracking-wider text-sky-400">
                  <Keyboard className="w-4 h-4" />
                  <span>Global Keyboard Shortcuts</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                  <div className="flex items-center justify-between p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a]">
                    <span className="text-gray-300">Quick Command / Search</span>
                    <kbd className="px-1.5 py-0.5 bg-[#2b2b2b] text-sky-300 rounded border border-[#3d3d3d]">Ctrl/⌘ + K</kbd>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a]">
                    <span className="text-gray-300">Send Message / Mail</span>
                    <kbd className="px-1.5 py-0.5 bg-[#2b2b2b] text-sky-300 rounded border border-[#3d3d3d]">Ctrl/⌘ + Enter</kbd>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a]">
                    <span className="text-gray-300">Copy Connection Code</span>
                    <kbd className="px-1.5 py-0.5 bg-[#2b2b2b] text-sky-300 rounded border border-[#3d3d3d]">Ctrl/⌘ + ⇧ + C</kbd>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a]">
                    <span className="text-gray-300">Open Notes & Reference</span>
                    <kbd className="px-1.5 py-0.5 bg-[#2b2b2b] text-sky-300 rounded border border-[#3d3d3d]">Ctrl/⌘ + /</kbd>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a] sm:col-span-2">
                    <span className="text-gray-300">Close Modals / Drawers</span>
                    <kbd className="px-1.5 py-0.5 bg-[#2b2b2b] text-sky-300 rounded border border-[#3d3d3d]">Esc</kbd>
                  </div>
                </div>
              </section>

              {/* 1. What is PeerRTC */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">01.</span> PeerRTC Overview
                </h3>
                <p>
                  PeerRTC is a browser-based, privacy-focused 1-to-1 peer-to-peer (P2P) communication and data-transfer application.
                  It requires zero accounts, no signup, no passwords, and no server-side user tracking. Your peer identity is generated locally
                  in your browser and persisted inside your device&apos;s IndexedDB storage.
                </p>
              </section>

              {/* 2. P2P & WebRTC DataChannels */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">02.</span> P2P WebRTC DataChannels
                </h3>
                <p>
                  All real-time chat messages, mail deliveries, and file transfers travel directly between your browser and your peer&apos;s browser
                  through encrypted <code className="text-xs bg-[#242424] px-1.5 py-0.5 rounded text-sky-300 font-mono">RTCDataChannel</code> pipes.
                </p>
                <p>
                  Data transmitted across WebRTC DataChannels is protected at the transport layer using industry-standard DTLS (Datagram Transport Layer Security)
                  and SRTP encryption. WebRTC mandates end-to-end encryption for all media and data connections out-of-the-box.
                </p>
              </section>

              {/* 3. Signaling Server */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">03.</span> Ephemeral Signaling Server
                </h3>
                <p>
                  WebRTC requires an out-of-band signaling mechanism solely to exchange network metadata (Session Description Protocol / SDP offers, answers,
                  and ICE candidate IP/port pairs) before direct P2P connectivity is established.
                </p>
                <p>
                  The PeerRTC signaling server is strictly ephemeral. It holds session handshake tokens in temporary in-memory session maps and immediately discards
                  them once peers connect. <strong>Chat text, mail messages, and files never pass through or get saved on the signaling server.</strong>
                </p>
              </section>

              {/* 4. TURN Relays */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">04.</span> TURN Fallback Architecture
                </h3>
                <p>
                  When peers are behind symmetric NATs or restrictive corporate firewalls where direct hole-punching fails, standard WebRTC employs a TURN
                  (Traversal Using Relays around NAT) server to relay encrypted packets.
                </p>
                <p>
                  Even when a TURN relay is utilized, traffic remains encrypted via DTLS between the peers; the relay server routes encrypted UDP packets without
                  access to the underlying plaintexts.
                </p>
              </section>

              {/* 5. Privacy Reality & Threat Model */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-amber-400">05.</span> Privacy Reality & Threat Model
                </h3>
                <p>
                  PeerRTC adheres to honest, precise cybersecurity standards. We explicitly do not make false claims such as &quot;100% anonymous&quot;, &quot;untraceable&quot;,
                  or &quot;magic zero-knowledge guarantees&quot;:
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-300 pl-1 text-xs">
                  <li><strong>IP Visibility:</strong> In direct P2P connections, peers necessarily discover each other&apos;s IP addresses to establish direct UDP sockets. If IP masking is required, using a trustworthy VPN or Tor proxy is recommended.</li>
                  <li><strong>Signaling IP:</strong> The signaling server sees the connecting client IP during the initial SDP exchange.</li>
                  <li><strong>Physical Device Security:</strong> IndexedDB messages remain unencrypted at the browser file-system level unless full-disk encryption or browser sandboxing is enabled on your device.</li>
                </ul>
              </section>

              {/* 6. Messages & Delivery States */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">06.</span> 1-to-1 Live Messages
                </h3>
                <p>
                  Instant messaging provides responsive 1-to-1 interaction. Every transmission packet is formatted using compact CBOR (Concise Binary Object Representation)
                  serialization. Delivery states provide verifiable feedback:
                </p>
                <div className="grid grid-cols-3 gap-2 text-xs font-mono pt-1">
                  <div className="p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a] text-center">
                    <span className="text-yellow-400">Sending</span>
                    <p className="text-[10px] text-gray-400 mt-1">In local buffer</p>
                  </div>
                  <div className="p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a] text-center">
                    <span className="text-sky-400">Sent</span>
                    <p className="text-[10px] text-gray-400 mt-1">Dispatched on wire</p>
                  </div>
                  <div className="p-2 rounded bg-[#1f1f1f] border border-[#2a2a2a] text-center">
                    <span className="text-emerald-400">Delivered</span>
                    <p className="text-[10px] text-gray-400 mt-1">Ack received from peer</p>
                  </div>
                </div>
              </section>

              {/* 7. PeerRTC Mail */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">07.</span> PeerRTC Mail
                </h3>
                <p>
                  PeerRTC Mail operates like an asynchronous dispatch station. You can draft structured dispatches with subjects, multi-recipient lists,
                  and file attachments. Mail items are preserved locally in your Sent box and verified in the peer&apos;s Inbox upon delivery.
                </p>
              </section>

              {/* 8. P2P File Transfers */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">08.</span> Chunked File Transfers
                </h3>
                <p>
                  Files of arbitrary size are sliced into 32KB binary chunks and transmitted through WebRTC DataChannels with adaptive backpressure handling.
                  Upon receipt, chunks are assembled directly in browser memory into a safe Blob. <strong>Files are never automatically executed or opened</strong>,
                  preventing client-side payload execution risks.
                </p>
              </section>

              {/* 9. Local Storage */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">09.</span> Local Browser Storage (IndexedDB)
                </h3>
                <p>
                  All application state — including your PRTC address, known peer address book, conversation transcripts, mail queues, and transfer logs —
                  resides in browser-isolated IndexedDB stores. You can inspect your storage usage or completely wipe all local records at any time from Settings.
                </p>
              </section>

              {/* 10. Connection States */}
              <section className="space-y-2">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">10.</span> Connection States
                </h3>
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-gray-500"></span> <strong>Disconnected:</strong> No active WebRTC session</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-yellow-400"></span> <strong>Connecting:</strong> Exchanging SDP offer/answer with peer</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-emerald-400"></span> <strong>Connected:</strong> WebRTC DataChannel open and active</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-amber-400"></span> <strong>Reconnecting:</strong> ICE connection interrupted, retrying</div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-rose-500"></span> <strong>Failed:</strong> ICE candidates exhausted or peer unreachable</div>
                </div>
              </section>

              {/* 11. Built-in Tools */}
              <section className="space-y-2 pb-6">
                <h3 className="font-mono text-sm font-semibold text-gray-100 flex items-center gap-2">
                  <span className="text-sky-400">11.</span> Built-in Cyber & Dev Tools
                </h3>
                <p>
                  PeerRTC includes 8 essential developer utilities that run 100% locally in your browser using Web Crypto Subtle APIs and native JavaScript:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-1 text-gray-300">
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• Hash Generator (SHA-256/384/512)</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• JWT Token Decoder</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• File Metadata & EXIF Parser</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• UUID Generator (v4 & v7)</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• Unix Timestamp Converter</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• Base64 Encoder / Decoder</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• URL Parameter Encoder / Decoder</div>
                  <div className="p-2 bg-[#1f1f1f] rounded border border-[#2a2a2a]">• JSON Formatter & Syntax Validator</div>
                </div>
              </section>

            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
