import React from 'react';
import { 
  Terminal, 
  Network, 
  MessageSquare, 
  Mail, 
  ArrowLeftRight, 
  Wrench,
  ShieldCheck
} from 'lucide-react';

export type NavigationSection = 'home' | 'connections' | 'messages' | 'mail' | 'transfers' | 'tools';

interface SidebarProps {
  activeSection: NavigationSection;
  onSelectSection: (section: NavigationSection) => void;
  unreadMessagesCount: number;
  unreadMailCount: number;
  activeTransfersCount: number;
  connectedCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  unreadMessagesCount,
  unreadMailCount,
  activeTransfersCount,
  connectedCount
}) => {
  const navItems = [
    {
      id: 'home' as NavigationSection,
      label: 'Home',
      icon: Terminal,
      badge: null
    },
    {
      id: 'connections' as NavigationSection,
      label: 'Connections',
      icon: Network,
      badge: connectedCount > 0 ? `${connectedCount}` : null,
      badgeColor: 'bg-emerald-600'
    },
    {
      id: 'messages' as NavigationSection,
      label: 'Messages',
      icon: MessageSquare,
      badge: unreadMessagesCount > 0 ? `${unreadMessagesCount}` : null,
      badgeColor: 'bg-sky-600'
    },
    {
      id: 'mail' as NavigationSection,
      label: 'Mail',
      icon: Mail,
      badge: unreadMailCount > 0 ? `${unreadMailCount}` : null,
      badgeColor: 'bg-indigo-600'
    },
    {
      id: 'transfers' as NavigationSection,
      label: 'Transfers',
      icon: ArrowLeftRight,
      badge: activeTransfersCount > 0 ? `${activeTransfersCount}` : null,
      badgeColor: 'bg-amber-600'
    },
    {
      id: 'tools' as NavigationSection,
      label: 'Tools',
      icon: Wrench,
      badge: null
    }
  ];

  return (
    <>
      {/* Desktop Sidebar: VS Code-inspired compact panel */}
      <aside className="hidden md:flex flex-col w-48 bg-[#181818] border-r border-[#2a2a2a] shrink-0 select-none justify-between">
        <div className="py-2 flex flex-col space-y-0.5">
          <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-gray-400 flex items-center justify-between">
            <span>Explorer</span>
            <span className="text-[9px] text-gray-400">P2P v1.0</span>
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectSection(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-mono transition-colors text-left relative group ${
                  isActive
                    ? 'bg-[#242424] text-gray-100 font-medium before:content-[""] before:absolute before:left-0 before:top-0 before:bottom-0 before:w-0.5 before:bg-sky-400'
                    : 'text-gray-400 hover:bg-[#1f1f1f] hover:text-gray-200'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-gray-400 group-hover:text-gray-300'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full text-white ${item.badgeColor || 'bg-sky-600'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom indicator */}
        <div className="p-3 border-t border-[#262626] text-[11px] font-mono text-gray-400 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[10px]">DataChannel</span>
          </div>
          <span className="text-[10px] text-gray-400">CBOR</span>
        </div>
      </aside>

      {/* Mobile Navigation Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-14 bg-[#181818] border-t border-[#2a2a2a] flex items-center justify-around px-1 z-40 select-none pb-safe">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectSection(item.id)}
              className={`flex flex-col items-center justify-center flex-1 py-1 text-[10px] font-mono transition-colors relative min-h-[44px] ${
                isActive ? 'text-sky-400' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className="relative">
                <Icon className="w-4 h-4 mb-0.5" />
                {item.badge && (
                  <span className="absolute -top-1 -right-2 text-[9px] w-3.5 h-3.5 flex items-center justify-center rounded-full bg-sky-500 text-white font-bold">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="truncate max-w-[56px]">{item.label}</span>
              {isActive && (
                <span className="absolute top-0 left-1/4 right-1/4 h-0.5 bg-sky-400 rounded-full" />
              )}
            </button>
          );
        })}
      </nav>
    </>
  );
};
