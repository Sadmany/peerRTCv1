import React from 'react';
import { 
  Radio, 
  Settings, 
  BookOpen, 
  Search, 
  LogOut, 
  WifiOff, 
  Loader2 
} from 'lucide-react';
import { ConnectionStatus, UserIdentity } from '../types';

interface NavbarProps {
  identity: UserIdentity | null;
  status: ConnectionStatus;
  statusDetail?: string;
  connectedPeer: { peerAddress: string; username: string } | null;
  onOpenNotes: () => void;
  onOpenSettings: () => void;
  onOpenCommandPalette: () => void;
  onRequestCloseSession: () => void;
  onNavigate: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  identity,
  status,
  connectedPeer,
  onOpenNotes,
  onOpenSettings,
  onOpenCommandPalette,
  onRequestCloseSession,
  onNavigate
}) => {
  const getStatusBadge = () => {
    switch (status) {
      case 'connected':
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Connected</span>
          </div>
        );
      case 'connecting':
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-sky-950/70 border border-sky-500/30 text-sky-400 text-xs font-mono">
            <Loader2 className="w-3 h-3 animate-spin text-sky-400" />
            <span>Connecting...</span>
          </div>
        );
      case 'waiting':
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-amber-950/70 border border-amber-500/30 text-amber-400 text-xs font-mono">
            <Radio className="w-3 h-3 animate-pulse text-amber-400" />
            <span>Awaiting peer</span>
          </div>
        );
      case 'reconnecting':
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-amber-950/70 border border-amber-500/30 text-amber-400 text-xs font-mono">
            <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
            <span>Reconnecting</span>
          </div>
        );
      case 'failed':
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-rose-950/70 border border-rose-500/30 text-rose-400 text-xs font-mono">
            <WifiOff className="w-3 h-3 text-rose-400" />
            <span>Failed</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-[#1e1e1e] border border-[#2d2d2d] text-gray-400 text-xs font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-gray-500"></span>
            <span>Standby</span>
          </div>
        );
    }
  };

  return (
    <header className="h-10 bg-[#181818] border-b border-[#2b2b2b] flex items-center justify-between px-3 shrink-0 z-30 select-none">
      {/* Left: Brand & Identity */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 text-gray-200 hover:text-white transition-colors"
          title="PeerRTC Home"
        >
          <div className="w-5 h-5 rounded-xs bg-sky-600 flex items-center justify-center text-white shadow-xs">
            <Radio className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-mono font-bold tracking-tight">
            Peer<span className="text-sky-400">RTC</span>
          </span>
        </button>

        {identity && (
          <div 
            onClick={() => onNavigate('home')}
            className="hidden lg:flex items-center gap-1.5 text-[11px] font-mono text-gray-400 hover:text-gray-200 cursor-pointer transition-colors pl-2 border-l border-[#2e2e2e]"
          >
            <span className="text-gray-300 font-medium">@{identity.username}</span>
            <span className="text-gray-600">/</span>
            <span className="text-gray-400 truncate max-w-[120px]" title={identity.peerAddress}>
              {identity.peerAddress}
            </span>
          </div>
        )}
      </div>

      {/* Middle: Centered Quick Search / Command Palette Input */}
      <div className="flex-1 max-w-lg mx-3 flex items-center justify-center">
        <button
          onClick={onOpenCommandPalette}
          className="w-full max-w-sm flex items-center justify-between px-2.5 py-1 rounded-sm bg-[#222222] hover:bg-[#282828] border border-[#333333] hover:border-[#444444] text-gray-400 hover:text-gray-200 text-xs font-mono transition-all group"
          title="Search or type a command (Ctrl/Cmd + K)"
        >
          <div className="flex items-center gap-2 truncate">
            <Search className="w-3.5 h-3.5 text-gray-400 group-hover:text-sky-400 transition-colors shrink-0" />
            <span className="truncate text-gray-400 group-hover:text-gray-200">
              Search or type a command...
            </span>
          </div>
          <kbd className="hidden sm:inline-flex items-center text-[10px] px-1 py-0.2 rounded bg-[#181818] border border-[#383838] text-gray-400 shrink-0 ml-2">
            Ctrl+K
          </kbd>
        </button>
      </div>

      {/* Right: Connection Status & Editor-Style Clean Action Controls */}
      <div className="flex items-center gap-2 shrink-0">
        {connectedPeer && (
          <div className="hidden md:flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-[#222222] border border-[#333333] text-xs font-mono text-gray-300">
            <span className="text-gray-500">Peer:</span>
            <span className="text-sky-400 font-medium truncate max-w-[100px]">@{connectedPeer.username}</span>
            <button
              onClick={onRequestCloseSession}
              className="text-gray-400 hover:text-rose-400 transition-colors p-0.5 ml-0.5"
              title="Disconnect Session"
            >
              <LogOut className="w-3 h-3" />
            </button>
          </div>
        )}

        <div className="hidden sm:block">
          {getStatusBadge()}
        </div>

        {/* Notes Action */}
        <button
          onClick={onOpenNotes}
          className="flex items-center gap-1 px-2 py-1 rounded-sm text-gray-400 hover:text-gray-100 hover:bg-[#252525] transition-colors text-xs font-mono"
          title="Notes & Architecture (Ctrl/Cmd + /)"
        >
          <BookOpen className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden md:inline">Notes</span>
        </button>

        {/* Settings Action */}
        <button
          onClick={onOpenSettings}
          className="flex items-center gap-1 px-2 py-1 rounded-sm text-gray-400 hover:text-gray-100 hover:bg-[#252525] transition-colors text-xs font-mono"
          title="Settings & Storage"
        >
          <Settings className="w-3.5 h-3.5 text-gray-300" />
          <span className="hidden md:inline">Settings</span>
        </button>
      </div>
    </header>
  );
};
