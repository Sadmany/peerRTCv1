import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Paperclip, 
  ArrowLeft, 
  LogOut, 
  Radio, 
  Code2, 
  FileText, 
  Download, 
  Check, 
  CheckCheck, 
  Clock, 
  Eye, 
  EyeOff
} from 'lucide-react';
import { ChatMessage, ConnectionStatus, UserIdentity } from '../types';

interface MessagesViewProps {
  identity: UserIdentity | null;
  status: ConnectionStatus;
  statusDetail?: string;
  connectedPeer: { peerAddress: string; username: string } | null;
  conversations: Array<{ peerAddress: string; lastMessage?: ChatMessage }>;
  activePeerAddress: string | null;
  messages: ChatMessage[];
  onSelectConversation: (peerAddress: string) => void;
  onSendMessage: (text: string) => void;
  onSendFile: (file: File) => Promise<string>;
  onRequestCloseSession: () => void;
  onBackToConversations: () => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  identity,
  connectedPeer,
  conversations,
  activePeerAddress,
  messages,
  onSelectConversation,
  onSendMessage,
  onSendFile,
  onRequestCloseSession,
  onBackToConversations
}) => {
  const [inputText, setInputText] = useState('');
  const [inspectingMsgId, setInspectingMsgId] = useState<string | null>(null);
  const [isSendingFile, setIsSendingFile] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isScrolledToBottomRef = useRef<boolean>(true);

  // Track if user is scrolled near bottom
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    isScrolledToBottomRef.current = scrollHeight - scrollTop - clientHeight < 80;
  };

  // Scroll to bottom only if user was already at bottom or newly sent
  useEffect(() => {
    if (isScrolledToBottomRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(inputText.trim());
    setInputText('');
    isScrolledToBottomRef.current = true;
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    try {
      setIsSendingFile(true);
      await onSendFile(file);
    } catch (err: any) {
      alert(`File transfer failed: ${err.message}`);
    } finally {
      setIsSendingFile(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const isCurrentPeerConnected = Boolean(
    connectedPeer && activePeerAddress && connectedPeer.peerAddress === activePeerAddress
  );

  const activePeerUser = connectedPeer?.peerAddress === activePeerAddress
    ? connectedPeer.username
    : (conversations.find(c => c.peerAddress === activePeerAddress)?.peerAddress || 'Peer');

  return (
    <div className="flex-1 flex overflow-hidden bg-[#181818] font-sans text-gray-200">
      {/* Conversations Master List (Hidden on mobile when chat is active) */}
      <div className={`w-full md:w-64 bg-[#1e1e1e] border-r border-[#2a2a2a] flex flex-col shrink-0 ${
        activePeerAddress ? 'hidden md:flex' : 'flex'
      }`}>
        <div className="p-3 border-b border-[#2a2a2a] flex items-center justify-between">
          <span className="font-mono text-xs font-semibold text-gray-200 uppercase tracking-wider">
            Conversations
          </span>
          <span className="text-[10px] font-mono text-gray-400">1-to-1</span>
        </div>

        {/* Current Active Connection quick item */}
        {connectedPeer && (
          <div 
            onClick={() => onSelectConversation(connectedPeer.peerAddress)}
            className={`p-3 border-b border-[#2a2a2a] cursor-pointer transition-colors font-mono text-xs ${
              activePeerAddress === connectedPeer.peerAddress
                ? 'bg-[#282828] text-white border-l-2 border-l-sky-400'
                : 'bg-[#1a1a1a] hover:bg-[#222222] text-gray-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 animate-pulse" />
                @{connectedPeer.username}
              </span>
              <span className="text-[10px] text-emerald-400">Live P2P</span>
            </div>
            <div className="text-[10px] text-gray-400 truncate mt-0.5" title={connectedPeer.peerAddress}>
              {connectedPeer.peerAddress}
            </div>
          </div>
        )}

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#262626]">
          {conversations.length === 0 && !connectedPeer ? (
            <div className="p-4 text-center text-gray-400 font-mono text-xs">
              No stored conversations. Connect with a peer to begin chatting.
            </div>
          ) : (
            conversations.map((conv) => {
              const isActive = activePeerAddress === conv.peerAddress;
              const isLive = connectedPeer?.peerAddress === conv.peerAddress;
              return (
                <div
                  key={conv.peerAddress}
                  onClick={() => onSelectConversation(conv.peerAddress)}
                  className={`p-3 cursor-pointer transition-colors font-mono text-xs ${
                    isActive ? 'bg-[#282828] text-white border-l-2 border-l-sky-400' : 'hover:bg-[#222222] text-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-gray-200 truncate max-w-[130px]">
                      {isLive ? `@${connectedPeer?.username}` : conv.lastMessage?.senderUsername ? `@${conv.lastMessage.senderUsername}` : 'Peer'}
                    </span>
                    {conv.lastMessage && (
                      <span className="text-[10px] text-gray-400">
                        {new Date(conv.lastMessage.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-gray-400 truncate mt-0.5">
                    {conv.lastMessage?.text || conv.peerAddress}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 1-to-1 Live Chat Detail Panel */}
      {activePeerAddress ? (
        <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#161616]">
          {/* Top Chat Header */}
          <div className="h-11 bg-[#1e1e1e] border-b border-[#2a2a2a] px-3 sm:px-4 flex items-center justify-between shrink-0 font-mono text-xs">
            <div className="flex items-center gap-2.5">
              <button
                onClick={onBackToConversations}
                className="md:hidden text-gray-400 hover:text-white p-1"
                title="Back to conversations"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white">@{activePeerUser}</span>
                  {isCurrentPeerConnected ? (
                    <span className="px-1.5 py-0.2 rounded-xs bg-emerald-950/80 text-emerald-400 border border-emerald-700/50 text-[10px] flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Connected (P2P)
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.2 rounded-xs bg-[#252525] text-gray-400 text-[10px]">
                      Offline / Transcript
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-gray-400 truncate max-w-[220px] sm:max-w-md" title={activePeerAddress}>
                  {activePeerAddress}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isCurrentPeerConnected && (
                <button
                  onClick={onRequestCloseSession}
                  className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded-xs text-[11px] transition-colors flex items-center gap-1"
                  title="Close current session"
                >
                  <LogOut className="w-3 h-3" />
                  <span className="hidden sm:inline">Disconnect</span>
                </button>
              )}
            </div>
          </div>

          {/* Messages Feed Container */}
          <div 
            ref={scrollContainerRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto p-4 space-y-3 font-mono text-xs"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-gray-400 space-y-2 p-6">
                <div className="w-10 h-10 rounded-full bg-[#1e1e1e] border border-[#2b2b2b] flex items-center justify-center text-sky-400">
                  <Code2 className="w-5 h-5" />
                </div>
                <div className="text-white font-medium">Direct P2P DataChannel Session</div>
                <p className="max-w-sm text-xs text-gray-400">
                  Messages travel directly between browsers via WebRTC DataChannel using CBOR binary serialization. Zero message logs exist on central servers.
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.sender === 'me';
                const isInspecting = inspectingMsgId === msg.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-full`}
                  >
                    {/* Sender & Timestamp */}
                    <div className="flex items-center gap-2 px-1 text-[10px] text-gray-400 mb-1 select-none">
                      <span className="font-semibold text-gray-300">
                        {isMe ? `@${identity?.username || 'You'}` : `@${msg.senderUsername}`}
                      </span>
                      <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                    </div>

                    {/* Bubble Content */}
                    <div className={`p-3 rounded-xs border max-w-xl break-words ${
                      isMe 
                        ? 'bg-[#1b2b3a] border-[#294560] text-gray-100' 
                        : 'bg-[#1e1e1e] border-[#2e2e2e] text-gray-200'
                    }`}>
                      {/* File message card */}
                      {msg.type === 'file' && msg.fileInfo ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <FileText className="w-5 h-5 text-sky-400 shrink-0" />
                            <div className="truncate">
                              <div className="font-semibold text-white truncate">{msg.fileInfo.filename}</div>
                              <div className="text-[10px] text-gray-400">
                                {(msg.fileInfo.size / 1024).toFixed(1)} KB • {msg.fileInfo.mimeType}
                              </div>
                            </div>
                          </div>

                          <div className="flex gap-2 pt-1">
                            {msg.fileInfo.blobUrl && (
                              <a
                                href={msg.fileInfo.blobUrl}
                                download={msg.fileInfo.filename}
                                className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-xs font-mono flex items-center gap-1.5 transition-colors"
                              >
                                <Download className="w-3.5 h-3.5" />
                                <span>Save File</span>
                              </a>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="whitespace-pre-wrap leading-relaxed select-text font-mono text-xs">
                          {msg.text}
                        </div>
                      )}

                      {/* Packet inspection toggle & delivery status */}
                      <div className="mt-2 pt-1.5 border-t border-white/10 flex items-center justify-between text-[10px] text-gray-400 select-none">
                        <button
                          onClick={() => setInspectingMsgId(isInspecting ? null : msg.id)}
                          className="hover:text-gray-200 flex items-center gap-1 text-[10px]"
                          title="Inspect raw transmission packet"
                        >
                          {isInspecting ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          <span>{isInspecting ? 'Hide Packet' : 'Inspect Packet'}</span>
                        </button>

                        {/* Delivery status */}
                        {isMe && (
                          <span className="flex items-center gap-1 text-[10px]">
                            {msg.status === 'delivered' ? (
                              <>
                                <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Delivered</span>
                              </>
                            ) : msg.status === 'sent' ? (
                              <>
                                <Check className="w-3 h-3 text-sky-400" />
                                <span className="text-sky-400">Sent</span>
                              </>
                            ) : (
                              <>
                                <Clock className="w-3 h-3 text-amber-400 animate-pulse" />
                                <span className="text-amber-400">Sending</span>
                              </>
                            )}
                          </span>
                        )}
                      </div>

                      {/* Raw Packet view */}
                      {isInspecting && (
                        <div className="mt-2 p-2 bg-[#121212] border border-[#2e2e2e] rounded-xs font-mono text-[10px] text-emerald-400 overflow-x-auto">
                          <pre>{JSON.stringify({
                            type: msg.type,
                            serialization: 'CBOR',
                            metadata: {
                              id: msg.id,
                              sender: msg.sender,
                              senderUsername: msg.senderUsername,
                              timestamp: msg.timestamp,
                              status: msg.status
                            }
                          }, null, 2)}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Composer at Bottom */}
          <div className="bg-[#1e1e1e] border-t border-[#2a2a2a] p-3 shrink-0">
            <div className="flex items-center justify-between mb-1.5 px-0.5 text-[10px] font-mono text-gray-400">
              <span className="text-gray-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>DataChannel: CBOR binary</span>
              </span>
              <span className="hidden sm:inline text-gray-400">
                <kbd className="px-1 py-0.5 bg-[#252525] border border-[#383838] rounded text-gray-300">Ctrl/⌘ + Enter</kbd> to Send
              </span>
            </div>

            {/* Input Form */}
            <form onSubmit={handleSend} className="flex items-end gap-2">
              <input
                ref={fileInputRef}
                type="file"
                onChange={handleFileSelected}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={!isCurrentPeerConnected || isSendingFile}
                className="p-2.5 rounded-xs bg-[#252525] hover:bg-[#2e2e2e] disabled:opacity-40 border border-[#383838] text-gray-300 hover:text-white transition-colors"
                title="Send File via P2P DataChannel"
              >
                <Paperclip className="w-4 h-4" />
              </button>

              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  isCurrentPeerConnected 
                    ? "Type message... (Ctrl+Enter to send)" 
                    : "Peer is offline. Messages can be drafted and saved locally."
                }
                rows={2}
                className="flex-1 bg-[#161616] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-2 rounded-xs font-mono text-xs resize-none placeholder-gray-600"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="py-2.5 px-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white rounded-xs font-mono text-xs font-semibold transition-colors flex items-center gap-1.5 h-10"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>
      ) : (
        <div className="flex-1 hidden md:flex flex-col items-center justify-center text-center p-6 text-gray-400 font-mono text-xs">
          <div className="w-12 h-12 rounded-full bg-[#1e1e1e] border border-[#2b2b2b] flex items-center justify-center text-sky-400 mb-2">
            <Radio className="w-6 h-6" />
          </div>
          <div className="text-white font-medium text-sm">Select a Conversation</div>
          <p className="max-w-xs mt-1 text-gray-400">
            Choose a peer from the conversations list or establish a new P2P connection to chat.
          </p>
        </div>
      )}
    </div>
  );
};
