import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  Network, 
  PlusCircle, 
  Link as LinkIcon, 
  Copy, 
  Check, 
  RefreshCw, 
  LogOut, 
  Radio, 
  Clock, 
  ArrowRight, 
  User 
} from 'lucide-react';
import { ConnectionStatus, KnownPeer, UserIdentity } from '../types';

interface ConnectionsViewProps {
  identity: UserIdentity | null;
  status: ConnectionStatus;
  statusDetail?: string;
  connectedPeer: { peerAddress: string; username: string } | null;
  activeSessionId: string | null;
  knownPeers: KnownPeer[];
  onCreateSession: (code: string) => Promise<void>;
  onJoinSession: (code: string) => Promise<void>;
  onRequestCloseSession: () => void;
  onOpenChatWithPeer: (peerAddress: string) => void;
}

export const ConnectionsView: React.FC<ConnectionsViewProps> = ({
  status,
  statusDetail,
  connectedPeer,
  activeSessionId,
  knownPeers,
  onCreateSession,
  onJoinSession,
  onRequestCloseSession,
  onOpenChatWithPeer
}) => {
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [joinError, setJoinError] = useState('');

  // Helper to generate clean readable 6-digit session code e.g. 748-291
  const generateNewCode = () => {
    const p1 = Math.floor(100 + Math.random() * 900);
    const p2 = Math.floor(100 + Math.random() * 900);
    return `${p1}-${p2}`;
  };

  // Generate QR code whenever activeSessionId changes
  useEffect(() => {
    if (activeSessionId) {
      const shareUrl = `${window.location.origin}/?session=${activeSessionId}`;
      QRCode.toDataURL(shareUrl, {
        width: 180,
        margin: 1,
        color: {
          dark: '#ffffff',
          light: '#181818'
        }
      })
        .then(url => setQrDataUrl(url))
        .catch(err => console.error('QR generation failed:', err));
    } else {
      setQrDataUrl('');
    }
  }, [activeSessionId]);

  const handleCreateNew = async () => {
    setIsGenerating(true);
    const newCode = generateNewCode();
    await onCreateSession(newCode);
    setIsGenerating(false);
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    setJoinError('');
    const clean = joinCodeInput.trim();
    if (!clean) {
      setJoinError('Please enter a valid session code');
      return;
    }
    try {
      await onJoinSession(clean);
    } catch (err: any) {
      setJoinError(err.message || 'Failed to connect to session');
    }
  };

  const handleCopyCode = () => {
    if (!activeSessionId) return;
    navigator.clipboard.writeText(activeSessionId);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    if (!activeSessionId) return;
    const shareUrl = `${window.location.origin}/?session=${activeSessionId}`;
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 max-w-5xl mx-auto w-full font-sans text-gray-200">
      {/* Title & info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2a2a2a] pb-3 font-mono">
        <div>
          <h2 className="text-base sm:text-lg font-semibold text-white flex items-center gap-2">
            <Network className="w-4 h-4 text-sky-400" />
            <span>P2P Connection Manager</span>
          </h2>
          <p className="text-xs text-gray-400">
            Establish direct, encrypted WebRTC DataChannels using temporary session codes.
          </p>
        </div>

        {connectedPeer && (
          <button
            onClick={onRequestCloseSession}
            className="px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded-xs text-xs transition-colors flex items-center gap-1.5 self-start"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Disconnect Session</span>
          </button>
        )}
      </div>

      {/* Active Connection Banner (if connected or connecting) */}
      {status !== 'disconnected' && (
        <div className={`p-3.5 rounded-sm border font-mono text-xs ${
          status === 'connected'
            ? 'bg-emerald-950/30 border-emerald-700/60 text-emerald-300'
            : status === 'connecting'
            ? 'bg-sky-950/30 border-sky-700/60 text-sky-300'
            : status === 'waiting'
            ? 'bg-amber-950/30 border-amber-700/60 text-amber-300'
            : status === 'reconnecting'
            ? 'bg-amber-950/30 border-amber-700/60 text-amber-300'
            : 'bg-rose-950/30 border-rose-700/60 text-rose-300'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="font-semibold text-sm flex items-center gap-2">
                <Radio className="w-4 h-4 animate-pulse" />
                <span>
                  {status === 'connected' && 'Connected'}
                  {status === 'connecting' && 'Connecting...'}
                  {status === 'waiting' && 'Awaiting Peer Connection...'}
                  {status === 'reconnecting' && 'Reconnecting...'}
                  {status === 'failed' && 'Connection failed.'}
                </span>
              </div>
              <p className="text-[11px] opacity-90">
                {statusDetail || (status === 'connected' ? 'WebRTC DataChannel active. Direct P2P link established.' : 'Negotiating peer route...')}
              </p>
              {connectedPeer && (
                <div className="pt-1 text-gray-200">
                  Peer: <strong className="text-white">@{connectedPeer.username}</strong> ({connectedPeer.peerAddress})
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              {status === 'connected' && (
                <button
                  onClick={() => onOpenChatWithPeer(connectedPeer?.peerAddress || '')}
                  className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xs transition-colors font-medium flex items-center gap-1.5"
                >
                  <span>Open Live Chat</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={onRequestCloseSession}
                className="px-3 py-1.5 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-white rounded-xs transition-colors"
              >
                Disconnect
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Connection Actions Split Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* ACTION A: CREATE CONNECTION */}
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3 font-mono">
            <div className="flex items-center justify-between border-b border-[#2b2b2b] pb-2">
              <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                <PlusCircle className="w-4 h-4 text-sky-400" />
                Host: Create Connection
              </span>
              <span className="text-[10px] text-gray-400">Offer</span>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Generate a session code and QR. Share it with your peer to establish a direct DataChannel.
            </p>

            {activeSessionId ? (
              <div className="bg-[#181818] border border-[#2b2b2b] rounded-sm p-3.5 space-y-3">
                <div className="text-center">
                  <div className="text-[11px] text-gray-400 uppercase tracking-wider">Session Code</div>
                  <div className="text-2xl sm:text-3xl font-bold tracking-widest text-sky-400 my-1 select-all font-mono">
                    {activeSessionId}
                  </div>
                </div>

                {qrDataUrl && (
                  <div className="flex flex-col items-center justify-center p-2 bg-[#141414] rounded-xs border border-[#262626]">
                    <img src={qrDataUrl} alt="PeerRTC Session QR" className="w-32 h-32 rounded-xs" />
                    <span className="text-[10px] text-gray-400 mt-1.5">Scan to connect</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="flex-1 py-1.5 px-2 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-white rounded-xs text-xs transition-colors flex items-center justify-center gap-1.5"
                    title="Copy session code (Ctrl+Shift+C)"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-gray-400" />}
                    <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                  </button>
                  <button
                    onClick={handleCopyLink}
                    className="flex-1 py-1.5 px-2 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-white rounded-xs text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <LinkIcon className="w-3.5 h-3.5 text-gray-400" />}
                    <span>{copiedLink ? 'Copied Link' : 'Copy Link'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-gray-400 text-xs">
                No active session code created.
              </div>
            )}
          </div>

          <button
            onClick={handleCreateNew}
            disabled={isGenerating}
            className="w-full py-2 px-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-xs font-mono text-xs font-semibold transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{activeSessionId ? 'Regenerate Code' : 'Generate Session Code'}</span>
          </button>
        </div>

        {/* ACTION B: JOIN CONNECTION */}
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-3 font-mono">
            <div className="flex items-center justify-between border-b border-[#2b2b2b] pb-2">
              <span className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                <LinkIcon className="w-4 h-4 text-emerald-400" />
                Guest: Join Connection
              </span>
              <span className="text-[10px] text-gray-400">Answer</span>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Enter the session code shared by your peer to initiate the WebRTC handshake automatically.
            </p>

            <form onSubmit={handleJoin} className="space-y-3 pt-2">
              <div>
                <label className="block text-[11px] text-gray-400 uppercase tracking-wider mb-1">
                  Enter Session Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. 748-291"
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value)}
                  className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white px-3 py-2 rounded-xs font-mono text-base tracking-widest uppercase placeholder-gray-600"
                />
              </div>

              {joinError && (
                <div className="p-2 bg-rose-950/40 border border-rose-800 text-rose-300 text-xs rounded-xs">
                  {joinError}
                </div>
              )}

              <button
                type="submit"
                disabled={status === 'connecting'}
                className="w-full py-2 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xs font-mono text-xs font-semibold transition-colors flex items-center justify-center gap-2"
              >
                <LinkIcon className="w-3.5 h-3.5" />
                <span>Connect to Session</span>
              </button>
            </form>
          </div>

          <div className="p-3 bg-[#181818] border border-[#262626] rounded-xs font-mono text-[11px] text-gray-400 space-y-1">
            <span className="text-gray-200 font-semibold">How it works:</span>
            <p>
              The code connects both peers to temporary signaling. Once the direct WebRTC DataChannel opens, the 1-to-1 conversation view launches automatically.
            </p>
          </div>
        </div>
      </div>

      {/* Known / Saved Connections History */}
      <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-[#2b2b2b] pb-2">
          <span className="font-semibold text-gray-200 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-sky-400" />
            Known Peers & Address Book
          </span>
          <span className="text-gray-400 text-[11px]">IndexedDB Storage</span>
        </div>

        {knownPeers.length === 0 ? (
          <div className="py-6 text-center text-gray-400">
            No known peers saved yet. Once you connect with a peer, their address is recorded here for easy reconnection.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {knownPeers.map((peer) => (
              <div
                key={peer.peerAddress}
                className="p-3 bg-[#181818] border border-[#262626] rounded-xs flex items-center justify-between gap-2"
              >
                <div className="truncate">
                  <div className="font-semibold text-white flex items-center gap-1.5">
                    <span>@{peer.username}</span>
                    {connectedPeer?.peerAddress === peer.peerAddress && (
                      <span className="text-[10px] text-emerald-400 font-normal">● Active</span>
                    )}
                  </div>
                  <div className="text-[11px] text-gray-400 truncate max-w-[200px]" title={peer.peerAddress}>
                    {peer.peerAddress}
                  </div>
                  <div className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3" />
                    <span>Seen {new Date(peer.lastSeen).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onOpenChatWithPeer(peer.peerAddress)}
                    className="px-2.5 py-1 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-gray-300 hover:text-white rounded-xs text-[11px] transition-colors"
                  >
                    Chat
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
