import React, { useRef, useState } from 'react';
import { 
  ArrowLeftRight, 
  Upload, 
  Download, 
  FileText, 
  XCircle, 
  CheckCircle, 
  AlertTriangle, 
  HardDrive, 
  Trash2, 
  Plus 
} from 'lucide-react';
import { FileTransferItem, ConnectionStatus } from '../types';

interface TransfersViewProps {
  status: ConnectionStatus;
  connectedPeer: { peerAddress: string; username: string } | null;
  activeTransfers: FileTransferItem[];
  transferHistory: FileTransferItem[];
  onSendFile: (file: File) => Promise<string>;
  onCancelTransfer: (transferId: string) => void;
  onClearHistory: () => Promise<void>;
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  status,
  connectedPeer,
  activeTransfers,
  transferHistory,
  onSendFile,
  onCancelTransfer,
  onClearHistory
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isStartingTransfer, setIsStartingTransfer] = useState(false);

  const handleSelectFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];

    try {
      setIsStartingTransfer(true);
      await onSendFile(file);
    } catch (err: any) {
      alert(`Transfer failed to start: ${err.message}`);
    } finally {
      setIsStartingTransfer(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const renderStatus = (item: FileTransferItem) => {
    switch (item.status) {
      case 'completed':
        return (
          <span className="text-emerald-400 flex items-center gap-1 font-mono text-xs">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Completed</span>
          </span>
        );
      case 'transferring':
        return (
          <span className="text-sky-400 flex items-center gap-1 font-mono text-xs">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
            <span>Transferring...</span>
          </span>
        );
      case 'interrupted':
        return (
          <span className="text-rose-400 flex items-center gap-1 font-mono text-xs">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Interrupted</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="text-amber-400 flex items-center gap-1 font-mono text-xs">
            <XCircle className="w-3.5 h-3.5" />
            <span>Cancelled</span>
          </span>
        );
      case 'failed':
      default:
        return <span className="text-rose-400 font-mono text-xs">Failed</span>;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 max-w-5xl mx-auto w-full font-sans text-gray-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#2a2a2a] pb-4 font-mono">
        <div>
          <h2 className="text-base sm:text-lg font-semibold text-white flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-sky-400" />
            <span>P2P Data & File Transfers</span>
          </h2>
          <p className="text-gray-400 text-xs">
            Direct 32KB binary chunked streaming over WebRTC DataChannels. Safe execution isolation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleSelectFile}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={status !== 'connected' || isStartingTransfer}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white rounded-xs font-semibold flex items-center gap-2 transition-colors text-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Send File to Peer</span>
          </button>
        </div>
      </div>

      {/* Safety Notice Banner */}
      <div className="p-3 bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm text-gray-300 space-y-1 font-mono text-xs">
        <div className="text-white font-semibold flex items-center gap-1.5">
          <HardDrive className="w-4 h-4 text-sky-400" />
          <span>Execution Isolation Guarantee</span>
        </div>
        <p className="text-[11px] text-gray-400">
          PeerRTC never automatically executes or runs received files or scripts. All received transfers remain isolated in browser memory until you explicitly download them.
        </p>
      </div>

      {/* ACTIVE TRANSFERS SECTION */}
      <div className="space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between">
          <span className="text-gray-200 font-semibold uppercase tracking-wider text-[11px]">
            Active Transfers ({activeTransfers.length})
          </span>
          {status !== 'connected' && (
            <span className="text-amber-400 text-[10px]">
              ○ Peer is currently disconnected
            </span>
          )}
        </div>

        {activeTransfers.length === 0 ? (
          <div className="p-6 bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm text-center text-gray-400">
            No transfers currently in progress.
          </div>
        ) : (
          <div className="space-y-3">
            {activeTransfers.map((t) => (
              <div
                key={t.id}
                className="p-4 bg-[#1e1e1e] border border-[#2e2e2e] rounded-sm space-y-2.5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5 truncate">
                    {t.direction === 'upload' ? (
                      <Upload className="w-5 h-5 text-sky-400 shrink-0" />
                    ) : (
                      <Download className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    <div className="truncate">
                      <div className="font-semibold text-white truncate text-sm">{t.filename}</div>
                      <div className="text-[11px] text-gray-400">
                        {(t.size / 1024).toFixed(1)} KB • {t.direction.toUpperCase()} to @{t.peerUsername}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {renderStatus(t)}
                    {t.status === 'in_progress' && (
                      <button
                        onClick={() => onCancelTransfer(t.id)}
                        className="p-1 text-gray-400 hover:text-rose-400 transition-colors"
                        title="Cancel Transfer"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div className="space-y-1">
                  <div className="w-full bg-[#141414] rounded-full h-2 overflow-hidden border border-[#262626]">
                    <div
                      className={`h-full transition-all duration-200 ${
                        t.status === 'interrupted' ? 'bg-rose-500' : 'bg-sky-500'
                      }`}
                      style={{ width: `${t.progress}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-gray-400">
                    <span>{t.progress}% Completed</span>
                    {t.speed && <span>{t.speed}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* TRANSFER HISTORY SECTION */}
      <div className="space-y-3 pt-2 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
          <span className="text-gray-200 font-semibold uppercase tracking-wider text-[11px]">
            Transfer History (IndexedDB Records)
          </span>
          {transferHistory.length > 0 && (
            <button
              onClick={onClearHistory}
              className="text-gray-400 hover:text-rose-400 flex items-center gap-1 text-[11px] transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}
        </div>

        {transferHistory.length === 0 ? (
          <div className="p-6 bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm text-center text-gray-400">
            No completed or past transfer logs recorded.
          </div>
        ) : (
          <div className="divide-y divide-[#262626] bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm overflow-hidden">
            {transferHistory.map((item) => (
              <div
                key={item.id}
                className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#222222] transition-colors"
              >
                <div className="flex items-center gap-3 truncate">
                  <FileText className="w-4 h-4 text-sky-400 shrink-0" />
                  <div className="truncate">
                    <div className="font-medium text-white truncate">{item.filename}</div>
                    <div className="text-[10px] text-gray-400">
                      {(item.size / 1024).toFixed(1)} KB • {item.direction === 'upload' ? `Sent to @${item.peerUsername}` : `Received from @${item.peerUsername}`} • {new Date(item.timestamp).toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  {renderStatus(item)}
                  {item.blobUrl && item.direction === 'download' && (
                    <a
                      href={item.blobUrl}
                      download={item.filename}
                      className="px-2.5 py-1 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-white rounded-xs text-[11px] flex items-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download</span>
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
