import React, { useState } from 'react';
import { 
  PlusCircle, 
  Link, 
  MessageSquare, 
  Mail, 
  Copy, 
  Check, 
  Activity, 
  Network, 
  Radio, 
  User,
  ArrowRight,
  ArrowLeftRight
} from 'lucide-react';
import { UserIdentity, ConnectionStatus, ChatMessage, MailItem, FileTransferItem } from '../types';
import { NavigationSection } from '../components/Sidebar';

interface HomeViewProps {
  identity: UserIdentity | null;
  status: ConnectionStatus;
  statusDetail?: string;
  connectedPeer: { peerAddress: string; username: string } | null;
  activeSessionId: string | null;
  recentMessages: ChatMessage[];
  recentMail: MailItem[];
  recentTransfers: FileTransferItem[];
  onNavigate: (section: NavigationSection) => void;
  onCreateConnection: () => void;
  onJoinConnection: () => void;
  onComposeMail: () => void;
  onRequestCloseSession: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  identity,
  status,
  statusDetail,
  connectedPeer,
  activeSessionId,
  recentMessages,
  recentMail,
  recentTransfers,
  onNavigate,
  onCreateConnection,
  onJoinConnection,
  onComposeMail,
  onRequestCloseSession
}) => {
  const [copiedAddress, setCopiedAddress] = useState(false);

  const handleCopyAddress = () => {
    if (!identity?.peerAddress) return;
    navigator.clipboard.writeText(identity.peerAddress);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 max-w-5xl mx-auto w-full font-sans text-gray-200">
      {/* Top Banner / Identity summary */}
      <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg sm:text-xl font-mono font-bold tracking-tight text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-sky-400"></span>
              PeerRTC Console
            </h1>
            <span className="px-2 py-0.5 rounded-xs bg-[#242424] border border-[#333333] text-[10px] font-mono text-emerald-400">
              WebRTC P2P
            </span>
          </div>
          <p className="text-xs font-mono text-gray-400 mt-1">
            Browser-based 1-to-1 P2P cyber communication and data transmission.
          </p>
        </div>

        {/* Node Address badge */}
        {identity && (
          <div className="bg-[#181818] border border-[#2b2b2b] rounded-sm p-2.5 flex items-center justify-between gap-3 font-mono text-xs max-w-md">
            <div className="truncate">
              <div className="text-[10px] text-gray-400 uppercase tracking-wider">Local Peer Address</div>
              <div className="text-sky-300 font-semibold truncate">{identity.peerAddress}</div>
            </div>
            <button
              onClick={handleCopyAddress}
              className="px-2.5 py-1 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-gray-200 rounded-xs text-[11px] transition-colors flex items-center gap-1 shrink-0"
              title="Copy Address"
            >
              {copiedAddress ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-gray-400" />}
              <span>{copiedAddress ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Identity & Active Connection Status Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Identity Box */}
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 space-y-2.5 font-mono text-xs">
          <div className="flex items-center justify-between text-gray-400 text-[11px] border-b border-[#2b2b2b] pb-2 uppercase tracking-wider">
            <span className="flex items-center gap-1.5 text-gray-200">
              <User className="w-3.5 h-3.5 text-sky-400" />
              Local Browser Profile
            </span>
            <span className="text-emerald-400 font-medium">IndexedDB Ready</span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <div>
              <span className="text-[10px] text-gray-400 block">Username</span>
              <span className="text-white font-semibold text-sm">@{identity?.username || 'Initializing'}</span>
            </div>
            <div>
              <span className="text-[10px] text-gray-400 block">Identity Created</span>
              <span className="text-gray-300 text-xs">
                {identity?.createdAt ? new Date(identity.createdAt).toLocaleDateString() : 'Today'}
              </span>
            </div>
          </div>
          <div className="text-[11px] text-gray-400 pt-1">
            Zero accounts or passwords required. Identity and keys reside in your browser.
          </div>
        </div>

        {/* Active Connection Box */}
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 space-y-2.5 font-mono text-xs">
          <div className="flex items-center justify-between text-gray-400 text-[11px] border-b border-[#2b2b2b] pb-2 uppercase tracking-wider">
            <span className="flex items-center gap-1.5 text-gray-200">
              <Network className="w-3.5 h-3.5 text-emerald-400" />
              Active WebRTC Session
            </span>
            <span>
              {status === 'connected' ? (
                <span className="text-emerald-400 font-semibold">● Connected</span>
              ) : status === 'connecting' ? (
                <span className="text-sky-400">◌ Connecting</span>
              ) : status === 'waiting' ? (
                <span className="text-amber-400">◌ Awaiting Peer</span>
              ) : (
                <span className="text-gray-400">○ Disconnected</span>
              )}
            </span>
          </div>

          {connectedPeer ? (
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-gray-400 block">Connected Peer</span>
                  <span className="text-sky-400 font-semibold text-sm">@{connectedPeer.username}</span>
                  <span className="text-[11px] text-gray-400 block truncate max-w-[200px]">
                    {connectedPeer.peerAddress}
                  </span>
                </div>
                <button
                  onClick={onRequestCloseSession}
                  className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/60 text-rose-300 rounded-xs text-xs transition-colors"
                >
                  Disconnect
                </button>
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => onNavigate('messages')}
                  className="flex-1 py-1 px-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-xs text-center transition-colors font-medium"
                >
                  Open Live Chat
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-2 pt-1">
              <p className="text-gray-400 text-xs">
                {activeSessionId 
                  ? `Session ${activeSessionId} created. Share code or QR to link.` 
                  : statusDetail || 'Establish a direct encrypted WebRTC link with another browser.'}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={onCreateConnection}
                  className="flex-1 py-1.5 px-2 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-gray-200 rounded-xs text-xs transition-colors"
                >
                  Create Connection
                </button>
                <button
                  onClick={onJoinConnection}
                  className="flex-1 py-1.5 px-2 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-gray-200 rounded-xs text-xs transition-colors"
                >
                  Join Connection
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="space-y-2">
        <div className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
          Quick Actions
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={onCreateConnection}
            className="p-3 bg-[#1e1e1e] hover:bg-[#242424] border border-[#2b2b2b] hover:border-sky-500/50 rounded-sm text-left transition-colors flex flex-col justify-between h-22 group"
          >
            <PlusCircle className="w-5 h-5 text-sky-400 group-hover:scale-105 transition-transform" />
            <div>
              <div className="font-mono text-xs font-semibold text-white">New Connection</div>
              <div className="font-mono text-[10px] text-gray-400">Generate session & QR</div>
            </div>
          </button>

          <button
            onClick={onJoinConnection}
            className="p-3 bg-[#1e1e1e] hover:bg-[#242424] border border-[#2b2b2b] hover:border-emerald-500/50 rounded-sm text-left transition-colors flex flex-col justify-between h-22 group"
          >
            <Link className="w-5 h-5 text-emerald-400 group-hover:scale-105 transition-transform" />
            <div>
              <div className="font-mono text-xs font-semibold text-white">Join Session</div>
              <div className="font-mono text-[10px] text-gray-400">Enter code / scan QR</div>
            </div>
          </button>

          <button
            onClick={() => onNavigate('messages')}
            className="p-3 bg-[#1e1e1e] hover:bg-[#242424] border border-[#2b2b2b] hover:border-sky-500/50 rounded-sm text-left transition-colors flex flex-col justify-between h-22 group"
          >
            <MessageSquare className="w-5 h-5 text-sky-400 group-hover:scale-105 transition-transform" />
            <div>
              <div className="font-mono text-xs font-semibold text-white">1-to-1 Chat</div>
              <div className="font-mono text-[10px] text-gray-400">Real-time DataChannel</div>
            </div>
          </button>

          <button
            onClick={onComposeMail}
            className="p-3 bg-[#1e1e1e] hover:bg-[#242424] border border-[#2b2b2b] hover:border-indigo-500/50 rounded-sm text-left transition-colors flex flex-col justify-between h-22 group"
          >
            <Mail className="w-5 h-5 text-indigo-400 group-hover:scale-105 transition-transform" />
            <div>
              <div className="font-mono text-xs font-semibold text-white">Compose Mail</div>
              <div className="font-mono text-[10px] text-gray-400">Dispatch message & files</div>
            </div>
          </button>
        </div>
      </div>

      {/* Recent Activity Panel */}
      <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[#2b2b2b] pb-2 text-xs font-mono">
          <span className="font-semibold text-gray-200 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            Recent Activity
          </span>
          <span className="text-gray-400 text-[11px]">IndexedDB Local Records</span>
        </div>

        {recentMessages.length === 0 && recentMail.length === 0 && recentTransfers.length === 0 ? (
          <div className="py-6 text-center text-xs font-mono text-gray-400 space-y-1">
            <p>No recent communications yet.</p>
            <p className="text-[11px] text-gray-400">
              Create or join a connection to start 1-to-1 chat, mail, or file transfers.
            </p>
          </div>
        ) : (
          <div className="space-y-2 font-mono text-xs">
            {/* Recent Messages list */}
            {recentMessages.slice(0, 3).map((m) => (
              <div 
                key={m.id}
                onClick={() => onNavigate('messages')}
                className="p-2 bg-[#181818] hover:bg-[#222222] border border-[#2a2a2a] rounded-xs flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <MessageSquare className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span className="text-gray-200 font-semibold">@{m.senderUsername}:</span>
                  <span className="text-gray-400 truncate max-w-xs">{m.text}</span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-gray-400 shrink-0">
                  <span className={m.status === 'delivered' ? 'text-emerald-400' : 'text-sky-400'}>
                    {m.status}
                  </span>
                  <span>{new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
            ))}

            {/* Recent Mail items */}
            {recentMail.slice(0, 2).map((mail) => (
              <div 
                key={mail.id}
                onClick={() => onNavigate('mail')}
                className="p-2 bg-[#181818] hover:bg-[#222222] border border-[#2a2a2a] rounded-xs flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <Mail className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="text-gray-200 font-semibold">
                    {mail.direction === 'sent' ? `To: ${mail.to.join(', ')}` : `From: @${mail.fromUsername}`}
                  </span>
                  <span className="text-gray-400 truncate max-w-xs">&quot;{mail.subject}&quot;</span>
                </div>
                <span className="text-[10px] text-gray-400">
                  {new Date(mail.timestamp).toLocaleDateString()}
                </span>
              </div>
            ))}

            {/* Recent File Transfers */}
            {recentTransfers.slice(0, 2).map((transfer) => (
              <div
                key={transfer.id}
                onClick={() => onNavigate('transfers')}
                className="p-2 bg-[#181818] hover:bg-[#222222] border border-[#2a2a2a] rounded-xs flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2 truncate">
                  <ArrowLeftRight className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="text-gray-200 font-semibold truncate max-w-[160px]">{transfer.fileName}</span>
                  <span className="text-gray-400 text-[10px]">({(transfer.fileSize / 1024).toFixed(1)} KB)</span>
                </div>
                <span className="text-[10px] text-gray-400 uppercase">
                  {transfer.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
