import React, { useState, useRef } from 'react';
import { 
  Mail, 
  Inbox, 
  Send, 
  Paperclip, 
  FileText, 
  Check, 
  AlertCircle, 
  Trash2, 
  ArrowLeft, 
  CheckCheck, 
  Download,
  Eye,
  EyeOff
} from 'lucide-react';
import { MailItem, UserIdentity, ConnectionStatus } from '../types';

interface MailViewProps {
  identity: UserIdentity | null;
  status: ConnectionStatus;
  connectedPeer: { peerAddress: string; username: string } | null;
  mailItems: MailItem[];
  onSendMail: (toRecipients: string[], subject: string, body: string, attachment?: File) => Promise<MailItem>;
  onDeleteMail: (id: string) => Promise<void>;
  initialTab?: 'inbox' | 'sent' | 'compose';
}

export const MailView: React.FC<MailViewProps> = ({
  status,
  connectedPeer,
  mailItems,
  onSendMail,
  onDeleteMail,
  initialTab = 'inbox'
}) => {
  const [activeTab, setActiveTab] = useState<'inbox' | 'sent' | 'compose'>(initialTab);
  const [selectedMail, setSelectedMail] = useState<MailItem | null>(null);

  // Compose form state
  const [recipientsInput, setRecipientsInput] = useState<string>(connectedPeer?.username || '');
  const [subjectInput, setSubjectInput] = useState<string>('');
  const [bodyInput, setBodyInput] = useState<string>('');
  const [attachment, setAttachment] = useState<File | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [sendSuccessMessage, setSendSuccessMessage] = useState<string>('');
  const [inspectPayload, setInspectPayload] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const inboxItems = mailItems.filter(m => m.direction === 'inbox');
  const sentItems = mailItems.filter(m => m.direction === 'sent');

  const handleComposeSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const recipients = recipientsInput
      .split(/[,;\s]+/)
      .map(r => r.trim().replace(/^@/, ''))
      .filter(Boolean);

    if (recipients.length === 0) {
      alert('Please enter at least one recipient username or peer address.');
      return;
    }

    if (!subjectInput.trim()) {
      alert('Please enter a subject line.');
      return;
    }

    try {
      setIsSending(true);
      const sentItem = await onSendMail(recipients, subjectInput.trim(), bodyInput, attachment || undefined);
      
      setSendSuccessMessage(
        (sentItem.status || sentItem.deliveryStatus) === 'delivered' 
          ? `Mail successfully delivered directly to ${connectedPeer?.username}!`
          : `Mail stored in local Outbox. Recipient is currently offline.`
      );

      // Reset form
      setRecipientsInput('');
      setSubjectInput('');
      setBodyInput('');
      setAttachment(null);
      if (fileInputRef.current) fileInputRef.current.value = '';

      setTimeout(() => {
        setSendSuccessMessage('');
        setActiveTab('sent');
      }, 1500);
    } catch (err: any) {
      alert(`Send failed: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleComposeSubmit();
    }
  };

  const renderStatusBadge = (item: MailItem) => {
    const status = item.status || item.deliveryStatus;
    switch (status) {
      case 'delivered':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-xs bg-emerald-950/80 text-emerald-400 border border-emerald-700/50 text-[10px]">
            <CheckCheck className="w-3 h-3" />
            <span>Delivered</span>
          </span>
        );
      case 'sent':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-xs bg-sky-950/80 text-sky-400 border border-sky-700/50 text-[10px]">
            <Check className="w-3 h-3" />
            <span>Sent</span>
          </span>
        );
      case 'recipient unavailable':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-xs bg-amber-950/80 text-amber-400 border border-amber-700/50 text-[10px]">
            <AlertCircle className="w-3 h-3" />
            <span>Recipient offline</span>
          </span>
        );
      case 'sending':
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-xs bg-neutral-800 text-neutral-300 border border-neutral-700 text-[10px]">
            <span>Sending...</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-xs bg-rose-950/80 text-rose-400 border border-rose-700/50 text-[10px]">
            <AlertCircle className="w-3 h-3" />
            <span>Failed</span>
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex overflow-hidden bg-[#181818] font-sans text-gray-200">
      {/* Left Mail Sidebar / Master list */}
      <div className={`w-full md:w-80 bg-[#1e1e1e] border-r border-[#2a2a2a] flex flex-col shrink-0 ${
        selectedMail ? 'hidden md:flex' : 'flex'
      }`}>
        {/* Navigation Tabs */}
        <div className="p-3 border-b border-[#2a2a2a] flex items-center justify-between">
          <div className="flex items-center gap-1 bg-[#181818] p-0.5 rounded-xs border border-[#2b2b2b]">
            <button
              onClick={() => { setActiveTab('inbox'); setSelectedMail(null); }}
              className={`px-2.5 py-1 rounded-xs flex items-center gap-1.5 text-xs font-mono transition-colors ${
                activeTab === 'inbox' ? 'bg-[#282828] text-white font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Inbox className="w-3.5 h-3.5" />
              <span>Inbox ({inboxItems.length})</span>
            </button>
            <button
              onClick={() => { setActiveTab('sent'); setSelectedMail(null); }}
              className={`px-2.5 py-1 rounded-xs flex items-center gap-1.5 text-xs font-mono transition-colors ${
                activeTab === 'sent' ? 'bg-[#282828] text-white font-semibold' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>Sent ({sentItems.length})</span>
            </button>
          </div>

          <button
            onClick={() => { setActiveTab('compose'); setSelectedMail(null); }}
            className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-xs font-mono font-semibold flex items-center gap-1 transition-colors"
          >
            <span>Compose</span>
          </button>
        </div>

        {/* List of items */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#262626] font-mono text-xs">
          {activeTab === 'compose' ? (
            <div className="p-4 text-gray-400">
              Composing new P2P Mail. Fill out dispatch parameters on the right.
            </div>
          ) : (
            (activeTab === 'inbox' ? inboxItems : sentItems).length === 0 ? (
              <div className="p-6 text-center text-gray-400">
                {activeTab === 'inbox' ? 'No incoming mail received.' : 'No sent mail recorded.'}
              </div>
            ) : (
              (activeTab === 'inbox' ? inboxItems : sentItems).map((item) => {
                const isSelected = selectedMail?.id === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => setSelectedMail(item)}
                    className={`p-3 cursor-pointer transition-colors space-y-1 ${
                      isSelected ? 'bg-[#282828] text-white border-l-2 border-l-sky-400' : 'hover:bg-[#222222] text-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-white truncate max-w-[140px]">
                        {item.direction === 'inbox' ? `@${item.fromUsername}` : `To: ${item.to.join(', ')}`}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {new Date(item.timestamp).toLocaleDateString()}
                      </span>
                    </div>

                    <div className="font-medium text-xs truncate text-gray-200">
                      {item.subject}
                    </div>

                    <div className="flex items-center justify-between text-[10px] pt-0.5">
                      <span className="text-gray-400 truncate max-w-[150px]">
                        {item.body.substring(0, 32)}...
                      </span>
                      {renderStatusBadge(item)}
                    </div>
                  </div>
                );
              })
            )
          )}
        </div>
      </div>

      {/* Right Detail / Compose Panel */}
      <div className="flex-1 flex flex-col overflow-hidden bg-[#161616]">
        {activeTab === 'compose' ? (
          /* COMPOSE MAIL FORM */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-3xl w-full mx-auto space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-400" />
                <span>New PeerRTC Mail Dispatch</span>
              </h3>
              <span className="text-[10px] text-gray-400">
                P2P Delivery Acknowledgment
              </span>
            </div>

            {sendSuccessMessage && (
              <div className="p-3 bg-emerald-950/50 border border-emerald-700/60 text-emerald-300 rounded-xs flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span>{sendSuccessMessage}</span>
              </div>
            )}

            <form onSubmit={handleComposeSubmit} className="space-y-4">
              {/* Recipients */}
              <div>
                <label className="block text-gray-400 uppercase tracking-wider text-[10px] mb-1">
                  Recipients (Comma or space separated usernames or addresses)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g. ShadowFox, CyberKid, PRTC-NODE-9482"
                    value={recipientsInput}
                    onChange={(e) => setRecipientsInput(e.target.value)}
                    className="flex-1 bg-[#1e1e1e] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white px-3 py-2 rounded-xs font-mono text-xs"
                  />
                  {connectedPeer && (
                    <button
                      type="button"
                      onClick={() => setRecipientsInput(connectedPeer.username)}
                      className="px-2.5 py-2 bg-[#242424] hover:bg-[#2c2c2c] text-emerald-400 border border-[#383838] rounded-xs text-[11px] shrink-0"
                      title="Add connected peer"
                    >
                      + @{connectedPeer.username}
                    </button>
                  )}
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="block text-gray-400 uppercase tracking-wider text-[10px] mb-1">
                  Subject Line
                </label>
                <input
                  type="text"
                  required
                  placeholder="Enter dispatch subject..."
                  value={subjectInput}
                  onChange={(e) => setSubjectInput(e.target.value)}
                  className="w-full bg-[#1e1e1e] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white px-3 py-2 rounded-xs font-mono text-xs"
                />
              </div>

              {/* Body */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-gray-400 uppercase tracking-wider text-[10px]">
                    Message Body
                  </label>
                  <span className="text-[10px] text-gray-400">
                    Ctrl/⌘ + Enter to Send
                  </span>
                </div>
                <textarea
                  rows={8}
                  placeholder="Write dispatch contents..."
                  value={bodyInput}
                  onChange={(e) => setBodyInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-full bg-[#1e1e1e] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs resize-y placeholder-gray-600"
                />
              </div>

              {/* Attachments */}
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={(e) => setAttachment(e.target.files?.[0] || null)}
                  className="hidden"
                />
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 bg-[#1e1e1e] hover:bg-[#252525] border border-[#2f2f2f] text-gray-300 rounded-xs text-xs flex items-center gap-2 transition-colors"
                  >
                    <Paperclip className="w-3.5 h-3.5 text-sky-400" />
                    <span>{attachment ? 'Replace Attachment' : 'Add Attachment'}</span>
                  </button>

                  {attachment && (
                    <div className="flex items-center gap-2 text-sky-300 text-xs">
                      <span>{attachment.name} ({(attachment.size / 1024).toFixed(1)} KB)</span>
                      <button
                        type="button"
                        onClick={() => {
                          setAttachment(null);
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="text-rose-400 hover:text-rose-300"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Notice & Submit */}
              <div className="pt-3 border-t border-[#2a2a2a] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="text-[11px] text-gray-400">
                  {status === 'connected' ? (
                    <span className="text-emerald-400">
                      ✓ Connected peer will receive direct WebRTC delivery confirmation.
                    </span>
                  ) : (
                    <span className="text-amber-400">
                      ◌ Recipient is offline. Delivery will be saved in Outbox.
                    </span>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSending}
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white rounded-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSending ? 'Sending...' : 'Send Mail'}</span>
                </button>
              </div>
            </form>
          </div>
        ) : selectedMail ? (
          /* MAIL DETAIL VIEW */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 max-w-3xl w-full mx-auto space-y-4 font-mono text-xs">
            {/* Header toolbar */}
            <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-3">
              <button
                onClick={() => setSelectedMail(null)}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to list</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={async () => {
                    if (confirm('Delete this mail from local storage?')) {
                      await onDeleteMail(selectedMail.id);
                      setSelectedMail(null);
                    }
                  }}
                  className="p-1.5 text-gray-400 hover:text-rose-400 transition-colors"
                  title="Delete Mail"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Subject and Delivery status */}
            <div className="space-y-1">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {selectedMail.subject}
                </h2>
                {renderStatusBadge(selectedMail)}
              </div>
              <div className="text-[11px] text-gray-400">
                {new Date(selectedMail.timestamp).toLocaleString()}
              </div>
            </div>

            {/* From / To info */}
            <div className="p-3 bg-[#1e1e1e] border border-[#2a2a2a] rounded-xs space-y-1 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-gray-400">From:</span>{' '}
                  <strong className="text-white">@{selectedMail.fromUsername}</strong>{' '}
                  <span className="text-[11px] text-gray-400">({selectedMail.from})</span>
                </div>
                <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-[#161616] text-sky-400 border border-[#2a2a2a]">
                  CBOR Packet
                </span>
              </div>
              <div>
                <span className="text-gray-400">To:</span>{' '}
                <span className="text-gray-200">{selectedMail.to.join(', ')}</span>
              </div>
            </div>

            {/* Body */}
            <div className="p-4 bg-[#1e1e1e] border border-[#2a2a2a] rounded-xs text-gray-200 whitespace-pre-wrap leading-relaxed">
              {selectedMail.body}
            </div>

            {/* Attachment preview / download */}
            {selectedMail.attachments && selectedMail.attachments.length > 0 && (
              <div className="space-y-2">
                <div className="text-[11px] text-gray-400 uppercase tracking-wider">
                  Attachments ({selectedMail.attachments.length})
                </div>
                {selectedMail.attachments.map((att, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-[#1e1e1e] border border-[#2a2a2a] rounded-xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-4 h-4 text-sky-400 shrink-0" />
                      <div className="truncate">
                        <div className="font-semibold text-white truncate">{att.filename}</div>
                        <div className="text-[10px] text-gray-400">{(att.size / 1024).toFixed(1)} KB</div>
                      </div>
                    </div>
                    {att.blobUrl && (
                      <a
                        href={att.blobUrl}
                        download={att.filename}
                        className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-xs flex items-center gap-1.5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Wire packet inspection toggle */}
            <div className="pt-2 border-t border-[#2a2a2a]">
              <button
                onClick={() => setInspectPayload(!inspectPayload)}
                className="text-gray-400 hover:text-white flex items-center gap-1 text-[11px]"
              >
                {inspectPayload ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{inspectPayload ? 'Hide Envelope' : 'Inspect Binary Packet Metadata'}</span>
              </button>

              {inspectPayload && (
                <div className="mt-2 p-3 bg-[#121212] border border-[#2a2a2a] rounded-xs text-emerald-400 text-[10px] overflow-x-auto">
                  <pre>{JSON.stringify({
                    id: selectedMail.id,
                    from: selectedMail.from,
                    fromUsername: selectedMail.fromUsername,
                    to: selectedMail.to,
                    subject: selectedMail.subject,
                    timestamp: selectedMail.timestamp,
                    status: selectedMail.status,
                    attachmentsCount: selectedMail.attachments?.length || 0
                  }, null, 2)}</pre>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 hidden md:flex flex-col items-center justify-center text-center p-6 text-gray-400 font-mono">
            <div className="w-12 h-12 rounded-full bg-[#1e1e1e] border border-[#2a2a2a] flex items-center justify-center text-sky-400 mb-2">
              <Mail className="w-6 h-6" />
            </div>
            <div className="text-white font-medium text-sm">Select a Mail Dispatch</div>
            <p className="max-w-xs mt-1 text-xs text-gray-400">
              Choose a message from your Inbox or Sent items, or compose a new P2P Mail.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
