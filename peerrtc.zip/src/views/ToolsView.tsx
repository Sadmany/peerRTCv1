import React, { useState, useEffect, useRef } from 'react';
import { 
  Wrench, 
  Copy, 
  Check, 
  Trash2, 
  ShieldCheck, 
  Hash as HashIcon, 
  FileCode, 
  FileSearch, 
  MapPin, 
  Camera, 
  Calendar, 
  Clock, 
  Download, 
  Upload, 
  ArrowRightLeft, 
  AlertTriangle,
  Fingerprint,
  Code2
} from 'lucide-react';
import { 
  computeHash, 
  decodeJWT, 
  DecodedJWT, 
  extractFileMetadata, 
  FileMetadataReport, 
  stripImageMetadata,
  generateUUIDs,
  parseTimestamp,
  ParsedTimestamp,
  validateAndFormatJSON,
  JSONValidationResult
} from '../utils/tools';

export const ToolsView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'base64' | 'hex' | 'hash' | 'jwt' | 'metadata' | 'uuid' | 'timestamp' | 'json'>('base64');

  // 1. BASE64 TOOL STATE
  const [b64Mode, setB64Mode] = useState<'encode' | 'decode'>('encode');
  const [b64Input, setB64Input] = useState('');
  const [b64Output, setB64Output] = useState('');
  const [b64Error, setB64Error] = useState('');
  const [b64Copied, setB64Copied] = useState(false);

  useEffect(() => {
    if (!b64Input) {
      setB64Output('');
      setB64Error('');
      return;
    }
    try {
      if (b64Mode === 'encode') {
        const encoded = btoa(unescape(encodeURIComponent(b64Input)));
        setB64Output(encoded);
        setB64Error('');
      } else {
        const decoded = decodeURIComponent(escape(atob(b64Input.trim())));
        setB64Output(decoded);
        setB64Error('');
      }
    } catch {
      setB64Output('');
      setB64Error('Invalid Base64 input string');
    }
  }, [b64Input, b64Mode]);

  // 2. HEX TOOL STATE
  const [hexMode, setHexMode] = useState<'textToHex' | 'hexToText'>('textToHex');
  const [hexInput, setHexInput] = useState('');
  const [hexOutput, setHexOutput] = useState('');
  const [hexError, setHexError] = useState('');
  const [hexCopied, setHexCopied] = useState(false);

  useEffect(() => {
    if (!hexInput) {
      setHexOutput('');
      setHexError('');
      return;
    }
    try {
      if (hexMode === 'textToHex') {
        const bytes = new TextEncoder().encode(hexInput);
        const hex = Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join(' ');
        setHexOutput(hex);
        setHexError('');
      } else {
        const clean = hexInput.replace(/[^0-9a-fA-F]/g, '');
        if (clean.length % 2 !== 0) {
          setHexError('Incomplete hex pairs (odd length)');
          setHexOutput('');
          return;
        }
        const bytes = new Uint8Array(clean.length / 2);
        for (let i = 0; i < clean.length; i += 2) {
          bytes[i / 2] = parseInt(clean.substring(i, i + 2), 16);
        }
        const text = new TextDecoder().decode(bytes);
        setHexOutput(text);
        setHexError('');
      }
    } catch {
      setHexOutput('');
      setHexError('Failed to parse hex values');
    }
  }, [hexInput, hexMode]);

  // 3. HASH TOOL STATE
  const [hashInput, setHashInput] = useState('');
  const [hashAlgo, setHashAlgo] = useState<'SHA-256' | 'SHA-384' | 'SHA-512'>('SHA-256');
  const [hashOutput, setHashOutput] = useState('');
  const [hashCopied, setHashCopied] = useState(false);

  useEffect(() => {
    if (!hashInput) {
      setHashOutput('');
      return;
    }
    computeHash(hashInput, hashAlgo).then(res => setHashOutput(res));
  }, [hashInput, hashAlgo]);

  // 4. JWT TOOL STATE
  const [jwtInput, setJwtInput] = useState('');
  const [decodedJwt, setDecodedJwt] = useState<DecodedJWT | null>(null);

  useEffect(() => {
    if (!jwtInput.trim()) {
      setDecodedJwt(null);
      return;
    }
    const res = decodeJWT(jwtInput);
    setDecodedJwt(res);
  }, [jwtInput]);

  // 5. METADATA TOOL STATE
  const [metaFile, setMetaFile] = useState<File | null>(null);
  const [metaReport, setMetaReport] = useState<FileMetadataReport | null>(null);
  const [isAnalyzingMeta, setIsAnalyzingMeta] = useState(false);
  const [stripStatus, setStripStatus] = useState('');
  const [sanitizedBlobUrl, setSanitizedBlobUrl] = useState<string | null>(null);
  const [sanitizedFilename, setSanitizedFilename] = useState<string>('');
  const metaInputRef = useRef<HTMLInputElement>(null);

  const handleMetaFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMetaFile(file);
    setIsAnalyzingMeta(true);
    setStripStatus('');
    setSanitizedBlobUrl(null);
    try {
      const report = await extractFileMetadata(file);
      setMetaReport(report);
    } catch (err: any) {
      alert(`Metadata analysis failed: ${err.message}`);
    } finally {
      setIsAnalyzingMeta(false);
    }
  };

  const handleStripMetadata = async () => {
    if (!metaFile) return;
    try {
      setStripStatus('Sanitizing file metadata...');
      const { cleanBlob, cleanFilename } = await stripImageMetadata(metaFile);
      const url = URL.createObjectURL(cleanBlob);
      setSanitizedBlobUrl(url);
      setSanitizedFilename(cleanFilename);
      setStripStatus(`Success! Generated clean file: ${cleanFilename} (${cleanBlob.size} bytes).`);
    } catch (err: any) {
      setStripStatus(`Stripping failed: ${err.message}`);
    }
  };

  // 6. UUID TOOL STATE
  const [uuidVersion, setUuidVersion] = useState<'v4' | 'v7'>('v4');
  const [uuidCount, setUuidCount] = useState<number>(5);
  const [uuidUppercase, setUuidUppercase] = useState(false);
  const [uuidHyphens, setUuidHyphens] = useState(true);
  const [generatedUuids, setGeneratedUuids] = useState<string[]>([]);
  const [uuidCopied, setUuidCopied] = useState(false);

  const handleGenerateUuids = () => {
    const list = generateUUIDs(uuidCount, uuidVersion, uuidUppercase, uuidHyphens);
    setGeneratedUuids(list);
  };

  useEffect(() => {
    handleGenerateUuids();
  }, [uuidVersion, uuidCount, uuidUppercase, uuidHyphens]);

  // 7. TIMESTAMP TOOL STATE
  const [tsInput, setTsInput] = useState<string>(Math.floor(Date.now() / 1000).toString());
  const [parsedTs, setParsedTs] = useState<ParsedTimestamp | null>(parseTimestamp(Date.now()));
  const [tsCopied, setTsCopied] = useState(false);

  useEffect(() => {
    if (!tsInput.trim()) {
      setParsedTs(null);
      return;
    }
    const res = parseTimestamp(tsInput);
    setParsedTs(res);
  }, [tsInput]);

  // 8. JSON FORMATTER STATE
  const [jsonInput, setJsonInput] = useState<string>('{\n  "service": "PeerRTC",\n  "transport": "WebRTC DataChannel",\n  "serialization": "CBOR",\n  "verified": true\n}');
  const [jsonIndent, setJsonIndent] = useState<number>(2);
  const [jsonResult, setJsonResult] = useState<JSONValidationResult | null>(null);
  const [jsonCopied, setJsonCopied] = useState(false);

  useEffect(() => {
    if (!jsonInput.trim()) {
      setJsonResult(null);
      return;
    }
    const res = validateAndFormatJSON(jsonInput, jsonIndent);
    setJsonResult(res);
  }, [jsonInput, jsonIndent]);

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 max-w-5xl mx-auto w-full font-sans text-gray-200">
      {/* Header */}
      <div className="border-b border-[#2a2a2a] pb-3 font-mono">
        <h2 className="text-base sm:text-lg font-semibold text-white flex items-center gap-2">
          <Wrench className="w-4 h-4 text-sky-400" />
          <span>Cyber & Developer Tools</span>
        </h2>
        <p className="text-gray-400 text-xs mt-0.5">
          100% local in-browser utilities. Zero network transmission.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 bg-[#1e1e1e] p-1 rounded-sm border border-[#2b2b2b] overflow-x-auto text-xs font-mono">
        {[
          { id: 'base64', label: 'Base64' },
          { id: 'hex', label: 'Hexadecimal' },
          { id: 'hash', label: 'Hash Digest' },
          { id: 'jwt', label: 'JWT Inspector' },
          { id: 'metadata', label: 'EXIF / Metadata' },
          { id: 'uuid', label: 'UUID (v4/v7)' },
          { id: 'timestamp', label: 'Timestamp' },
          { id: 'json', label: 'JSON Formatter' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-xs transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-[#282828] text-white font-semibold border border-[#383838]'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: BASE64 */}
      {activeTab === 'base64' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white">Base64 Encoder / Decoder</span>
            <div className="flex items-center gap-1 bg-[#141414] p-0.5 rounded-xs border border-[#262626]">
              <button
                onClick={() => setB64Mode('encode')}
                className={`px-2.5 py-0.5 rounded-xs text-[11px] ${
                  b64Mode === 'encode' ? 'bg-[#252525] text-white font-semibold' : 'text-gray-400'
                }`}
              >
                Encode
              </button>
              <button
                onClick={() => setB64Mode('decode')}
                className={`px-2.5 py-0.5 rounded-xs text-[11px] ${
                  b64Mode === 'decode' ? 'bg-[#252525] text-white font-semibold' : 'text-gray-400'
                }`}
              >
                Decode
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
              {b64Mode === 'encode' ? 'Plaintext Input' : 'Base64 Encoded Input'}
            </label>
            <textarea
              rows={4}
              value={b64Input}
              onChange={(e) => setB64Input(e.target.value)}
              placeholder={b64Mode === 'encode' ? 'Enter string to encode...' : 'Enter Base64 string to decode...'}
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs"
            />
          </div>

          {b64Error && (
            <div className="p-2 bg-rose-950/40 border border-rose-800 text-rose-300 rounded-xs text-[11px]">
              {b64Error}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
                Output
              </label>
              {b64Output && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(b64Output);
                    setB64Copied(true);
                    setTimeout(() => setB64Copied(false), 2000);
                  }}
                  className="text-sky-400 hover:text-sky-300 flex items-center gap-1 text-[11px]"
                >
                  {b64Copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{b64Copied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            <textarea
              readOnly
              rows={4}
              value={b64Output}
              placeholder="Result will appear automatically..."
              className="w-full bg-[#141414] border border-[#262626] text-gray-200 p-3 rounded-xs font-mono text-xs"
            />
          </div>
        </div>
      )}

      {/* TAB 2: HEX */}
      {activeTab === 'hex' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white">Hexadecimal Converter</span>
            <div className="flex items-center gap-1 bg-[#141414] p-0.5 rounded-xs border border-[#262626]">
              <button
                onClick={() => setHexMode('textToHex')}
                className={`px-2.5 py-0.5 rounded-xs text-[11px] ${
                  hexMode === 'textToHex' ? 'bg-[#252525] text-white font-semibold' : 'text-gray-400'
                }`}
              >
                Text → Hex
              </button>
              <button
                onClick={() => setHexMode('hexToText')}
                className={`px-2.5 py-0.5 rounded-xs text-[11px] ${
                  hexMode === 'hexToText' ? 'bg-[#252525] text-white font-semibold' : 'text-gray-400'
                }`}
              >
                Hex → Text
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
              {hexMode === 'textToHex' ? 'Text Input' : 'Hexadecimal Input'}
            </label>
            <textarea
              rows={4}
              value={hexInput}
              onChange={(e) => setHexInput(e.target.value)}
              placeholder={hexMode === 'textToHex' ? 'Enter string...' : 'e.g. 48 65 6c 6c 6f'}
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs"
            />
          </div>

          {hexError && (
            <div className="p-2 bg-rose-950/40 border border-rose-800 text-rose-300 rounded-xs text-[11px]">
              {hexError}
            </div>
          )}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
                Output
              </label>
              {hexOutput && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(hexOutput);
                    setHexCopied(true);
                    setTimeout(() => setHexCopied(false), 2000);
                  }}
                  className="text-sky-400 hover:text-sky-300 flex items-center gap-1 text-[11px]"
                >
                  {hexCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{hexCopied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            <textarea
              readOnly
              rows={4}
              value={hexOutput}
              placeholder="Hexadecimal result..."
              className="w-full bg-[#141414] border border-[#262626] text-gray-200 p-3 rounded-xs font-mono text-xs"
            />
          </div>
        </div>
      )}

      {/* TAB 3: HASH DIGEST */}
      {activeTab === 'hash' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <HashIcon className="w-4 h-4 text-sky-400" />
              Cryptographic Hash Generator
            </span>
            <div className="flex items-center gap-1 bg-[#141414] p-0.5 rounded-xs border border-[#262626]">
              {(['SHA-256', 'SHA-384', 'SHA-512'] as const).map((algo) => (
                <button
                  key={algo}
                  onClick={() => setHashAlgo(algo)}
                  className={`px-2 py-0.5 rounded-xs text-[11px] ${
                    hashAlgo === algo ? 'bg-[#252525] text-white font-semibold' : 'text-gray-400'
                  }`}
                >
                  {algo}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
              Input String / Payload
            </label>
            <textarea
              rows={4}
              value={hashInput}
              onChange={(e) => setHashInput(e.target.value)}
              placeholder="Enter text to compute cryptographic digest..."
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
                {hashAlgo} Digest (Hex)
              </label>
              {hashOutput && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(hashOutput);
                    setHashCopied(true);
                    setTimeout(() => setHashCopied(false), 2000);
                  }}
                  className="text-sky-400 hover:text-sky-300 flex items-center gap-1 text-[11px]"
                >
                  {hashCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{hashCopied ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs text-emerald-400 font-mono text-xs break-all select-all">
              {hashOutput || 'Awaiting input...'}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: JWT INSPECTOR */}
      {activeTab === 'jwt' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white">JWT Token Inspector</span>
            <p className="text-gray-400 text-[11px] mt-0.5">
              Decodes JWT header, claims, issued/expiration timestamps, and payload offline.
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
              Encoded JWT Token
            </label>
            <textarea
              rows={3}
              value={jwtInput}
              onChange={(e) => setJwtInput(e.target.value)}
              placeholder="Paste JWT string (eyJhbGciOi...)"
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs"
            />
          </div>

          {decodedJwt && (
            <div className="space-y-3">
              {decodedJwt.validFormat ? (
                <>
                  {decodedJwt.isExpired !== undefined && (
                    <div className={`p-2.5 rounded-xs border text-xs flex items-center gap-2 ${
                      decodedJwt.isExpired 
                        ? 'bg-rose-950/40 border-rose-800 text-rose-300' 
                        : 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
                    }`}>
                      <span>Token Status: <strong>{decodedJwt.isExpired ? 'EXPIRED' : 'ACTIVE / VALID'}</strong></span>
                      {decodedJwt.expiresAt && (
                        <span className="text-[11px] opacity-80">(Expires: {decodedJwt.expiresAt})</span>
                      )}
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <span className="text-[#e06c75] font-semibold text-[11px]">Header</span>
                      <pre className="p-3 bg-[#141414] border border-[#262626] rounded-xs text-[#e06c75] overflow-x-auto text-[11px]">
                        {JSON.stringify(decodedJwt.header, null, 2)}
                      </pre>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[#98c379] font-semibold text-[11px]">Payload Claims</span>
                      <pre className="p-3 bg-[#141414] border border-[#262626] rounded-xs text-[#98c379] overflow-x-auto text-[11px]">
                        {JSON.stringify(decodedJwt.payload, null, 2)}
                      </pre>
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-3 bg-rose-950/40 border border-rose-800 text-rose-300 rounded-xs">
                  {decodedJwt.error || 'Invalid JWT structure'}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: EXIF / METADATA */}
      {activeTab === 'metadata' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white">File EXIF & Metadata Analyzer</span>
            <p className="text-gray-400 text-[11px] mt-0.5">
              Inspect hidden EXIF, camera, GPS, and creation timestamps, or strip metadata before sharing.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <input
              ref={metaInputRef}
              type="file"
              onChange={handleMetaFileSelect}
              className="hidden"
            />
            <button
              onClick={() => metaInputRef.current?.click()}
              className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xs font-semibold flex items-center gap-2 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Select File to Analyze</span>
            </button>
            {metaFile && (
              <span className="text-gray-300 text-xs truncate max-w-xs">
                {metaFile.name} ({(metaFile.size / 1024).toFixed(1)} KB)
              </span>
            )}
          </div>

          {metaReport && (
            <div className="space-y-3 pt-2">
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1 text-xs">
                <div className="text-white font-semibold">General Properties</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <div>
                    <span className="text-gray-400 block">Filename:</span>
                    <span className="text-white truncate block">{metaReport.filename}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">MIME:</span>
                    <span className="text-white">{metaReport.mimeType || 'unknown'}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Size:</span>
                    <span className="text-white">{metaReport.formattedSize}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">SHA-256:</span>
                    <span className="text-emerald-400 truncate block">{metaReport.sha256Checksum?.substring(0, 16)}...</span>
                  </div>
                </div>
              </div>

              {/* Strip metadata button */}
              <div className="p-3.5 bg-[#181818] border border-[#2b2b2b] rounded-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Privacy Sanitizer</span>
                  </div>
                  <p className="text-gray-400 text-[11px] mt-0.5">
                    Re-render image to completely strip EXIF, GPS coordinates, and camera serial numbers.
                  </p>
                </div>
                <button
                  onClick={handleStripMetadata}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xs font-semibold shrink-0"
                >
                  Strip Metadata
                </button>
              </div>

              {stripStatus && (
                <div className="p-3 bg-[#141414] border border-[#262626] text-xs text-gray-200 rounded-xs flex items-center justify-between">
                  <span>{stripStatus}</span>
                  {sanitizedBlobUrl && (
                    <a
                      href={sanitizedBlobUrl}
                      download={sanitizedFilename}
                      className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-xs font-semibold flex items-center gap-1.5 ml-2 shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Clean File</span>
                    </a>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 6: UUID GENERATOR */}
      {activeTab === 'uuid' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2a2a2a] pb-2">
            <div>
              <span className="font-semibold text-white flex items-center gap-1.5">
                <Fingerprint className="w-4 h-4 text-sky-400" />
                Cryptographic UUID Generator
              </span>
              <p className="text-gray-400 text-[11px] mt-0.5">
                Generate random v4 or timestamp-ordered v7 UUIDs.
              </p>
            </div>
            <button
              onClick={handleGenerateUuids}
              className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs font-semibold text-xs"
            >
              Generate New
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-gray-400 block text-[11px] mb-1">Version</label>
              <select
                value={uuidVersion}
                onChange={(e) => setUuidVersion(e.target.value as any)}
                className="w-full bg-[#181818] border border-[#2f2f2f] text-white p-1.5 rounded-xs"
              >
                <option value="v4">UUID v4 (Random)</option>
                <option value="v7">UUID v7 (Time-Ordered)</option>
              </select>
            </div>

            <div>
              <label className="text-gray-400 block text-[11px] mb-1">Count</label>
              <select
                value={uuidCount}
                onChange={(e) => setUuidCount(Number(e.target.value))}
                className="w-full bg-[#181818] border border-[#2f2f2f] text-white p-1.5 rounded-xs"
              >
                <option value={1}>1 UUID</option>
                <option value={5}>5 UUIDs</option>
                <option value={10}>10 UUIDs</option>
                <option value={25}>25 UUIDs</option>
              </select>
            </div>

            <div className="flex items-center gap-2 pt-5">
              <input
                type="checkbox"
                id="hyphens"
                checked={uuidHyphens}
                onChange={(e) => setUuidHyphens(e.target.checked)}
                className="rounded-xs"
              />
              <label htmlFor="hyphens" className="text-gray-300 text-[11px]">Hyphens</label>
            </div>

            <div className="flex items-center gap-2 pt-5">
              <input
                type="checkbox"
                id="uppercase"
                checked={uuidUppercase}
                onChange={(e) => setUuidUppercase(e.target.checked)}
                className="rounded-xs"
              />
              <label htmlFor="uppercase" className="text-gray-300 text-[11px]">Uppercase</label>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-[11px] uppercase tracking-wider">Generated UUIDs</span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedUuids.join('\n'));
                  setUuidCopied(true);
                  setTimeout(() => setUuidCopied(false), 2000);
                }}
                className="text-sky-400 hover:text-sky-300 flex items-center gap-1 text-[11px]"
              >
                {uuidCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{uuidCopied ? 'Copied All' : 'Copy All'}</span>
              </button>
            </div>
            <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1.5">
              {generatedUuids.map((id, idx) => (
                <div key={idx} className="flex items-center justify-between text-gray-200 hover:text-white">
                  <span className="select-all">{id}</span>
                  <button
                    onClick={() => navigator.clipboard.writeText(id)}
                    className="text-gray-400 hover:text-sky-400"
                    title="Copy this UUID"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: TIMESTAMP CONVERTER */}
      {activeTab === 'timestamp' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-400" />
              Unix Timestamp & ISO Converter
            </span>
            <button
              onClick={() => setTsInput(Math.floor(Date.now() / 1000).toString())}
              className="px-2.5 py-1 bg-[#252525] hover:bg-[#2e2e2e] border border-[#383838] text-white rounded-xs text-[11px]"
            >
              Set Current Time
            </button>
          </div>

          <div className="space-y-2">
            <label className="text-gray-400 block text-[11px] uppercase tracking-wider">
              Input Timestamp (Unix seconds, milliseconds, or ISO-8601)
            </label>
            <input
              type="text"
              value={tsInput}
              onChange={(e) => setTsInput(e.target.value)}
              placeholder="e.g. 1773350000 or 2026-03-12T12:00:00Z"
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-2.5 rounded-xs"
            />
          </div>

          {parsedTs ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1">
                <span className="text-gray-400 text-[10px] block uppercase">Unix Seconds</span>
                <div className="text-sky-400 font-semibold text-sm select-all">{parsedTs.unixSeconds}</div>
              </div>
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1">
                <span className="text-gray-400 text-[10px] block uppercase">Unix Milliseconds</span>
                <div className="text-sky-400 font-semibold text-sm select-all">{parsedTs.unixMillis}</div>
              </div>
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1 sm:col-span-2">
                <span className="text-gray-400 text-[10px] block uppercase">ISO 8601 (UTC)</span>
                <div className="text-emerald-400 font-semibold text-xs select-all">{parsedTs.iso8601}</div>
              </div>
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1">
                <span className="text-gray-400 text-[10px] block uppercase">Local Time</span>
                <div className="text-gray-200 text-xs">{parsedTs.localString}</div>
              </div>
              <div className="p-3 bg-[#141414] border border-[#262626] rounded-xs space-y-1">
                <span className="text-gray-400 text-[10px] block uppercase">Relative Offset</span>
                <div className="text-gray-200 text-xs">{parsedTs.relative}</div>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-rose-950/40 border border-rose-800 text-rose-300 rounded-xs">
              Unable to parse timestamp format.
            </div>
          )}
        </div>
      )}

      {/* TAB 8: JSON FORMATTER */}
      {activeTab === 'json' && (
        <div className="bg-[#1e1e1e] border border-[#2b2b2b] rounded-sm p-4 sm:p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-[#2a2a2a] pb-2">
            <span className="font-semibold text-white flex items-center gap-1.5">
              <Code2 className="w-4 h-4 text-sky-400" />
              JSON Formatter & Validator
            </span>
            <div className="flex items-center gap-2">
              <select
                value={jsonIndent}
                onChange={(e) => setJsonIndent(Number(e.target.value))}
                className="bg-[#181818] border border-[#2f2f2f] text-white p-1 rounded-xs text-[11px]"
              >
                <option value={2}>2 Spaces</option>
                <option value={4}>4 Spaces</option>
              </select>
              {jsonResult?.isValid && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(jsonResult.formatted || '');
                    setJsonCopied(true);
                    setTimeout(() => setJsonCopied(false), 2000);
                  }}
                  className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-xs text-[11px]"
                >
                  {jsonCopied ? 'Copied' : 'Copy Formatted'}
                </button>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <textarea
              rows={8}
              value={jsonInput}
              onChange={(e) => setJsonInput(e.target.value)}
              placeholder="Paste JSON payload here..."
              className="w-full bg-[#181818] border border-[#2f2f2f] focus:border-sky-500 focus:outline-hidden text-white p-3 rounded-xs font-mono text-xs leading-relaxed"
            />
          </div>

          {jsonResult && (
            <div className="space-y-2">
              {jsonResult.isValid ? (
                <div className="p-2.5 bg-emerald-950/40 border border-emerald-800 text-emerald-300 rounded-xs flex items-center justify-between text-[11px]">
                  <span>✓ Valid JSON Structure</span>
                  <span>Formatted size: {jsonResult.sizeAfterBytes} bytes</span>
                </div>
              ) : (
                <div className="p-2.5 bg-rose-950/40 border border-rose-800 text-rose-300 rounded-xs text-[11px]">
                  <span>✕ {jsonResult.error}</span>
                  {jsonResult.line && (
                    <span className="ml-2 font-semibold">(Line {jsonResult.line}, Col {jsonResult.column})</span>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
