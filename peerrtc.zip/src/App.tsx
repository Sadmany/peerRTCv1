import React, { useState, useEffect, useRef } from 'react';
import { 
  UserIdentity, 
  AppSettings, 
  ConnectionStatus, 
  ChatMessage, 
  MailItem, 
  FileTransferItem, 
  KnownPeer 
} from './types';
import { 
  getOrCreateIdentity, 
  updateIdentityUsername, 
  resetIdentityInDB,
  getSettings, 
  saveSettings, 
  getChatMessagesForPeer, 
  saveChatMessage, 
  getAllKnownPeers, 
  saveKnownPeer, 
  getMailItems, 
  saveMail, 
  deleteMail,
  getFileTransfers, 
  saveFileTransfer, 
  clearHistory, 
  clearAllData 
} from './utils/storage';
import { WebRTCManager } from './utils/webrtc';
import { Navbar } from './components/Navbar';
import { Sidebar, NavigationSection } from './components/Sidebar';
import { CommandPalette } from './components/CommandPalette';
import { CloseSessionModal } from './components/CloseSessionModal';
import { NotesSidebar } from './components/NotesSidebar';
import { SettingsModal } from './components/SettingsModal';
import { HomeView } from './views/HomeView';
import { ConnectionsView } from './views/ConnectionsView';
import { MessagesView } from './views/MessagesView';
import { MailView } from './views/MailView';
import { TransfersView } from './views/TransfersView';
import { ToolsView } from './views/ToolsView';

export default function App() {
  // Application State
  const [identity, setIdentity] = useState<UserIdentity | null>(null);
  const [settings, setSettings] = useState<AppSettings>({
    autoReconnect: true,
    stripMetadataOnTransfer: true,
    iceServers: [
      'stun:stun.l.google.com:19302',
      'stun:stun1.l.google.com:19302',
      'stun:stun.cloudflare.com:3478'
    ]
  });

  // Navigation & UI Modals
  const [activeSection, setActiveSection] = useState<NavigationSection>('home');
  const [isNotesOpen, setIsNotesOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [isCloseSessionOpen, setIsCloseSessionOpen] = useState<boolean>(false);
  const [copyToast, setCopyToast] = useState<string | null>(null);

  // WebRTC Connection State
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [statusDetail, setStatusDetail] = useState<string>('');
  const [connectedPeer, setConnectedPeer] = useState<{ peerAddress: string; username: string } | null>(null);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  // Data Collections
  const [knownPeers, setKnownPeers] = useState<KnownPeer[]>([]);
  const [activePeerAddress, setActivePeerAddress] = useState<string | null>(null);
  const [activePeerMessages, setActivePeerMessages] = useState<ChatMessage[]>([]);
  const [mailItems, setMailItems] = useState<MailItem[]>([]);
  const [activeTransfers, setActiveTransfers] = useState<FileTransferItem[]>([]);
  const [transferHistory, setTransferHistory] = useState<FileTransferItem[]>([]);

  // Badges & Counters
  const [unreadMessagesCount, setUnreadMessagesCount] = useState<number>(0);
  const [unreadMailCount, setUnreadMailCount] = useState<number>(0);

  // WebRTC Manager Ref
  const webrtcRef = useRef<WebRTCManager | null>(null);

  // Initialize Identity, Settings & WebRTC Manager on Mount
  useEffect(() => {
    let mounted = true;

    async function init() {
      try {
        const id = await getOrCreateIdentity();
        const loadedSettings = await getSettings();
        const peers = await getAllKnownPeers();
        const mail = await getMailItems();
        const transfers = await getFileTransfers();

        if (!mounted) return;

        setIdentity(id);
        if (loadedSettings) {
          setSettings(loadedSettings);
        }
        setKnownPeers(peers);
        setMailItems(mail);
        setTransferHistory(transfers);

        // Instantiate WebRTC Manager
        const manager = new WebRTCManager({
          onStatusChange: (newStatus, detail) => {
            setStatus(newStatus);
            setStatusDetail(detail || '');
            if (newStatus === 'disconnected') {
              setConnectedPeer(null);
            }
          },
          onPeerInfo: (peer) => {
            setConnectedPeer(peer);
            setActivePeerAddress(peer.peerAddress);

            // Record into known peers
            saveKnownPeer({
              peerAddress: peer.peerAddress,
              username: peer.username,
              lastSeen: Date.now()
            }).then(() => getAllKnownPeers().then(setKnownPeers));

            // Automatically switch to messages view if user is in home or connections view
            setActiveSection((prev) => (prev === 'connections' ? 'messages' : prev));
          },
          onMessage: async (msg) => {
            await saveChatMessage(msg);
            setActivePeerAddress((curr) => {
              if (curr === msg.conversationId || curr === msg.peerAddress) {
                setActivePeerMessages((prev) => [...prev, msg]);
              } else {
                setUnreadMessagesCount((prev) => prev + 1);
              }
              return curr;
            });
          },
          onMail: async (mailItem) => {
            await saveMail(mailItem);
            const allMail = await getMailItems();
            setMailItems(allMail);
            setUnreadMailCount((prev) => prev + 1);
          },
          onTransferProgress: (transfer) => {
            setActiveTransfers((prev) => {
              const existing = prev.find((t) => t.id === transfer.id);
              if (existing) {
                return prev.map((t) => (t.id === transfer.id ? transfer : t));
              }
              return [...prev, transfer];
            });
          },
          onTransferComplete: async (transfer) => {
            await saveFileTransfer(transfer);
            setActiveTransfers((prev) => prev.filter((t) => t.id !== transfer.id));
            const history = await getFileTransfers();
            setTransferHistory(history);
          }
        });

        manager.setIdentity(id.peerAddress, id.username);
        if (loadedSettings?.iceServers) {
          manager.setIceServers(loadedSettings.iceServers);
        }
        webrtcRef.current = manager;

        // Check URL for session query param (e.g. ?session=749-182)
        const urlParams = new URLSearchParams(window.location.search);
        const sessionFromUrl = urlParams.get('session');
        if (sessionFromUrl) {
          manager.joinSession(sessionFromUrl, id.peerAddress, id.username);
          setActiveSessionId(sessionFromUrl);
          setActiveSection('connections');
        }
      } catch (err) {
        console.error('PeerRTC initialization error:', err);
      }
    }

    init();

    return () => {
      mounted = false;
      webrtcRef.current?.closeSession();
    };
  }, []);

  // Whenever activePeerAddress changes, load its messages
  useEffect(() => {
    if (activePeerAddress) {
      getChatMessagesForPeer(activePeerAddress).then((msgs) => {
        setActivePeerMessages(msgs);
      });
    } else {
      setActivePeerMessages([]);
    }
  }, [activePeerAddress]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Avoid intercepting inside inputs unless it's Ctrl+K, Ctrl+/, Ctrl+Shift+C, Esc
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      } else if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        setIsNotesOpen((prev) => !prev);
      } else if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'c') {
        if (activeSessionId) {
          e.preventDefault();
          navigator.clipboard.writeText(activeSessionId);
          setCopyToast(`Copied session code: ${activeSessionId}`);
          setTimeout(() => setCopyToast(null), 2500);
        }
      } else if (e.key === 'Escape') {
        setIsCommandPaletteOpen(false);
        setIsNotesOpen(false);
        setIsSettingsOpen(false);
        setIsCloseSessionOpen(false);
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [activeSessionId]);

  // Actions
  const handleCreateSession = async (code: string) => {
    if (!webrtcRef.current || !identity) return;
    setActiveSessionId(code);
    await webrtcRef.current.createSession(code, identity.peerAddress, identity.username);
  };

  const handleJoinSession = async (code: string) => {
    if (!webrtcRef.current || !identity) return;
    setActiveSessionId(code);
    await webrtcRef.current.joinSession(code, identity.peerAddress, identity.username);
  };

  const handleConfirmCloseSession = () => {
    webrtcRef.current?.closeSession();
    setActiveSessionId(null);
    setConnectedPeer(null);
    setStatus('disconnected');
    setStatusDetail('Session closed.');
  };

  const handleSendMessage = async (text: string) => {
    if (!webrtcRef.current || !activePeerAddress) return;
    const msgId = 'msg-' + Math.random().toString(36).substring(2, 11);
    const msg = webrtcRef.current.sendMessage(text, msgId);
    if (msg) {
      await saveChatMessage(msg);
      setActivePeerMessages((prev) => [...prev, msg]);
    }
  };

  const handleSendFile = async (file: File): Promise<string> => {
    if (!webrtcRef.current) throw new Error('WebRTC manager unavailable');
    return webrtcRef.current.sendFile(file);
  };

  const handleSendMail = async (
    toRecipients: string[],
    subject: string,
    body: string,
    attachment?: File
  ): Promise<MailItem> => {
    if (!webrtcRef.current) throw new Error('WebRTC manager unavailable');
    const attachments = attachment ? [{
      name: attachment.name,
      filename: attachment.name,
      size: attachment.size,
      type: attachment.type
    }] : undefined;
    const sentMail = webrtcRef.current.sendMail(toRecipients, subject, body, attachments);
    await saveMail(sentMail);
    const updated = await getMailItems();
    setMailItems(updated);
    return sentMail;
  };

  const handleDeleteMail = async (id: string) => {
    await deleteMail(id);
    const updated = await getMailItems();
    setMailItems(updated);
  };

  const handleUpdateUsername = async (username: string) => {
    await updateIdentityUsername(username);
    webrtcRef.current?.updateUsername(username);
    if (identity) {
      setIdentity({ ...identity, username });
    }
  };

  const handleUpdateSettings = async (newSettings: AppSettings) => {
    await saveSettings(newSettings);
    setSettings(newSettings);
    if (newSettings.iceServers && webrtcRef.current) {
      webrtcRef.current.setIceServers(newSettings.iceServers);
    }
  };

  const handleClearHistory = async () => {
    await clearHistory();
    setActivePeerMessages([]);
    setMailItems([]);
    setTransferHistory([]);
    setActiveTransfers([]);
  };

  const handleClearAllData = async () => {
    await clearAllData();
    window.location.reload();
  };

  const handleResetIdentity = async () => {
    const newId = await resetIdentityInDB();
    setIdentity(newId);
    webrtcRef.current?.updateUsername(newId.username);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#181818] text-gray-200 font-sans overflow-hidden select-none">
      {/* Top Navbar */}
      <Navbar
        identity={identity}
        status={status}
        statusDetail={statusDetail}
        connectedPeer={connectedPeer}
        onOpenNotes={() => setIsNotesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onRequestCloseSession={() => setIsCloseSessionOpen(true)}
        onNavigate={(section) => setActiveSection(section as NavigationSection)}
      />

      {/* Main Workspace: Sidebar + View Content */}
      <div className="flex flex-1 overflow-hidden pb-14 md:pb-0">
        <Sidebar
          activeSection={activeSection}
          onSelectSection={(sec) => {
            setActiveSection(sec);
            if (sec === 'messages') setUnreadMessagesCount(0);
            if (sec === 'mail') setUnreadMailCount(0);
          }}
          unreadMessagesCount={unreadMessagesCount}
          unreadMailCount={unreadMailCount}
          activeTransfersCount={activeTransfers.length}
          connectedCount={connectedPeer ? 1 : 0}
        />

        <main className="flex-1 flex flex-col overflow-hidden bg-[#181818]">
          {activeSection === 'home' && (
            <HomeView
              identity={identity}
              status={status}
              statusDetail={statusDetail}
              connectedPeer={connectedPeer}
              activeSessionId={activeSessionId}
              recentMessages={activePeerMessages}
              recentMail={mailItems}
              recentTransfers={transferHistory}
              onNavigate={(s) => setActiveSection(s)}
              onCreateConnection={() => {
                setActiveSection('connections');
              }}
              onJoinConnection={() => {
                setActiveSection('connections');
              }}
              onComposeMail={() => {
                setActiveSection('mail');
              }}
              onRequestCloseSession={() => setIsCloseSessionOpen(true)}
            />
          )}

          {activeSection === 'connections' && (
            <ConnectionsView
              identity={identity}
              status={status}
              statusDetail={statusDetail}
              connectedPeer={connectedPeer}
              activeSessionId={activeSessionId}
              knownPeers={knownPeers}
              onCreateSession={handleCreateSession}
              onJoinSession={handleJoinSession}
              onRequestCloseSession={() => setIsCloseSessionOpen(true)}
              onOpenChatWithPeer={(peerAddress) => {
                setActivePeerAddress(peerAddress);
                setActiveSection('messages');
              }}
            />
          )}

          {activeSection === 'messages' && (
            <MessagesView
              identity={identity}
              status={status}
              statusDetail={statusDetail}
              connectedPeer={connectedPeer}
              conversations={knownPeers.map(p => ({
                peerAddress: p.peerAddress,
                username: p.username,
                lastSeen: p.lastSeen
              }))}
              activePeerAddress={activePeerAddress || connectedPeer?.peerAddress || null}
              messages={activePeerMessages}
              onSelectConversation={(addr) => setActivePeerAddress(addr)}
              onSendMessage={handleSendMessage}
              onSendFile={handleSendFile}
              onRequestCloseSession={() => setIsCloseSessionOpen(true)}
              onBackToConversations={() => setActivePeerAddress(null)}
            />
          )}

          {activeSection === 'mail' && (
            <MailView
              identity={identity}
              status={status}
              connectedPeer={connectedPeer}
              mailItems={mailItems}
              onSendMail={handleSendMail}
              onDeleteMail={handleDeleteMail}
            />
          )}

          {activeSection === 'transfers' && (
            <TransfersView
              status={status}
              connectedPeer={connectedPeer}
              activeTransfers={activeTransfers}
              transferHistory={transferHistory}
              onSendFile={handleSendFile}
              onCancelTransfer={(id) => webrtcRef.current?.cancelTransfer(id)}
              onClearHistory={async () => {
                setTransferHistory([]);
              }}
            />
          )}

          {activeSection === 'tools' && <ToolsView />}
        </main>
      </div>

      {/* Slide-in Notes Sidebar */}
      <NotesSidebar
        isOpen={isNotesOpen}
        onClose={() => setIsNotesOpen(false)}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        identity={identity}
        settings={settings}
        onUpdateUsername={handleUpdateUsername}
        onUpdateSettings={handleUpdateSettings}
        onClearHistory={handleClearHistory}
        onClearAllData={handleClearAllData}
        onResetIdentity={handleResetIdentity}
      />

      {/* Close Session Confirmation Modal */}
      <CloseSessionModal
        isOpen={isCloseSessionOpen}
        onClose={() => setIsCloseSessionOpen(false)}
        onConfirmClose={handleConfirmCloseSession}
      />

      {/* Global Command Palette (Ctrl+K) */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigate={(sec) => setActiveSection(sec)}
        onOpenNotes={() => setIsNotesOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onCreateConnection={() => {
          setActiveSection('connections');
        }}
        onJoinConnection={() => {
          setActiveSection('connections');
        }}
        onComposeMail={() => {
          setActiveSection('mail');
        }}
        onRequestCloseSession={() => setIsCloseSessionOpen(true)}
        isSessionActive={Boolean(connectedPeer)}
      />

      {/* Keyboard shortcut toast notification */}
      {copyToast && (
        <div className="fixed bottom-4 right-4 bg-[#252525] border border-sky-500/50 text-white text-xs font-mono px-3.5 py-2 rounded-sm shadow-xl z-50 animate-in fade-in duration-150 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          <span>{copyToast}</span>
        </div>
      )}
    </div>
  );
}
