import { encode, decode } from 'cbor-x';
import { TransmissionPacket } from '../types';

/**
 * Internal binary serialization format for structured WebRTC DataChannel messages.
 * Uses CBOR (Concise Binary Object Representation) for high performance and low overhead.
 */
export function serializePacket(packet: TransmissionPacket): Uint8Array {
  return encode(packet);
}

/**
 * Deserializes an incoming WebRTC packet from CBOR binary (or JSON string fallback).
 */
export function deserializePacket(data: Uint8Array | ArrayBuffer | string): TransmissionPacket | null {
  try {
    if (typeof data === 'string') {
      return JSON.parse(data);
    }
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    return decode(bytes) as TransmissionPacket;
  } catch (err) {
    console.error('Failed to deserialize packet:', err);
    return null;
  }
}
