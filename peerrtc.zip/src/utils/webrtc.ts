import { 
  ConnectionStatus, 
  TransmissionPacket, 
  ChatMessage, 
  MailItem, 
  FileTransferItem 
} from '../types';
import { serializePacket, deserializePacket } from './cbor';

const CHUNK_SIZE = 32 * 1024; // 32KB per chunk

export interface PeerRTCEventHandlers {
  onStatusChange?: (status: ConnectionStatus, detail?: string) => void;
  onMessage?: (message: ChatMessage) => void;
  onMessageAck?: (messageId: string) => void;
  onMail?: (mail: MailItem) => void;
  onMailAck?: (mailId: string) => void;
  onTransferProgress?: (transfer: FileTransferItem) => void;
  onTransferComplete?: (transfer: FileTransferItem, blob: Blob) => void;
  onTransferFailed?: (transferId: string, error: string) => void;
  onPeerInfo?: (peer: { peerAddress: string; username: string }) => void;
}

export class WebRTCManager {
  private pc: RTCPeerConnection | null = null;
  private dataChannel: RTCDataChannel | null = null;
  private ws: WebSocket | null = null;
  private pollTimer: any = null;
  private heartbeatTimer: any = null;
  private reconnectTimer: any = null;

  private currentSessionId: string | null = null;
  private myAddress: string = '';
  private myUsername: string = '';
  private remotePeerAddress: string | null = null;
  private remotePeerUsername: string | null = null;
  private status: ConnectionStatus = 'disconnected';
  private isHost: boolean = false;
  private handlers: PeerRTCEventHandlers = {};

  // File reception buffers: transferId -> array of chunks
  private incomingFiles: Map<string, {
    metadata: any;
    chunks: Uint8Array[];
    receivedChunks: number;
    totalChunks: number;
    startTime: number;
    bytesReceived: number;
  }> = new Map();

  // Active outgoing transfers
  private activeUploads: Map<string, {
    file: File;
    cancelled: boolean;
  }> = new Map();

  private iceServers: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun.cloudflare.com:3478' }
  ];

  constructor(handlers: PeerRTCEventHandlers = {}) {
    this.handlers = handlers;
  }

  public setHandlers(handlers: PeerRTCEventHandlers) {
    this.handlers = { ...this.handlers, ...handlers };
  }

  public setIceServers(servers: string[]) {
    this.iceServers = servers.map(url => ({ urls: url }));
  }

  public getStatus(): ConnectionStatus {
    return this.status;
  }

  public getConnectedPeer(): { peerAddress: string; username: string } | null {
    if (this.remotePeerAddress) {
      return {
        peerAddress: this.remotePeerAddress,
        username: this.remotePeerUsername || 'Peer'
      };
    }
    return null;
  }

  public getSessionId(): string | null {
    return this.currentSessionId;
  }

  public updateUsername(newUsername: string) {
    this.myUsername = newUsername;
  }

  public setIdentity(address: string, username: string) {
    this.myAddress = address;
    this.myUsername = username;
  }

  public cancelTransfer(transferId: string) {
    this.cancelUpload(transferId);
  }

  private setStatus(newStatus: ConnectionStatus, detail?: string) {
    this.status = newStatus;
    if (this.handlers.onStatusChange) {
      this.handlers.onStatusChange(newStatus, detail);
    }
  }

  /**
   * Connect to temporary signaling server via WebSocket with HTTP polling fallback
   */
  private connectSignaling(): Promise<void> {
    return new Promise((resolve) => {
      // Determine protocol
      const isHttps = window.location.protocol === 'https:';
      const wsProtocol = isHttps ? 'wss:' : 'ws:';
      const wsUrl = `${wsProtocol}//${window.location.host}/ws`;

      try {
        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          resolve();
        };

        this.ws.onmessage = (event) => {
          this.handleSignalingMessage(event.data);
        };

        this.ws.onerror = () => {
          console.warn('Signaling WebSocket encountered error, starting HTTP polling fallback.');
          this.startHttpPolling();
          resolve();
        };

        this.ws.onclose = () => {
          if (this.status === 'connecting' || this.status === 'waiting') {
            this.startHttpPolling();
          }
        };
      } catch (err) {
        console.warn('Failed to construct WebSocket, falling back to HTTP signaling:', err);
        this.startHttpPolling();
        resolve();
      }
    });
  }

  private startHttpPolling() {
    if (this.pollTimer) return;
    this.pollTimer = setInterval(async () => {
      if (!this.currentSessionId || !this.myAddress) return;
      try {
        const res = await fetch(`/api/signaling/poll/${this.currentSessionId}/${this.myAddress}`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.messages && Array.isArray(data.messages)) {
          for (const msg of data.messages) {
            this.processSignalPacket(msg.type, msg.fromPeer, msg.payload);
          }
        }
        if (data.peer && (!this.remotePeerAddress || !this.remotePeerUsername)) {
          this.remotePeerAddress = data.peer.peerAddress;
          this.remotePeerUsername = data.peer.username;
          if (this.handlers.onPeerInfo) {
            this.handlers.onPeerInfo({
              peerAddress: data.peer.peerAddress,
              username: data.peer.username
            });
          }
        }
      } catch {
        // Polling retry
      }
    }, 1500);
  }

  private sendSignaling(data: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    } else if (this.currentSessionId) {
      // Send via REST fallback
      fetch('/api/signaling/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: this.currentSessionId,
          targetPeer: data.targetPeer || this.remotePeerAddress,
          fromPeer: this.myAddress,
          type: data.type,
          payload: data.payload || data
        })
      }).catch(err => console.error('REST signaling send failed:', err));
    }
  }

  private async handleSignalingMessage(raw: string) {
    try {
      const data = JSON.parse(raw);
      const { type, sessionId, peer, payload, fromPeer } = data;

      switch (type) {
        case 'session:created':
          this.setStatus('waiting', 'Session code generated. Waiting for peer...');
          break;

        case 'session:joined':
          if (peer) {
            this.remotePeerAddress = peer.peerAddress;
            this.remotePeerUsername = peer.username;
            if (this.handlers.onPeerInfo) {
              this.handlers.onPeerInfo(peer);
            }
          }
          this.setStatus('connecting', 'Connecting to host peer...');
          break;

        case 'peer:joined':
          if (peer) {
            this.remotePeerAddress = peer.peerAddress;
            this.remotePeerUsername = peer.username;
            if (this.handlers.onPeerInfo) {
              this.handlers.onPeerInfo(peer);
            }
          }
          this.setStatus('connecting', 'Peer detected. Establishing direct connection...');
          // Host initiates offer
          if (this.isHost && this.pc) {
            await this.createAndSendOffer();
          }
          break;

        case 'signal':
          await this.processSignalPacket(payload.signalType || payload.type, fromPeer, payload);
          break;

        case 'peer:disconnected':
          this.setStatus('disconnected', 'Peer disconnected.');
          break;

        case 'error':
          this.setStatus('failed', data.message || 'Connection failed.');
          break;
      }
    } catch (err) {
      console.error('Failed to parse signaling packet:', err);
    }
  }

  private async processSignalPacket(type: string, fromPeer: string, payload: any) {
    if (!this.pc) return;

    if (payload.peerAddress && !this.remotePeerAddress) {
      this.remotePeerAddress = payload.peerAddress;
      this.remotePeerUsername = payload.username || 'Peer';
      if (this.handlers.onPeerInfo) {
        this.handlers.onPeerInfo({
          peerAddress: payload.peerAddress,
          username: payload.username || 'Peer'
        });
      }
    }

    try {
      if (type === 'offer') {
        await this.pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
        const answer = await this.pc.createAnswer();
        await this.pc.setLocalDescription(answer);

        this.sendSignaling({
          type: 'signal',
          sessionId: this.currentSessionId,
          targetPeer: fromPeer || this.remotePeerAddress,
          peerAddress: this.myAddress,
          payload: {
            signalType: 'answer',
            sdp: answer,
            peerAddress: this.myAddress,
            username: this.myUsername
          }
        });
      } else if (type === 'answer') {
        await this.pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
      } else if (type === 'candidate') {
        if (payload.candidate) {
          await this.pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
        }
      }
    } catch (err) {
      console.error('Error handling WebRTC signal:', err);
      this.setStatus('failed', 'Signaling negotiation failed.');
    }
  }

  private setupPeerConnection() {
    if (this.pc) {
      try {
        this.pc.close();
      } catch {}
    }

    this.pc = new RTCPeerConnection({ iceServers: this.iceServers });

    this.pc.onicecandidate = (event) => {
      if (event.candidate && this.currentSessionId) {
        this.sendSignaling({
          type: 'signal',
          sessionId: this.currentSessionId,
          targetPeer: this.remotePeerAddress,
          peerAddress: this.myAddress,
          payload: {
            signalType: 'candidate',
            candidate: event.candidate,
            peerAddress: this.myAddress
          }
        });
      }
    };

    this.pc.onconnectionstatechange = () => {
      if (!this.pc) return;
      const state = this.pc.connectionState;
      if (state === 'connected') {
        this.setStatus('connected', 'Connected');
      } else if (state === 'connecting') {
        this.setStatus('connecting', 'Connecting...');
      } else if (state === 'disconnected') {
        this.setStatus('reconnecting', 'Trying to reconnect...');
        this.handleAutoReconnect();
      } else if (state === 'failed') {
        this.setStatus('failed', 'Connection failed.');
      } else if (state === 'closed') {
        this.setStatus('disconnected', 'Session closed.');
      }
    };

    this.pc.oniceconnectionstatechange = () => {
      if (!this.pc) return;
      const state = this.pc.iceConnectionState;
      if (state === 'failed') {
        this.setStatus('reconnecting', 'Trying to reconnect...');
        this.handleAutoReconnect();
      }
    };

    // If guest, listen for incoming data channel
    if (!this.isHost) {
      this.pc.ondatachannel = (event) => {
        this.bindDataChannel(event.channel);
      };
    }
  }

  private bindDataChannel(channel: RTCDataChannel) {
    this.dataChannel = channel;
    this.dataChannel.binaryType = 'arraybuffer';

    this.dataChannel.onopen = () => {
      this.setStatus('connected', 'Connected');
      this.startHeartbeat();

      // Send greeting handshake with username and address
      this.sendRawPacket({
        type: 'ping',
        payload: 'handshake',
        metadata: {
          senderAddress: this.myAddress,
          senderUsername: this.myUsername
        }
      });
    };

    this.dataChannel.onclose = () => {
      this.stopHeartbeat();
      if (this.status === 'connected') {
        this.setStatus('disconnected', 'Session closed.');
      }
    };

    this.dataChannel.onerror = (err) => {
      console.warn('DataChannel error:', err);
    };

    this.dataChannel.onmessage = (event) => {
      this.handleIncomingData(event.data);
    };
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      if (this.dataChannel && this.dataChannel.readyState === 'open') {
        this.sendRawPacket({
          type: 'ping',
          payload: 'ping',
          metadata: { timestamp: Date.now() }
        });
      }
    }, 15000);
  }

  private stopHeartbeat() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  private handleAutoReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      if (this.status === 'reconnecting' && this.pc) {
        try {
          if (this.isHost) {
            const offer = await this.pc.createOffer({ iceRestart: true });
            await this.pc.setLocalDescription(offer);
            this.sendSignaling({
              type: 'signal',
              sessionId: this.currentSessionId,
              targetPeer: this.remotePeerAddress,
              peerAddress: this.myAddress,
              payload: {
                signalType: 'offer',
                sdp: offer,
                peerAddress: this.myAddress,
                username: this.myUsername
              }
            });
          }
        } catch {
          this.setStatus('failed', 'Connection failed.');
        }
      }
    }, 3000);
  }

  private async createAndSendOffer() {
    if (!this.pc) return;
    try {
      // Host creates the data channel
      const channel = this.pc.createDataChannel('peerrtc-data', {
        ordered: true
      });
      this.bindDataChannel(channel);

      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);

      this.sendSignaling({
        type: 'signal',
        sessionId: this.currentSessionId,
        targetPeer: this.remotePeerAddress,
        peerAddress: this.myAddress,
        payload: {
          signalType: 'offer',
          sdp: offer,
          peerAddress: this.myAddress,
          username: this.myUsername
        }
      });
    } catch (err) {
      console.error('Error creating offer:', err);
      this.setStatus('failed', 'Failed to initiate connection.');
    }
  }

  /**
   * Host starts a connection session
   */
  public async createSession(sessionId: string, myAddress: string, myUsername: string) {
    this.currentSessionId = sessionId;
    this.myAddress = myAddress;
    this.myUsername = myUsername;
    this.isHost = true;
    this.remotePeerAddress = null;
    this.remotePeerUsername = null;

    this.setStatus('connecting', 'Connecting to signaling...');
    await this.connectSignaling();

    this.setupPeerConnection();

    // Register session on signaling
    this.sendSignaling({
      type: 'session:create',
      sessionId,
      peerAddress: myAddress,
      username: myUsername
    });

    // Also REST backup
    fetch('/api/signaling/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, peerAddress: myAddress, username: myUsername })
    }).catch(() => {});
  }

  /**
   * Guest joins an existing connection session
   */
  public async joinSession(sessionId: string, myAddress: string, myUsername: string) {
    this.currentSessionId = sessionId;
    this.myAddress = myAddress;
    this.myUsername = myUsername;
    this.isHost = false;
    this.remotePeerAddress = null;
    this.remotePeerUsername = null;

    this.setStatus('connecting', 'Connecting to session...');
    await this.connectSignaling();

    this.setupPeerConnection();

    // Register join on signaling
    this.sendSignaling({
      type: 'session:join',
      sessionId,
      peerAddress: myAddress,
      username: myUsername
    });

    // Also REST backup
    fetch('/api/signaling/join', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId, peerAddress: myAddress, username: myUsername })
    })
      .then(res => res.json())
      .then(data => {
        if (data.host) {
          this.remotePeerAddress = data.host.peerAddress;
          this.remotePeerUsername = data.host.username;
          if (this.handlers.onPeerInfo) {
            this.handlers.onPeerInfo(data.host);
          }
        }
      })
      .catch(() => {});
  }

  /**
   * Explicitly closes current session
   */
  public closeSession() {
    this.stopHeartbeat();
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (this.currentSessionId) {
      this.sendSignaling({
        type: 'session:leave',
        sessionId: this.currentSessionId,
        peerAddress: this.myAddress
      });
    }

    if (this.dataChannel) {
      try {
        this.dataChannel.close();
      } catch {}
      this.dataChannel = null;
    }

    if (this.pc) {
      try {
        this.pc.close();
      } catch {}
      this.pc = null;
    }

    if (this.ws) {
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    this.currentSessionId = null;
    this.remotePeerAddress = null;
    this.remotePeerUsername = null;
    this.setStatus('disconnected', 'Session closed.');
  }

  private sendRawPacket(packet: TransmissionPacket) {
    if (!this.dataChannel || this.dataChannel.readyState !== 'open') {
      throw new Error('DataChannel is not open');
    }
    const binary = serializePacket(packet);
    this.dataChannel.send(binary);
  }

  /**
   * Send 1-to-1 live chat message
   */
  public sendMessage(text: string, messageId: string): ChatMessage {
    const packet: TransmissionPacket = {
      type: 'text',
      payload: text,
      metadata: {
        id: messageId,
        senderAddress: this.myAddress,
        senderUsername: this.myUsername,
        recipientAddress: this.remotePeerAddress || undefined,
        timestamp: Date.now()
      }
    };

    this.sendRawPacket(packet);

    return {
      id: messageId,
      conversationId: this.remotePeerAddress || 'unknown',
      sender: 'me',
      senderUsername: this.myUsername,
      timestamp: Date.now(),
      type: 'text',
      text,
      deliveryStatus: 'sent'
    };
  }

  /**
   * Send PeerRTC Mail
   */
  public sendMail(
    recipients: string[],
    subject: string,
    message: string,
    attachments?: any[]
  ): MailItem {
    const mailId = 'mail-' + Math.random().toString(36).substring(2, 11);
    const mailPayloadObj = {
      id: mailId,
      from: this.myAddress,
      fromUsername: this.myUsername,
      to: recipients,
      subject,
      message,
      attachments,
      timestamp: Date.now()
    };

    const packet: TransmissionPacket = {
      type: 'mail',
      payload: mailPayloadObj,
      metadata: {
        id: mailId,
        senderAddress: this.myAddress,
        senderUsername: this.myUsername,
        timestamp: Date.now()
      }
    };

    // If connected to peer, send via DataChannel
    let status: MailItem['status'] = 'sending';
    if (this.dataChannel && this.dataChannel.readyState === 'open') {
      try {
        this.sendRawPacket(packet);
        status = 'sent';
      } catch {
        status = 'failed';
      }
    } else {
      status = 'recipient unavailable';
    }

    return {
      id: mailId,
      direction: 'sent',
      from: this.myAddress,
      fromUsername: this.myUsername,
      to: recipients,
      subject,
      message,
      attachments,
      timestamp: Date.now(),
      status,
      read: true
    };
  }

  /**
   * Send file via WebRTC chunked transfer
   */
  public async sendFile(file: File): Promise<string> {
    if (!this.dataChannel || this.dataChannel.readyState !== 'open') {
      throw new Error('DataChannel is not connected');
    }

    const transferId = 'transfer-' + Math.random().toString(36).substring(2, 10);
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);

    this.activeUploads.set(transferId, { file, cancelled: false });

    // Step 1: Send file header
    const headerPacket: TransmissionPacket = {
      type: 'file_header',
      payload: file.name,
      metadata: {
        transferId,
        filename: file.name,
        fileSize: file.size,
        mimeType: file.type || 'application/octet-stream',
        totalChunks,
        senderAddress: this.myAddress,
        senderUsername: this.myUsername
      }
    };
    this.sendRawPacket(headerPacket);

    // Initial transfer record
    const transferItem: FileTransferItem = {
      id: transferId,
      filename: file.name,
      fileSize: file.size,
      fileType: file.type || 'application/octet-stream',
      peerAddress: this.remotePeerAddress || 'unknown',
      peerUsername: this.remotePeerUsername || 'Peer',
      direction: 'upload',
      status: 'transferring',
      progress: 0,
      speed: 0,
      bytesTransferred: 0,
      totalChunks,
      chunksCompleted: 0,
      timestamp: Date.now()
    };

    if (this.handlers.onTransferProgress) {
      this.handlers.onTransferProgress(transferItem);
    }

    // Step 2: Stream binary chunks
    const startTime = Date.now();
    let bytesSent = 0;

    for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
      const uploadState = this.activeUploads.get(transferId);
      if (!uploadState || uploadState.cancelled) {
        transferItem.status = 'cancelled';
        if (this.handlers.onTransferProgress) {
          this.handlers.onTransferProgress(transferItem);
        }
        return transferId;
      }

      // Check backpressure on DataChannel
      while (this.dataChannel && this.dataChannel.bufferedAmount > 512 * 1024) {
        await new Promise(r => setTimeout(r, 40));
      }

      const start = chunkIndex * CHUNK_SIZE;
      const end = Math.min(file.size, start + CHUNK_SIZE);
      const slice = file.slice(start, end);
      const arrayBuffer = await slice.arrayBuffer();

      const chunkPacket: TransmissionPacket = {
        type: 'file_chunk',
        payload: new Uint8Array(arrayBuffer),
        metadata: {
          transferId,
          chunkIndex,
          totalChunks
        }
      };

      this.sendRawPacket(chunkPacket);
      bytesSent += (end - start);

      const elapsedSec = (Date.now() - startTime) / 1000;
      const speed = elapsedSec > 0 ? Math.round(bytesSent / elapsedSec) : 0;
      const progress = Math.min(100, Math.round((bytesSent / file.size) * 100));

      transferItem.bytesTransferred = bytesSent;
      transferItem.chunksCompleted = chunkIndex + 1;
      transferItem.progress = progress;
      transferItem.speed = speed;

      if (this.handlers.onTransferProgress) {
        this.handlers.onTransferProgress(transferItem);
      }

      // Yield control briefly to prevent UI blocking
      if (chunkIndex % 8 === 0) {
        await new Promise(r => setTimeout(r, 10));
      }
    }

    transferItem.status = 'completed';
    transferItem.progress = 100;
    this.activeUploads.delete(transferId);

    if (this.handlers.onTransferProgress) {
      this.handlers.onTransferProgress(transferItem);
    }

    return transferId;
  }

  public cancelUpload(transferId: string) {
    const upload = this.activeUploads.get(transferId);
    if (upload) {
      upload.cancelled = true;
      this.activeUploads.delete(transferId);
    }
  }

  /**
   * Parse incoming WebRTC DataChannel payloads
   */
  private handleIncomingData(rawWireData: string | ArrayBuffer) {
    try {
      const packet = deserializePacket(rawWireData);
      if (!packet) return;

      switch (packet.type) {
        case 'ping': {
          if (packet.payload === 'handshake' && packet.metadata) {
            if (packet.metadata.senderAddress && !this.remotePeerAddress) {
              this.remotePeerAddress = packet.metadata.senderAddress;
              this.remotePeerUsername = packet.metadata.senderUsername || 'Peer';
              if (this.handlers.onPeerInfo) {
                this.handlers.onPeerInfo({
                  peerAddress: packet.metadata.senderAddress,
                  username: packet.metadata.senderUsername || 'Peer'
                });
              }
            }
          }
          break;
        }

        case 'text': {
          const msgId = packet.metadata?.id || ('msg-' + Math.random().toString(36).substring(2, 9));
          const text = typeof packet.payload === 'string' ? packet.payload : String(packet.payload || '');
          const message: ChatMessage = {
            id: msgId,
            conversationId: this.remotePeerAddress || 'unknown',
            sender: this.remotePeerAddress || 'peer',
            senderUsername: packet.metadata?.senderUsername || this.remotePeerUsername || 'Peer',
            timestamp: packet.metadata?.timestamp || Date.now(),
            type: 'text',
            text,
            deliveryStatus: 'delivered'
          };

          // Send message delivery acknowledgment back to peer
          this.sendRawPacket({
            type: 'mail_ack',
            payload: msgId,
            metadata: { messageId: msgId }
          });

          if (this.handlers.onMessage) {
            this.handlers.onMessage(message);
          }
          break;
        }

        case 'mail_ack': {
          const ackMsgId = packet.metadata?.messageId || packet.payload;
          if (this.handlers.onMessageAck) {
            this.handlers.onMessageAck(ackMsgId);
          }
          if (this.handlers.onMailAck) {
            this.handlers.onMailAck(ackMsgId);
          }
          break;
        }

        case 'mail': {
          try {
            const mailData = typeof packet.payload === 'string' ? JSON.parse(packet.payload) : packet.payload;
            const mailItem: MailItem = {
              id: mailData.id || ('mail-' + Math.random().toString(36).substring(2, 10)),
              direction: 'inbox',
              from: mailData.from || this.remotePeerAddress || 'unknown',
              fromUsername: mailData.fromUsername || this.remotePeerUsername || 'Peer',
              to: mailData.to || [this.myAddress],
              subject: mailData.subject || '(No Subject)',
              message: mailData.message || '',
              attachments: mailData.attachments || [],
              timestamp: mailData.timestamp || Date.now(),
              status: 'delivered',
              read: false
            };

            // Confirm delivery back
            this.sendRawPacket({
              type: 'mail_ack',
              payload: mailItem.id,
              metadata: { messageId: mailItem.id }
            });

            if (this.handlers.onMail) {
              this.handlers.onMail(mailItem);
            }
          } catch (e) {
            console.error('Failed to parse incoming mail:', e);
          }
          break;
        }

        case 'file_header': {
          const meta = packet.metadata || {};
          const transferId = meta.transferId;
          if (!transferId) return;

          this.incomingFiles.set(transferId, {
            metadata: meta,
            chunks: new Array(meta.totalChunks),
            receivedChunks: 0,
            totalChunks: meta.totalChunks,
            startTime: Date.now(),
            bytesReceived: 0
          });

          const transferItem: FileTransferItem = {
            id: transferId,
            filename: meta.filename || 'received_file',
            fileSize: meta.fileSize || 0,
            fileType: meta.mimeType || 'application/octet-stream',
            peerAddress: this.remotePeerAddress || 'unknown',
            peerUsername: this.remotePeerUsername || 'Peer',
            direction: 'download',
            status: 'transferring',
            progress: 0,
            speed: 0,
            bytesTransferred: 0,
            totalChunks: meta.totalChunks,
            chunksCompleted: 0,
            timestamp: Date.now()
          };

          if (this.handlers.onTransferProgress) {
            this.handlers.onTransferProgress(transferItem);
          }
          break;
        }

        case 'file_chunk': {
          const meta = packet.metadata || {};
          const transferId = meta.transferId;
          const chunkIndex = meta.chunkIndex;
          const incoming = this.incomingFiles.get(transferId);

          if (!incoming) return;

          let bytes: Uint8Array;
          if (packet.payload instanceof Uint8Array) {
            bytes = packet.payload;
          } else if (typeof packet.payload === 'string') {
            const bin = atob(packet.payload);
            bytes = new Uint8Array(bin.length);
            for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          } else {
            bytes = new Uint8Array(packet.payload);
          }

          incoming.chunks[chunkIndex] = bytes;
          incoming.receivedChunks++;
          incoming.bytesReceived += bytes.length;

          const elapsedSec = (Date.now() - incoming.startTime) / 1000;
          const speed = elapsedSec > 0 ? Math.round(incoming.bytesReceived / elapsedSec) : 0;
          const progress = Math.min(100, Math.round((incoming.receivedChunks / incoming.totalChunks) * 100));

          const transferItem: FileTransferItem = {
            id: transferId,
            filename: incoming.metadata.filename || 'received_file',
            fileSize: incoming.metadata.fileSize || incoming.bytesReceived,
            fileType: incoming.metadata.mimeType || 'application/octet-stream',
            peerAddress: this.remotePeerAddress || 'unknown',
            peerUsername: this.remotePeerUsername || 'Peer',
            direction: 'download',
            status: incoming.receivedChunks === incoming.totalChunks ? 'completed' : 'transferring',
            progress,
            speed,
            bytesTransferred: incoming.bytesReceived,
            totalChunks: incoming.totalChunks,
            chunksCompleted: incoming.receivedChunks,
            timestamp: Date.now()
          };

          if (this.handlers.onTransferProgress) {
            this.handlers.onTransferProgress(transferItem);
          }

          // When all chunks arrive
          if (incoming.receivedChunks === incoming.totalChunks) {
            const blob = new Blob(incoming.chunks, { type: incoming.metadata.mimeType || 'application/octet-stream' });
            const blobUrl = URL.createObjectURL(blob);
            transferItem.blob = blob;
            transferItem.blobUrl = blobUrl;
            transferItem.status = 'completed';

            // Post as a chat message in the conversation
            if (this.handlers.onMessage) {
              this.handlers.onMessage({
                id: 'file-msg-' + transferId,
                conversationId: this.remotePeerAddress || 'unknown',
                sender: this.remotePeerAddress || 'peer',
                senderUsername: this.remotePeerUsername || 'Peer',
                timestamp: Date.now(),
                type: 'file',
                text: `Transferred file: ${incoming.metadata.filename}`,
                fileInfo: {
                  transferId,
                  filename: incoming.metadata.filename,
                  size: incoming.bytesReceived,
                  mimeType: incoming.metadata.mimeType,
                  blobUrl,
                  downloadReady: true
                },
                deliveryStatus: 'delivered'
              });
            }

            if (this.handlers.onTransferComplete) {
              this.handlers.onTransferComplete(transferItem, blob);
            }

            this.incomingFiles.delete(transferId);
          }
          break;
        }
      }
    } catch (err) {
      console.error('Error handling DataChannel message:', err);
    }
  }
}
