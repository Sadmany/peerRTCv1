/**
 * Browser-based utilities for developer & cybersecurity tasks.
 * All operations execute 100% locally in the browser with zero network transmission.
 */

// 1. HASH GENERATOR (SHA-256, SHA-384, SHA-512)
export async function computeHash(
  data: string | ArrayBuffer,
  algorithm: 'SHA-256' | 'SHA-384' | 'SHA-512'
): Promise<string> {
  const buffer = typeof data === 'string' ? new TextEncoder().encode(data) : data;
  const hashBuffer = await crypto.subtle.digest(algorithm, buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 2. JWT DECODER
export interface DecodedJWT {
  header: any;
  payload: any;
  signature: string;
  isExpired?: boolean;
  expiresAt?: string;
  issuedAt?: string;
  validFormat: boolean;
  error?: string;
}

export function decodeJWT(token: string): DecodedJWT {
  try {
    const trimmed = token.trim();
    if (!trimmed) {
      return { header: null, payload: null, signature: '', validFormat: false };
    }

    const parts = trimmed.split('.');
    if (parts.length !== 3) {
      return {
        header: null,
        payload: null,
        signature: '',
        validFormat: false,
        error: 'Invalid JWT format. Expected 3 dot-separated segments (header.payload.signature).'
      };
    }

    const base64UrlDecode = (str: string) => {
      let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
      while (base64.length % 4 !== 0) {
        base64 += '=';
      }
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      return new TextDecoder().decode(bytes);
    };

    const header = JSON.parse(base64UrlDecode(parts[0]));
    const payload = JSON.parse(base64UrlDecode(parts[1]));
    const signature = parts[2];

    let isExpired: boolean | undefined;
    let expiresAt: string | undefined;
    let issuedAt: string | undefined;

    if (payload.exp && typeof payload.exp === 'number') {
      const expDate = new Date(payload.exp * 1000);
      expiresAt = expDate.toISOString();
      isExpired = Date.now() > expDate.getTime();
    }

    if (payload.iat && typeof payload.iat === 'number') {
      issuedAt = new Date(payload.iat * 1000).toISOString();
    }

    return {
      header,
      payload,
      signature,
      isExpired,
      expiresAt,
      issuedAt,
      validFormat: true
    };
  } catch (err: any) {
    return {
      header: null,
      payload: null,
      signature: '',
      validFormat: false,
      error: `Failed to decode token: ${err.message || 'Malformed base64url content'}`
    };
  }
}

// 3. FILE METADATA & EXIF PARSER
export interface FileMetadataReport {
  filename: string;
  extension: string;
  mimeType: string;
  sizeBytes: number;
  formattedSize: string;
  lastModified?: string;
  sha256Checksum?: string;
  exifAvailable: boolean;
  cameraInfo?: {
    make?: string;
    model?: string;
    software?: string;
    lens?: string;
  };
  dateTimeOriginal?: string;
  exposureInfo?: {
    fNumber?: string;
    exposureTime?: string;
    iso?: number;
    focalLength?: string;
  };
  gpsInfo?: {
    latitude?: number;
    longitude?: number;
    altitude?: number;
    mapsLink?: string;
  };
  rawTags: Record<string, any>;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export async function extractFileMetadata(file: File): Promise<FileMetadataReport> {
  const extension = file.name.split('.').pop()?.toLowerCase() || '';
  const report: FileMetadataReport = {
    filename: file.name,
    extension,
    mimeType: file.type || 'application/octet-stream',
    sizeBytes: file.size,
    formattedSize: formatFileSize(file.size),
    lastModified: file.lastModified ? new Date(file.lastModified).toISOString() : undefined,
    exifAvailable: false,
    rawTags: {}
  };

  // Compute SHA-256 Checksum client-side (slice if huge to prevent memory exhaustion, full if <= 25MB)
  try {
    const buffer = await file.slice(0, Math.min(file.size, 25 * 1024 * 1024)).arrayBuffer();
    report.sha256Checksum = await computeHash(buffer, 'SHA-256');
    if (file.size > 25 * 1024 * 1024) {
      report.sha256Checksum += ' (first 25MB preview)';
    }
  } catch (err) {
    console.warn('Hash computation failed:', err);
  }

  // Parse JPEG EXIF APP1 Segment
  if (file.type === 'image/jpeg' || extension === 'jpg' || extension === 'jpeg') {
    try {
      const buffer = await file.slice(0, 128 * 1024).arrayBuffer();
      const view = new DataView(buffer);

      if (view.getUint16(0) === 0xFFD8) {
        let offset = 2;
        while (offset < view.byteLength - 2) {
          const marker = view.getUint16(offset);
          offset += 2;

          if (marker === 0xFFE1) {
            const length = view.getUint16(offset);
            offset += 2;
            const exifHeader = String.fromCharCode(
              view.getUint8(offset),
              view.getUint8(offset + 1),
              view.getUint8(offset + 2),
              view.getUint8(offset + 3)
            );

            if (exifHeader === 'Exif') {
              report.exifAvailable = true;
              parseExifTIFF(view, offset + 6, report);
            }
            break;
          } else if ((marker & 0xFF00) === 0xFF00 && marker !== 0xFF00) {
            const length = view.getUint16(offset);
            offset += length;
          } else {
            break;
          }
        }
      }
    } catch (e) {
      console.warn('EXIF parsing notice:', e);
    }
  }

  return report;
}

function parseExifTIFF(view: DataView, tiffOffset: number, report: FileMetadataReport) {
  try {
    const isLittleEndian = view.getUint16(tiffOffset) === 0x4949; // 'II'
    const firstIFDOffset = view.getUint32(tiffOffset + 4, isLittleEndian);
    let ifdOffset = tiffOffset + firstIFDOffset;

    const numEntries = view.getUint16(ifdOffset, isLittleEndian);
    ifdOffset += 2;

    report.cameraInfo = {};
    report.exposureInfo = {};

    let exifSubIFDOffset: number | null = null;
    let gpsIFDOffset: number | null = null;

    for (let i = 0; i < numEntries; i++) {
      const entryOffset = ifdOffset + i * 12;
      if (entryOffset + 12 > view.byteLength) break;

      const tag = view.getUint16(entryOffset, isLittleEndian);
      const count = view.getUint32(entryOffset + 4, isLittleEndian);
      const valueOffset = entryOffset + 8;

      const getStringVal = () => {
        let strOffset = count > 4 ? tiffOffset + view.getUint32(valueOffset, isLittleEndian) : valueOffset;
        let str = '';
        for (let j = 0; j < count - 1; j++) {
          if (strOffset + j < view.byteLength) {
            str += String.fromCharCode(view.getUint8(strOffset + j));
          }
        }
        return str.trim();
      };

      if (tag === 0x010f) report.cameraInfo.make = getStringVal();
      else if (tag === 0x0110) report.cameraInfo.model = getStringVal();
      else if (tag === 0x0131) report.cameraInfo.software = getStringVal();
      else if (tag === 0x0132) report.dateTimeOriginal = getStringVal();
      else if (tag === 0x8769) exifSubIFDOffset = tiffOffset + view.getUint32(valueOffset, isLittleEndian);
      else if (tag === 0x8825) gpsIFDOffset = tiffOffset + view.getUint32(valueOffset, isLittleEndian);
    }

    if (exifSubIFDOffset && exifSubIFDOffset < view.byteLength - 2) {
      const subEntries = view.getUint16(exifSubIFDOffset, isLittleEndian);
      let subOffset = exifSubIFDOffset + 2;

      for (let i = 0; i < subEntries; i++) {
        const entryOffset = subOffset + i * 12;
        if (entryOffset + 12 > view.byteLength) break;
        const tag = view.getUint16(entryOffset, isLittleEndian);
        const valueOffset = entryOffset + 8;

        if (tag === 0x829D) {
          const ratOffset = tiffOffset + view.getUint32(valueOffset, isLittleEndian);
          const num = view.getUint32(ratOffset, isLittleEndian);
          const den = view.getUint32(ratOffset + 4, isLittleEndian);
          if (den !== 0) report.exposureInfo.fNumber = `f/${(num / den).toFixed(1)}`;
        } else if (tag === 0x8827) {
          report.exposureInfo.iso = view.getUint16(valueOffset, isLittleEndian);
        }
      }
    }

    if (gpsIFDOffset && gpsIFDOffset < view.byteLength - 2) {
      report.gpsInfo = {};
      const gpsEntries = view.getUint16(gpsIFDOffset, isLittleEndian);
      let gOffset = gpsIFDOffset + 2;
      let latRef = 'N', lonRef = 'E';
      let latCoords: number[] = [], lonCoords: number[] = [];

      for (let i = 0; i < gpsEntries; i++) {
        const entryOffset = gOffset + i * 12;
        if (entryOffset + 12 > view.byteLength) break;
        const tag = view.getUint16(entryOffset, isLittleEndian);
        const valueOffset = entryOffset + 8;

        if (tag === 0x0001) latRef = String.fromCharCode(view.getUint8(valueOffset));
        else if (tag === 0x0003) lonRef = String.fromCharCode(view.getUint8(valueOffset));
        else if (tag === 0x0002) {
          const ratOffset = tiffOffset + view.getUint32(valueOffset, isLittleEndian);
          for (let c = 0; c < 3; c++) {
            const num = view.getUint32(ratOffset + c * 8, isLittleEndian);
            const den = view.getUint32(ratOffset + c * 8 + 4, isLittleEndian);
            latCoords.push(den !== 0 ? num / den : 0);
          }
        } else if (tag === 0x0004) {
          const ratOffset = tiffOffset + view.getUint32(valueOffset, isLittleEndian);
          for (let c = 0; c < 3; c++) {
            const num = view.getUint32(ratOffset + c * 8, isLittleEndian);
            const den = view.getUint32(ratOffset + c * 8 + 4, isLittleEndian);
            lonCoords.push(den !== 0 ? num / den : 0);
          }
        }
      }

      if (latCoords.length === 3) {
        let lat = latCoords[0] + latCoords[1] / 60 + latCoords[2] / 3600;
        if (latRef === 'S') lat = -lat;
        report.gpsInfo.latitude = parseFloat(lat.toFixed(6));
      }
      if (lonCoords.length === 3) {
        let lon = lonCoords[0] + lonCoords[1] / 60 + lonCoords[2] / 3600;
        if (lonRef === 'W') lon = -lon;
        report.gpsInfo.longitude = parseFloat(lon.toFixed(6));
      }
      if (report.gpsInfo.latitude !== undefined && report.gpsInfo.longitude !== undefined) {
        report.gpsInfo.mapsLink = `https://www.openstreetmap.org/?mlat=${report.gpsInfo.latitude}&mlon=${report.gpsInfo.longitude}#map=16/${report.gpsInfo.latitude}/${report.gpsInfo.longitude}`;
      }
    }
  } catch (err) {
    console.warn('Error reading TIFF structure:', err);
  }
}

export async function stripImageMetadata(file: File): Promise<{ cleanBlob: Blob; cleanFilename: string }> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Local metadata stripping is currently supported for image files (JPEG, PNG, WebP).'));
      return;
    }

    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to get 2D canvas context'));
        return;
      }

      ctx.drawImage(img, 0, 0);

      const mime = file.type === 'image/jpeg' ? 'image/jpeg' : 'image/png';
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Canvas blob generation failed'));
          return;
        }
        const nameParts = file.name.split('.');
        const ext = nameParts.pop();
        const cleanFilename = `${nameParts.join('.')}_sanitized.${ext}`;
        resolve({ cleanBlob: blob, cleanFilename });
      }, mime, 0.95);
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to load image for sanitization'));
    };

    img.src = objectUrl;
  });
}

// 4. UUID GENERATOR (v4 and v7)
export function generateUUIDv4(): string {
  if (typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function generateUUIDv7(): string {
  const timestamp = BigInt(Date.now());
  const randomBytes = new Uint8Array(10);
  crypto.getRandomValues(randomBytes);

  // 48-bit timestamp
  const timeHex = timestamp.toString(16).padStart(12, '0');
  
  // version 7 (0x7)
  const randA = (randomBytes[0] & 0x0f) | 0x70;
  const randAHex = randA.toString(16).padStart(2, '0') + randomBytes[1].toString(16).padStart(2, '0');
  
  // variant 1 (0x8 - 0xb)
  const randB = (randomBytes[2] & 0x3f) | 0x80;
  let restHex = randB.toString(16).padStart(2, '0');
  for (let i = 3; i < 10; i++) {
    restHex += randomBytes[i].toString(16).padStart(2, '0');
  }

  return `${timeHex.substring(0, 8)}-${timeHex.substring(8, 12)}-${randAHex}-${restHex.substring(0, 4)}-${restHex.substring(4)}`;
}

export function generateUUIDs(count: number, version: 'v4' | 'v7', uppercase: boolean = false, hyphens: boolean = true): string[] {
  const result: string[] = [];
  for (let i = 0; i < count; i++) {
    let uuid = version === 'v7' ? generateUUIDv7() : generateUUIDv4();
    if (!hyphens) uuid = uuid.replace(/-/g, '');
    if (uppercase) uuid = uuid.toUpperCase();
    result.push(uuid);
  }
  return result;
}

// 5. TIMESTAMP CONVERTER
export interface ParsedTimestamp {
  unixSeconds: number;
  unixMillis: number;
  iso8601: string;
  utcString: string;
  localString: string;
  relative: string;
}

export function parseTimestamp(input: number | string): ParsedTimestamp | null {
  let ms: number;

  if (typeof input === 'number') {
    // If < 10000000000, likely seconds
    ms = input < 10000000000 ? input * 1000 : input;
  } else {
    const num = Number(input.trim());
    if (!isNaN(num) && num > 0) {
      ms = num < 10000000000 ? num * 1000 : num;
    } else {
      const parsed = Date.parse(input);
      if (isNaN(parsed)) return null;
      ms = parsed;
    }
  }

  const date = new Date(ms);
  if (isNaN(date.getTime())) return null;

  const now = Date.now();
  const diffSec = Math.round((now - ms) / 1000);
  let relative = '';
  if (Math.abs(diffSec) < 60) {
    relative = diffSec >= 0 ? `${diffSec}s ago` : `in ${Math.abs(diffSec)}s`;
  } else if (Math.abs(diffSec) < 3600) {
    const m = Math.round(diffSec / 60);
    relative = m >= 0 ? `${m}m ago` : `in ${Math.abs(m)}m`;
  } else if (Math.abs(diffSec) < 86400) {
    const h = Math.round(diffSec / 3600);
    relative = h >= 0 ? `${h}h ago` : `in ${Math.abs(h)}h`;
  } else {
    const d = Math.round(diffSec / 86400);
    relative = d >= 0 ? `${d}d ago` : `in ${Math.abs(d)}d`;
  }

  return {
    unixSeconds: Math.floor(ms / 1000),
    unixMillis: ms,
    iso8601: date.toISOString(),
    utcString: date.toUTCString(),
    localString: date.toLocaleString(),
    relative
  };
}

// 6. JSON FORMATTER & VALIDATOR
export interface JSONValidationResult {
  isValid: boolean;
  formatted?: string;
  minified?: string;
  error?: string;
  line?: number;
  column?: number;
  sizeBeforeBytes: number;
  sizeAfterBytes?: number;
}

export function validateAndFormatJSON(input: string, indentSpaces: number = 2): JSONValidationResult {
  const sizeBeforeBytes = new TextEncoder().encode(input).length;
  if (!input.trim()) {
    return { isValid: false, error: 'Input is empty', sizeBeforeBytes: 0 };
  }

  try {
    const parsed = JSON.parse(input);
    const formatted = JSON.stringify(parsed, null, indentSpaces);
    const minified = JSON.stringify(parsed);
    const sizeAfterBytes = new TextEncoder().encode(formatted).length;

    return {
      isValid: true,
      formatted,
      minified,
      sizeBeforeBytes,
      sizeAfterBytes
    };
  } catch (err: any) {
    let line: number | undefined;
    let column: number | undefined;

    // Extract position from message like "at position 42 (line 3 column 5)"
    const match = err.message.match(/position\s+(\d+)/i);
    if (match) {
      const pos = parseInt(match[1], 10);
      const lines = input.substring(0, pos).split('\n');
      line = lines.length;
      column = lines[lines.length - 1].length + 1;
    }

    return {
      isValid: false,
      error: err.message || 'SyntaxError: Invalid JSON',
      line,
      column,
      sizeBeforeBytes
    };
  }
}
