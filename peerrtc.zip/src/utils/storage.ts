import { UserIdentity, AppSettings, KnownPeer, ChatMessage, MailItem, FileTransferItem } from '../types';

const DB_NAME = 'PeerRTC_LocalDB';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function generateRandomAddress(): string {
  const chars = '0123456789ABCDEF';
  const segments: string[] = [];
  for (let s = 0; s < 4; s++) {
    let seg = '';
    for (let i = 0; i < 4; i++) {
      seg += chars[Math.floor(Math.random() * chars.length)];
    }
    segments.push(seg);
  }
  return `PRTC-${segments.join('-')}`;
}

const DEFAULT_USERNAMES = ['ShadowFox', 'RedTeam', 'NullByte', 'CyberKid', 'GhostSec', 'ZeroDay', 'Cipher'];

export function getRandomDefaultUsername(): string {
  return DEFAULT_USERNAMES[Math.floor(Math.random() * DEFAULT_USERNAMES.length)];
}

export function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not supported in this browser environment'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Identity store
      if (!db.objectStoreNames.contains('identity')) {
        db.createObjectStore('identity', { keyPath: 'id' });
      }

      // Settings store
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'id' });
      }

      // Known peers store
      if (!db.objectStoreNames.contains('connections')) {
        db.createObjectStore('connections', { keyPath: 'peerAddress' });
      }

      // Messages store
      if (!db.objectStoreNames.contains('messages')) {
        const msgStore = db.createObjectStore('messages', { keyPath: 'id' });
        msgStore.createIndex('conversationId', 'conversationId', { unique: false });
        msgStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // Mail store
      if (!db.objectStoreNames.contains('mail')) {
        const mailStore = db.createObjectStore('mail', { keyPath: 'id' });
        mailStore.createIndex('direction', 'direction', { unique: false });
        mailStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // Transfers store
      if (!db.objectStoreNames.contains('transfers')) {
        const transferStore = db.createObjectStore('transfers', { keyPath: 'id' });
        transferStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      resolve((event.target as IDBOpenDBRequest).result);
    };

    request.onerror = (event) => {
      console.error('IndexedDB open failed:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
}

// ==================== IDENTITY ====================

export async function getStoredIdentity(): Promise<UserIdentity> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('identity', 'readonly');
      const store = tx.objectStore('identity');
      const req = store.get('current_identity');

      req.onsuccess = () => {
        if (req.result) {
          resolve(req.result.data);
        } else {
          // Generate fresh identity
          const newIdentity: UserIdentity = {
            username: getRandomDefaultUsername(),
            peerAddress: generateRandomAddress(),
            createdAt: Date.now()
          };
          saveIdentity(newIdentity).then(() => resolve(newIdentity));
        }
      };

      req.onerror = () => {
        const fallback: UserIdentity = {
          username: getRandomDefaultUsername(),
          peerAddress: generateRandomAddress(),
          createdAt: Date.now()
        };
        resolve(fallback);
      };
    });
  } catch {
    // Fallback if IndexedDB fails
    const local = localStorage.getItem('peerrtc_identity');
    if (local) {
      return JSON.parse(local);
    }
    const fresh: UserIdentity = {
      username: getRandomDefaultUsername(),
      peerAddress: generateRandomAddress(),
      createdAt: Date.now()
    };
    localStorage.setItem('peerrtc_identity', JSON.stringify(fresh));
    return fresh;
  }
}

export async function saveIdentity(identity: UserIdentity): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('identity', 'readwrite');
      const store = tx.objectStore('identity');
      const req = store.put({ id: 'current_identity', data: identity });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('Fallback to localStorage for identity:', e);
  }
  localStorage.setItem('peerrtc_identity', JSON.stringify(identity));
}

export async function updateUsername(newUsername: string): Promise<UserIdentity> {
  const cleanUsername = newUsername.trim().substring(0, 10) || 'Anonymous';
  const identity = await getStoredIdentity();
  identity.username = cleanUsername;
  await saveIdentity(identity);
  return identity;
}

// ==================== SETTINGS ====================

export const DEFAULT_SETTINGS: AppSettings = {
  autoReconnect: true,
  stripMetadataOnTransfer: true,
  iceServers: [
    'stun:stun.l.google.com:19302',
    'stun:stun1.l.google.com:19302',
    'stun:stun.cloudflare.com:3478'
  ]
};

export async function getStoredSettings(): Promise<AppSettings> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const req = store.get('user_settings');

      req.onsuccess = () => {
        if (req.result) {
          resolve({ ...DEFAULT_SETTINGS, ...req.result.data });
        } else {
          saveSettings(DEFAULT_SETTINGS).then(() => resolve(DEFAULT_SETTINGS));
        }
      };

      req.onerror = () => resolve(DEFAULT_SETTINGS);
    });
  } catch {
    const local = localStorage.getItem('peerrtc_settings');
    if (local) {
      try {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(local) };
      } catch {
        return DEFAULT_SETTINGS;
      }
    }
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const req = store.put({ id: 'user_settings', data: settings });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.warn('Fallback to localStorage for settings:', e);
  }
  localStorage.setItem('peerrtc_settings', JSON.stringify(settings));
}

// ==================== KNOWN CONNECTIONS ====================

export async function getKnownPeers(): Promise<KnownPeer[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('connections', 'readonly');
      const store = tx.objectStore('connections');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function saveKnownPeer(peer: KnownPeer): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('connections', 'readwrite');
      const store = tx.objectStore('connections');
      const req = store.put(peer);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.error('Failed to save known peer:', e);
  }
}

// ==================== MESSAGES & CONVERSATIONS ====================

export async function getMessagesForConversation(conversationId: string): Promise<ChatMessage[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('messages', 'readonly');
      const store = tx.objectStore('messages');
      const index = store.index('conversationId');
      const req = index.getAll(conversationId);

      req.onsuccess = () => {
        const msgs: ChatMessage[] = req.result || [];
        msgs.sort((a, b) => a.timestamp - b.timestamp);
        resolve(msgs);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function getAllConversations(): Promise<Array<{ peerAddress: string; lastMessage?: ChatMessage }>> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('messages', 'readonly');
      const store = tx.objectStore('messages');
      const req = store.getAll();

      req.onsuccess = () => {
        const msgs: ChatMessage[] = req.result || [];
        const map = new Map<string, ChatMessage>();
        for (const m of msgs) {
          const prev = map.get(m.conversationId);
          if (!prev || m.timestamp > prev.timestamp) {
            map.set(m.conversationId, m);
          }
        }
        const list = Array.from(map.entries()).map(([peerAddress, lastMessage]) => ({
          peerAddress,
          lastMessage
        }));
        list.sort((a, b) => (b.lastMessage?.timestamp || 0) - (a.lastMessage?.timestamp || 0));
        resolve(list);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function saveMessage(message: ChatMessage): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('messages', 'readwrite');
      const store = tx.objectStore('messages');
      const req = store.put(message);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.error('Failed to save message to IndexedDB:', e);
  }
}

export async function updateMessageDeliveryStatus(id: string, status: ChatMessage['deliveryStatus']): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction('messages', 'readwrite');
    const store = tx.objectStore('messages');
    const req = store.get(id);

    req.onsuccess = () => {
      if (req.result) {
        const updated = { ...req.result, deliveryStatus: status };
        store.put(updated);
      }
    };
  } catch (e) {
    console.error('Failed to update message status:', e);
  }
}

// ==================== MAIL HISTORY ====================

export async function getMailHistory(direction?: 'inbox' | 'sent'): Promise<MailItem[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('mail', 'readonly');
      const store = tx.objectStore('mail');

      let req: IDBRequest;
      if (direction) {
        const index = store.index('direction');
        req = index.getAll(direction);
      } else {
        req = store.getAll();
      }

      req.onsuccess = () => {
        const items: MailItem[] = req.result || [];
        items.sort((a, b) => b.timestamp - a.timestamp);
        resolve(items);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function saveMail(mail: MailItem): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('mail', 'readwrite');
      const store = tx.objectStore('mail');
      const req = store.put(mail);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.error('Failed to save mail:', e);
  }
}

export async function updateMailStatus(id: string, status: MailItem['status']): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction('mail', 'readwrite');
    const store = tx.objectStore('mail');
    const req = store.get(id);

    req.onsuccess = () => {
      if (req.result) {
        const updated = { ...req.result, status };
        store.put(updated);
      }
    };
  } catch (e) {
    console.error('Failed to update mail status:', e);
  }
}

export async function markMailAsRead(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction('mail', 'readwrite');
    const store = tx.objectStore('mail');
    const req = store.get(id);

    req.onsuccess = () => {
      if (req.result) {
        const updated = { ...req.result, read: true };
        store.put(updated);
      }
    };
  } catch (e) {
    console.error('Failed to mark mail as read:', e);
  }
}

// ==================== FILE TRANSFERS ====================

export async function getFileTransfers(): Promise<FileTransferItem[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction('transfers', 'readonly');
      const store = tx.objectStore('transfers');
      const req = store.getAll();

      req.onsuccess = () => {
        const items: FileTransferItem[] = req.result || [];
        items.sort((a, b) => b.timestamp - a.timestamp);
        resolve(items);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

export async function saveFileTransfer(transfer: FileTransferItem): Promise<void> {
  try {
    const db = await openDatabase();
    // Strip Blob before saving to IndexedDB if large, or store metadata
    const storable = {
      ...transfer,
      blob: undefined,
      blobUrl: undefined
    };
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('transfers', 'readwrite');
      const store = tx.objectStore('transfers');
      const req = store.put(storable);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (e) {
    console.error('Failed to save transfer:', e);
  }
}

// ==================== DESTRUCTIVE STORAGE ACTIONS ====================

export async function clearLocalHistory(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(['messages', 'mail', 'transfers'], 'readwrite');
    tx.objectStore('messages').clear();
    tx.objectStore('mail').clear();
    tx.objectStore('transfers').clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllPeerRTCData(): Promise<void> {
  const db = await openDatabase();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(['identity', 'settings', 'connections', 'messages', 'mail', 'transfers'], 'readwrite');
    tx.objectStore('identity').clear();
    tx.objectStore('settings').clear();
    tx.objectStore('connections').clear();
    tx.objectStore('messages').clear();
    tx.objectStore('mail').clear();
    tx.objectStore('transfers').clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  localStorage.removeItem('peerrtc_identity');
  localStorage.removeItem('peerrtc_settings');
}

export async function resetIdentity(): Promise<UserIdentity> {
  const fresh: UserIdentity = {
    username: getRandomDefaultUsername(),
    peerAddress: generateRandomAddress(),
    createdAt: Date.now()
  };
  await saveIdentity(fresh);
  return fresh;
}

export async function deleteMail(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    const tx = db.transaction('mail', 'readwrite');
    tx.objectStore('mail').delete(id);
  } catch (e) {
    console.error('Failed to delete mail:', e);
  }
}

export async function getStorageStats(): Promise<{
  messagesCount: number;
  mailCount: number;
  transfersCount: number;
  peersCount: number;
  approximateSizeBytes: number;
}> {
  try {
    const db = await openDatabase();
    const countStore = (storeName: string): Promise<number> => {
      return new Promise((res) => {
        try {
          const tx = db.transaction(storeName, 'readonly');
          const countReq = tx.objectStore(storeName).count();
          countReq.onsuccess = () => res(countReq.result);
          countReq.onerror = () => res(0);
        } catch {
          res(0);
        }
      });
    };

    const [messagesCount, mailCount, transfersCount, peersCount] = await Promise.all([
      countStore('messages'),
      countStore('mail'),
      countStore('transfers'),
      countStore('connections')
    ]);

    // Rough estimation
    const approximateSizeBytes = (messagesCount * 250) + (mailCount * 1200) + (transfersCount * 400) + (peersCount * 180);

    return {
      messagesCount,
      mailCount,
      transfersCount,
      peersCount,
      approximateSizeBytes
    };
  } catch {
    return {
      messagesCount: 0,
      mailCount: 0,
      transfersCount: 0,
      peersCount: 0,
      approximateSizeBytes: 0
    };
  }
}

// Convenient aliases for components
export const getOrCreateIdentity = getStoredIdentity;
export const updateIdentityUsername = updateUsername;
export const resetIdentityInDB = resetIdentity;
export const getSettings = getStoredSettings;
export const getChatMessagesForPeer = getMessagesForConversation;
export const saveChatMessage = saveMessage;
export const getAllKnownPeers = getKnownPeers;
export const getMailItems = getMailHistory;
export const clearHistory = clearLocalHistory;
export const clearAllData = clearAllPeerRTCData;

