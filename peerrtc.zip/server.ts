import express, { Request, Response } from 'express';
import http from 'http';
import path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';

interface SignalingSession {
  id: string;
  createdAt: number;
  host: {
    peerAddress: string;
    username: string;
    ws?: WebSocket;
  };
  guest?: {
    peerAddress: string;
    username: string;
    ws?: WebSocket;
  };
  // Temporary message buffer for HTTP polling fallback
  messages: Array<{
    id: string;
    targetPeer: string;
    fromPeer: string;
    type: string;
    payload: any;
    timestamp: number;
  }>;
}

const app = express();
const server = http.createServer(app);
const PORT = 3000;

app.use(express.json({ limit: '2mb' }));

// In-memory active temporary signaling sessions
const sessions = new Map<string, SignalingSession>();

// Cleanup stale sessions older than 15 minutes
setInterval(() => {
  const now = Date.now();
  for (const [id, session] of sessions.entries()) {
    if (now - session.createdAt > 15 * 60 * 1000) {
      sessions.delete(id);
    }
  }
}, 60 * 1000);

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    activeSessions: sessions.size,
    timestamp: Date.now()
  });
});

// REST Fallback: Create Session
app.post('/api/signaling/create', (req: Request, res: Response) => {
  const { sessionId, peerAddress, username } = req.body;
  if (!sessionId || !peerAddress) {
    return res.status(400).json({ error: 'sessionId and peerAddress required' });
  }

  const session: SignalingSession = {
    id: sessionId,
    createdAt: Date.now(),
    host: {
      peerAddress,
      username: username || 'UserA'
    },
    messages: []
  };

  sessions.set(sessionId, session);
  return res.json({ success: true, sessionId });
});

// REST Fallback: Join Session
app.post('/api/signaling/join', (req: Request, res: Response) => {
  const { sessionId, peerAddress, username } = req.body;
  const session = sessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: 'Session code not found or expired.' });
  }

  if (session.host.peerAddress === peerAddress) {
    return res.status(400).json({ error: 'Cannot join your own session.' });
  }

  session.guest = {
    peerAddress,
    username: username || 'UserB'
  };

  // Notify host that guest joined
  session.messages.push({
    id: Math.random().toString(36).substring(2, 9),
    targetPeer: session.host.peerAddress,
    fromPeer: peerAddress,
    type: 'peer:joined',
    payload: {
      peerAddress,
      username: username || 'UserB'
    },
    timestamp: Date.now()
  });

  return res.json({
    success: true,
    host: {
      peerAddress: session.host.peerAddress,
      username: session.host.username
    }
  });
});

// REST Fallback: Send Signaling message (SDP offer/answer, ICE candidate)
app.post('/api/signaling/message', (req: Request, res: Response) => {
  const { sessionId, targetPeer, fromPeer, type, payload } = req.body;
  const session = sessions.get(sessionId);

  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }

  // Push to temporary message buffer
  session.messages.push({
    id: Math.random().toString(36).substring(2, 9),
    targetPeer,
    fromPeer,
    type,
    payload,
    timestamp: Date.now()
  });

  // Keep buffer bounded
  if (session.messages.length > 50) {
    session.messages.splice(0, session.messages.length - 50);
  }

  return res.json({ success: true });
});

// REST Fallback: Poll for Signaling messages
app.get('/api/signaling/poll/:sessionId/:peerAddress', (req: Request, res: Response) => {
  const { sessionId, peerAddress } = req.params;
  const session = sessions.get(sessionId);

  if (!session) {
    return res.json({ messages: [], active: false });
  }

  const messagesForPeer = session.messages.filter(m => m.targetPeer === peerAddress);
  // Remove messages retrieved
  session.messages = session.messages.filter(m => m.targetPeer !== peerAddress);

  return res.json({
    messages: messagesForPeer,
    active: true,
    peer: session.host.peerAddress === peerAddress ? session.guest : session.host
  });
});

// WebSocket Signaling Server
const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws: WebSocket) => {
  let boundSessionId: string | null = null;
  let boundPeerAddress: string | null = null;

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());
      const { type, sessionId, peerAddress, username, targetPeer, payload } = msg;

      switch (type) {
        case 'session:create': {
          boundSessionId = sessionId;
          boundPeerAddress = peerAddress;

          const session: SignalingSession = {
            id: sessionId,
            createdAt: Date.now(),
            host: {
              peerAddress,
              username: username || 'UserA',
              ws
            },
            messages: []
          };
          sessions.set(sessionId, session);
          ws.send(JSON.stringify({ type: 'session:created', sessionId }));
          break;
        }

        case 'session:join': {
          boundSessionId = sessionId;
          boundPeerAddress = peerAddress;
          const session = sessions.get(sessionId);

          if (!session) {
            ws.send(JSON.stringify({ type: 'error', message: 'Session code not found or expired.' }));
            return;
          }

          if (session.host.peerAddress === peerAddress) {
            ws.send(JSON.stringify({ type: 'error', message: 'Cannot join your own session.' }));
            return;
          }

          session.guest = {
            peerAddress,
            username: username || 'UserB',
            ws
          };

          // Notify guest about host
          ws.send(JSON.stringify({
            type: 'session:joined',
            sessionId,
            peer: {
              peerAddress: session.host.peerAddress,
              username: session.host.username
            }
          }));

          // Notify host that guest joined
          if (session.host.ws && session.host.ws.readyState === WebSocket.OPEN) {
            session.host.ws.send(JSON.stringify({
              type: 'peer:joined',
              peer: {
                peerAddress,
                username: username || 'UserB'
              }
            }));
          }
          break;
        }

        case 'signal': {
          if (!sessionId) return;
          const session = sessions.get(sessionId);
          if (!session) return;

          // Target is the other peer
          const targetWs = session.host.peerAddress === targetPeer 
            ? session.host.ws 
            : (session.guest?.peerAddress === targetPeer ? session.guest.ws : undefined);

          if (targetWs && targetWs.readyState === WebSocket.OPEN) {
            targetWs.send(JSON.stringify({
              type: 'signal',
              fromPeer: peerAddress,
              payload
            }));
          }
          break;
        }

        case 'session:leave': {
          if (sessionId) {
            const session = sessions.get(sessionId);
            if (session) {
              const otherWs = session.host.peerAddress === peerAddress ? session.guest?.ws : session.host.ws;
              if (otherWs && otherWs.readyState === WebSocket.OPEN) {
                otherWs.send(JSON.stringify({ type: 'peer:disconnected', peerAddress }));
              }
              sessions.delete(sessionId);
            }
          }
          break;
        }
      }
    } catch (err) {
      console.error('WebSocket message parsing error:', err);
    }
  });

  ws.on('close', () => {
    if (boundSessionId && boundPeerAddress) {
      const session = sessions.get(boundSessionId);
      if (session) {
        const otherWs = session.host.peerAddress === boundPeerAddress ? session.guest?.ws : session.host.ws;
        if (otherWs && otherWs.readyState === WebSocket.OPEN) {
          otherWs.send(JSON.stringify({ type: 'peer:disconnected', peerAddress: boundPeerAddress }));
        }
      }
    }
  });
});

async function startServer() {
  // Vite dev server middleware or static prod serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`PeerRTC Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
